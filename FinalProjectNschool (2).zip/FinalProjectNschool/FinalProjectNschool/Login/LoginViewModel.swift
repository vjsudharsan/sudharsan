//
//  LoginViewModel.swift
//  FinalProjectNschool
//
//  Created by Apple on 25/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import Foundation
class LoginViewModel{
    var reloadClosure: (() -> ())?
    
    var loginModelClass: LoginModel? {
        didSet {
            self.reloadClosure?()
        }
    }
    
    func apiPostCall(email: String, password: String) {
        
        let params = ["email": email, "password": password] as Dictionary<String, String>
        
        var request = URLRequest(url: URL(string: "http://demo.smartstorez.com/TESTAPI/UserLogin")!)
        request.httpMethod = "POST"
        request.httpBody = try? JSONSerialization.data(withJSONObject: params, options: [])
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let session = URLSession.shared
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            print(response!)
            do {
                let json = try JSONSerialization.jsonObject(with: data!) as! Dictionary<String, AnyObject>
                print(json)
                let jsonDecoder = JSONDecoder()
                let responseModel = try jsonDecoder.decode(LoginModel.self, from: data!)
                print(responseModel)
                self.loginModelClass = responseModel
            } catch {
                print("error")
            }
        })
        
        task.resume()
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
