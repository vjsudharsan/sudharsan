//
//  ProfileViewModel.swift
//  FinalProjectNschool
//
//  Created by Apple on 25/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import Foundation
class ProfileViewModel {
    var update = ProfileModel()
    var emptyString = ""
    var reloadClosure: (() -> ())?
    
    var profileModelCLass: ProfileModel?{
        didSet {
            self.reloadClosure?()
        }
    }
    
    
    var profileList: DataList?
    
    var UserId: String {
        return profileList?.UserId ?? emptyString
    }
    var firstname: String {
        return profileList?.firstname ?? emptyString
    }
    var lastname: String {
        return profileList?.lastname ?? emptyString
    }
    var mobile: String {
        return profileList?.mobile ?? emptyString
    }
    var email: String {
        return profileList?.email ?? emptyString
    }

    func apiPostCall(UserId: String,firstname: String,lastname:String, mobile: String) {
        
        let params = ["UserId":UserId,"firstname":firstname,"lastname": lastname,"mobile":mobile] as Dictionary<String, String>
        
        var request = URLRequest(url: URL(string: "http://demo.smartstorez.com/TESTAPI/UserUpdateProfile")!)
        request.httpMethod = "POST"
        request.httpBody = try? JSONSerialization.data(withJSONObject: params, options: [])
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let session = URLSession.shared
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            print(response!)
            do {
                let json = try JSONSerialization.jsonObject(with: data!) as! Dictionary<String, AnyObject>
                print(json)
                let jsonDecoder = JSONDecoder()
                let responseModel = try jsonDecoder.decode(ProfileModel.self, from: data!)
                print(responseModel)
                self.profileModelCLass = responseModel
                DispatchQueue.main.async {
                    // your code here
                }
            } catch {
                print("error")
            }
        })
        
        task.resume()
    }
    
    
    
}
