//
//  UserListViewController.swift
//  FinalProjectNschool
//
//  Created by Apple on 25/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import UIKit

class UserListViewController: UIViewController {
    
    @IBOutlet weak var myTableView: UITableView!
    
    var userViewModel = UserListViewModel()
    //     var reuseidentifier = "UserListTableViewCell"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = " USER LIST "
       
        navigationItem.hidesBackButton = true
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool){
       self.initViewModel()
    }
    
    
    
    func initViewModel() {
        userViewModel.reloadClosures = {
            [weak self] in
            guard let self = self else { return}
            DispatchQueue.main.async {
                self.myTableView.reloadData()
            }
        }
        self.userViewModel.getMethod()
    }
    
    
}

extension UserListViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return userViewModel.numberOfSection
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userViewModel.numberOfRowsInSection
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = myTableView.dequeueReusableCell(withIdentifier: Constants.reuseableidentifier) as! UserListTableViewCell
        
        if let getObject = userViewModel.cellRowAtindexPath(indexpath: indexPath), let first = getObject.firstname, let last = getObject.lastname {
            cell.nameLabel.text = String(first.appending(last))
            cell.emailLabel.text = getObject.email
            cell.phoneLabel.text = getObject.mobile
            cell.ProfileLayer.image = UIImage(named: "placeholder")
        }
        
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return  UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let userData = self.userViewModel.cellRowAtindexPath(indexpath: indexPath)
        if  let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "ProfileViewController") as? ProfileViewController {
            vc.profileViewModel.profileList = userData
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
        
    }
}
