//
//  UserListModel.swift
//  FinalProjectNschool
//
//  Created by Apple on 25/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import Foundation
struct UserListModel: Decodable {
    var message: String?
    var status: Int?
    var data: [DataList]?
}
struct DataList: Decodable{
    var UserId: String?
    var firstname: String?
    var lastname: String?
    var email: String?
    var mobile: String?
    var createdDateTime: String?
}
