//
//  UpdateViewController.swift
//  ProjectTest2
//
//  Created by nschool on 03/12/20.
//

import UIKit

class UpdateViewController: UIViewController {
    
    @IBOutlet weak var textFieldfirstName: UITextField!
    @IBOutlet weak var textFieldlastName: UITextField!
    @IBOutlet weak var textFieldEmail: UITextField!
    @IBOutlet weak var textFieldMobileNumber: UITextField!
    @IBOutlet weak var bgImage: UIImageView!
    var updateViewModel = UpdateViewModel()
   
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "UPDATE DETAILES"
        textFieldfirstName.text = updateViewModel.first_name
        textFieldlastName.text = updateViewModel.last_name
        textFieldEmail.text = updateViewModel.email_Id
        textFieldMobileNumber.text = updateViewModel.mobile_Number
        self.initViewModel()
        
    }
   
    
    func initViewModel() {
        updateViewModel.reloadClosure = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.navigationController?.popViewController(animated: true)
        }
        }
        
    }
    
    func navigationToUserViewController() {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "UserListViewController") as? UserListViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    @IBAction func logoutButton(_ sender: UIButton) {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "LogInViewController") as? LogInViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    
    
    
    
    @IBAction func buttonActionUpdate(_ sender: Any) {
        if let firstName = textFieldfirstName.text , let lastName = textFieldlastName.text, let mobile = textFieldMobileNumber.text, let userid = textFieldEmail.text {
            if firstName == "" && lastName == "" && mobile == "" {
                print("All fields Mandatory")
            }else if firstName == "" {
                print("Enter first name")
            }else if lastName == "" {
                print("Enter last name")}
                else if mobile == "" {
                    print("enter mobile number")
                }else if !CommonFunction().validateFirstName(name: firstName){
                    print("Enter valid first Name")
                }else if !CommonFunction().validateLastName(name: lastName){
                    print("Enter valid lastName")
                }else if !CommonFunction().validatePhoneNumber(phoneNumber: mobile){
                    print("Enter valid mobile")
                }else {
                    self.updateViewModel.apiPostCall(UserId: userid, firstname: firstName, lastname: lastName, mobilenumber: mobile)
                }
            
      
        
        
    }
    
    
    
}

}
