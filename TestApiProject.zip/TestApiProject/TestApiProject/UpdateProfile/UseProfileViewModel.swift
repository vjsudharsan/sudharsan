import Foundation
class UpdateViewModel {
    var update = UpdateModel()
    var emptyString = ""
    var reloadClosure: (() -> ())?
    
    var updateModel: UpdateModel? {
        didSet {
            self.reloadClosure?()
        }
    }
    
    var userList: UserListData?
    var userId: String {
        return userList?.UserId ?? emptyString
    }
    var first_name: String {
        return userList?.firstname ?? emptyString
    }
    var last_name: String {
        return userList?.lastname ?? emptyString
    }
    var mobile_Number: String {
        return userList?.mobile ?? emptyString
    }
    var email_Id: String {
        return userList?.email ?? emptyString
    }
    
    func apiPostCall(UserId: String, firstname: String, lastname: String, mobilenumber: String ) {
        let params = ["UserId": userId, "firstname": firstname, "lastname": lastname, "mobile": mobilenumber] as Dictionary<String, Any>
        var request = URLRequest(url: URL(string: "http://demo.smartstorez.com/TESTAPI/UserRegister")!)
        request.httpMethod = "POST"
        request.httpBody = try? JSONSerialization.data(withJSONObject: params, options: [])
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        let session = URLSession.shared
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            print(response!)
            do {
                let json = try JSONSerialization.jsonObject(with: data!) as! Dictionary<String, AnyObject>
                print(json)
                let jsonDecoder = JSONDecoder()
                let responseModel = try jsonDecoder.decode(UpdateModel.self, from: data!)
                print(responseModel)
                self.updateModel = responseModel
                DispatchQueue.main.async {
                    // your code here
                   
                }
            } catch {
                print("error")
            }
        })
        task.resume()
    }
}
