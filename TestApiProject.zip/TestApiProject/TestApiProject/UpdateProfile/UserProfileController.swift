//
//  UseListViewController.swift
//  TestApiProject
//
//  Created by nschool on 29/01/21.
//

import UIKit

class UserProfileController: UIViewController {
    @IBOutlet weak var textFieldfirstName: UITextField!
    @IBOutlet weak var textFieldLastName: UITextField!
    @IBOutlet weak var textFieldcreateTime: UITextField!
    @IBOutlet weak var textFieldEmail: UITextField!
    @IBOutlet weak var textFieldMobileNumber: UITextField!

    var updateViewModel = UpdateViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "UPDATE DETAILES"
        te
        initViewModel()
        
    }
    
    func initViewModel() {
        updateViewModel.reloadClosure = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.navigationToUserViewController()
            }
        }
        
    }
    
    func navigationToUserViewController() {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "UserListViewController") as? UserListViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    
    
    
    
    @IBAction func buttonActionUpdate(_ sender: Any) {
        if let firstName = textFieldfirstName.text , let lastName = textFieldlastName.text, let email = textFieldEmail.text, let mobile = textFieldMobileNumber.text {
//            self.updateViewModel.apiUpdatePostMethodCall(firstname: firstName, lastName: lastName, email: email, mobilenumber: mobile)
        }
    
    
    
}
