//
//  UserListViewModel.swift
//  ProjectTest2
//
//  Created by nschool on 03/12/20.
//

import Foundation
class UserListViewModel {
    var reloadClosure: (() -> ())?
    var userListModel: UserListModel? {
        didSet {
            self.reloadClosure?()
        }
    }
    func getMethod() {
        var request = URLRequest(url: URL(string: "http://demo.smartstorez.com/TESTAPI/GetUsersList")!)
        request.httpMethod = "GET"
        
        URLSession.shared.dataTask(with: request, completionHandler: { data, response, error -> Void in
            do {
                let jsonDecoder = JSONDecoder()
                let responseModel = try jsonDecoder.decode(UserListModel.self, from: data!)
                print(responseModel)
                //note
                self.userListModel = responseModel
                //
            } catch {
                print("JSON Serialization error")
            }
        }).resume()
    }
    
    
    
    
    
    var numberOfSection: Int {
        return 1
    }
    var numberOfRowsInSctions: Int {
        return userListModel?.data?.count ?? 0
    }
    func getObject(indexpath: IndexPath) -> UserListData? {
        if let object = userListModel?.data?[indexpath.row] {
            return object
        }
        return nil
    }
}
