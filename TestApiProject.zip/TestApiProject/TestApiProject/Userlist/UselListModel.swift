//
//  UserListModel.swift
//  PracticalProject
//
//  Created by nschool on 01/12/20.
//

import Foundation
struct UserListModel: Decodable {
    var message: String?
    var status: Int?
    var data: [UserListData]?
}
struct UserListData: Decodable {
    var UserId: String?
    var firstname: String?
    var lastname: String?
    var mobile: String?
    var email: String?
   
    
}


