
import UIKit

class UserListViewController: UIViewController {
    
    @IBOutlet weak var userListTableView: UITableView!
    var userListViewModel = UserListViewModel()
    var userListCellidentfier = "UserListTableViewCell"
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "USER LIST"
        
        navigationItem.hidesBackButton = true
        
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        self.initViewModel()
    }
    func initViewModel() {
        userListViewModel.reloadClosure = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.userListTableView.reloadData()
            }
        }
        self.userListViewModel.getMethod()
    }
}
extension UserListViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return userListViewModel.numberOfSection
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userListViewModel.numberOfRowsInSctions
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = userListTableView.dequeueReusableCell(withIdentifier: "UserListTableViewCell") as! UserListTableViewCell
        if let dataObject = userListViewModel.getObject(indexpath: indexPath), let first = dataObject.firstname,let last = dataObject.lastname  {
            cell.labelFirstName.text = String(first.appending(last))
            cell.labelEmail.text = dataObject.email
            cell.labelMobileNumber.text = dataObject.mobile
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let userDetails = self.userListViewModel.getObject(indexpath: indexPath)
        if let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "UpdateViewController") as? UpdateViewController {
            vc.updateViewModel.userList = userDetails
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
}

