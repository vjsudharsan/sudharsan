//
//  LogInViewController.swift
//  TestApiProject
//
//  Created by nschool on 29/01/21.
//

import UIKit

class LogInViewController: UIViewController {
    var loginViewModel = LogInViewModel()
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordLabel: UILabel!
    @IBOutlet weak var PasswordTextField: UITextField!
    @IBOutlet weak var bagroundimage: UIImageView!
    @IBOutlet weak var logoImage: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.initViewModel()
        self.title = "LOGIN"
        navigationItem.hidesBackButton = true

        // Do any additional setup after loading the view.
    }
    func initViewModel() {
        loginViewModel.relaodClosure = { [weak self] in
            guard let self = self else {return}
            DispatchQueue.main.async {
                self.navigationToUserViewController()
            }
            
        }
    }
    func navigationToUserViewController() {
        print("success")
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "UserListViewController") as? UserListViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    @IBAction func logInButtonAction(_ sender: Any) {
        if let email = emailTextField.text, let password = PasswordTextField.text {
            if email == "" && password == "" {
                print("All Fields are Mandatory")
            } else if email == "" {
                print("enter the email")
            } else if password == "" {
                print("enter the password")
            } else if !CommonFunction().validateEmailId(emailID: email) {
                print("Enter Valid Email")
            } else if !CommonFunction().validatePassword(password: password) {
                print("Enter Valid Password")
            } else {
                loginViewModel.postApiCall(email: email, password: password)
            
        }
    }
    }
    
    @IBAction func newUserButton(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "RegisterViewController") as? RegisterViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }



  
}
extension LogInViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == emailTextField {
            self.PasswordTextField.becomeFirstResponder()
        } else if textField == PasswordTextField {
            self.PasswordTextField.resignFirstResponder()
        }
        return true
    }
}
