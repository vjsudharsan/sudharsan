//
//  LogInViewModel.swift
//  TestApiProject
//
//  Created by nschool on 29/01/21.
//

import Foundation
class LogInViewModel {
    var relaodClosure: (()->())?
    
    var loginModel: LoginModel? {
        didSet {
            self.relaodClosure?()
        }
    }
    func postApiCall(email: String, password: String) {
        let params = ["email":email, "password":password] as Dictionary<String, String>

        var request = URLRequest(url: URL(string: "http://demo.smartstorez.com/TESTAPI/UserLogin")!)
        request.httpMethod = "POST"
        request.httpBody = try? JSONSerialization.data(withJSONObject: params, options: [])
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")

        let session = URLSession.shared
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            print(response!)
            do {
                let json = try JSONSerialization.jsonObject(with: data!) as! Dictionary<String, AnyObject>
                print(json)
                let jsonDecoder = JSONDecoder()
                        let responseModel = try jsonDecoder.decode(LoginModel.self, from: data!)
                        print(responseModel)
                self.loginModel = responseModel
            } catch {
                print("error")
            }
        })

        task.resume()
    }
    
}

