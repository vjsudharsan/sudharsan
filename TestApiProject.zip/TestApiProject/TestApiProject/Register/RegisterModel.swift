//
//  RegisterModel.swift
//  PracticalProject
//
//  Created by nschool on 01/12/20.
//

import Foundation

struct  RegisterModel: Decodable {
    
    var data: RegisterData?
    var message: String?
    var status: Int?
}
struct RegisterData: Decodable {
    var UserId: Int?
    var Username: String?
   
}
