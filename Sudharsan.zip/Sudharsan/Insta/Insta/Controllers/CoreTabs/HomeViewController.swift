//
//  ViewController.swift
//  Insta
//
//  Created by Apple on 08/02/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

