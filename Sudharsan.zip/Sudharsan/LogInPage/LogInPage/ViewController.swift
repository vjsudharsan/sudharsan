//
//  ViewController.swift
//  login page
//
//  Created by NNMACMINI14 on 03/09/20.
//  Copyright © 2020 Nanonino. All rights reserved.
//

import UIKit

class CompleteAccountViewController: UIViewController {
    
    @IBOutlet var labelTitle: UILabel!
    @IBOutlet var viewMain: UIView!
    @IBOutlet var viewMenu: UIView!
    @IBOutlet var imgConsultTime: UIImageView!
    @IBOutlet var imgConsultPrice: UIImageView!
    @IBOutlet var imgBankAc: UIImageView!
    @IBOutlet var imgInvite: UIImageView!
    @IBOutlet var buttonStartNow: UIButton!
    var buttonConsultTime = true
    var buttonConsultPrice = true
    var buttonBankAcc = true
    var buttonInvite = true
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.buttonStartNow.layer.cornerRadius = 20
        self.buttonStartNow.clipsToBounds = true
        self.buttonStartNow.layer.shadowOffset = CGSize(width: 0, height: 3)
        self.buttonStartNow.layer.shadowOpacity = 0.7
        self.buttonStartNow.layer.shadowRadius = 3
        self.buttonStartNow.layer.masksToBounds = false
        
        self.viewMain.layer.cornerRadius = 15
        self.viewMain.clipsToBounds = true
        
    }
    
    
    @IBAction func buttonConsultPrice(_ sender: Any) {
        if buttonConsultPrice {
            self.imgConsultPrice.image = UIImage(named: "ic_checkbox")
            buttonConsultPrice = false
        }
        else {
            self.imgConsultPrice.image = UIImage(named: "ic_checkbox_grey")
            buttonConsultPrice = true
            
        }
        
    }
    
    
    @IBAction func buttonConsultTime(_ sender: Any) {
        
        if buttonConsultTime {
            self.imgConsultTime.image = UIImage(named: "ic_checkbox")
            buttonConsultTime = false
        }
        else {
            self.imgConsultTime.image = UIImage(named: "ic_checkbox_grey")
            buttonConsultTime = true
            
        }
    }
    
    
    @IBAction func buttonBankAcc(_ sender: Any) {
        
        if buttonBankAcc {
            self.imgBankAc.image = UIImage(named: "ic_checkbox")
            buttonBankAcc = false
        }
        else {
            self.imgBankAc.image = UIImage(named: "ic_checkbox_grey")
            buttonBankAcc = true
        }
    }
    
    @IBAction func buttonInvitePatients(_ sender: Any) {
        if buttonInvite {
            self.imgInvite.image = UIImage(named: "ic_checkbox")
            buttonInvite = false
        }
        else {
            self.imgInvite.image = UIImage(named: "ic_checkbox_grey")
            buttonInvite = true
        }
    }
    
    
    @IBAction func buttonStartNow(_ sender: Any) {
    }
    
    @IBAction func buttonDoitLater(_ sender: Any) {
    }
    
    
}

