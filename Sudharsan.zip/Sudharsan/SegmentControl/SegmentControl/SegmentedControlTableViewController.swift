//
//  ViewController.swift
//  Segmented_Control
//
//  Created by NNMACMINI14 on 11/02/20.
//  Copyright © 2020 NNMACMINI14. All rights reserved.
//

import UIKit

class SegmentedControlTableViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
   
    

    @IBOutlet var hi: UISegmentedControl!
    @IBOutlet var segmentedControl: UISegmentedControl!
   
    @IBOutlet var tableViewSegmented: UITableView!
    
    var arrayFruits: [String] = []
    
    var arrayVeg: [String] = []
    
    var arrayNonVeg:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        arrayFruits = [ "Apple", "orange", "Grapes", "Pineapple", "Guava"]
        
        arrayVeg = ["spinach", "ladies finger", "potato", "drumstick", "capsicum"]
        
        arrayNonVeg = ["Mutton", "Fish", "Prawn", "Chicken", "Crab"]
        
    }
    
    
    
    @IBAction func segmentedControl(_ sender: Any) {
        
        switch segmentedControl.selectedSegmentIndex{
            
        case 0 :
            
            tableViewSegmented.reloadData()
            
        case 1:
            
            tableViewSegmented.reloadData()
            
        case 2:
            
              tableViewSegmented.reloadData()
            
        default:
            break
        }
        
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var returnValue = 0
    
    
        switch  segmentedControl.selectedSegmentIndex {
        
        case 0 :
            
            returnValue = arrayFruits.count
            
        
        case 1:
            
          returnValue = arrayVeg.count
    
        case 2:
            
            returnValue = arrayNonVeg.count
            
            
        default:
            break
        }
        
        
        return returnValue
}
    
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell1 = tableViewSegmented.dequeueReusableCell(withIdentifier: "cell1", for: indexPath)
           let cell2 = tableViewSegmented.dequeueReusableCell(withIdentifier: "cell2", for: indexPath)
        
        let cell3 = tableViewSegmented.dequeueReusableCell(withIdentifier: "cell3", for: indexPath)
      
        switch segmentedControl.selectedSegmentIndex{
            
        case 0:
            
            
            cell1.textLabel?.text = arrayVeg[indexPath.row]
            
            return cell1
            
        case 1:
            
         
            
            cell2.textLabel?.text = arrayNonVeg[indexPath.row]
            
             return cell2
            
        case 2:
            
            cell3.textLabel?.text = arrayFruits[indexPath.row]
            
             return cell3
            
        default:
            break
        }
        
        let cell = tableViewSegmented.dequeueReusableCell(withIdentifier: "cell")!
         return cell
    }

}
