//
//  SegmentedMapViewController.swift
//  Segmented_Control
//
//  Created by NNMACMINI14 on 15/02/20.
//  Copyright © 2020 NNMACMINI14. All rights reserved.
//

import UIKit
import MapKit

class SegmentedMapViewController: UIViewController {

    @IBOutlet var segmentedMapView: UISegmentedControl!
    
    @IBOutlet var mapKitView: MKMapView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    
    
    
    @IBAction func segmentedMapView(_ sender: Any) {
        
        switch segmentedMapView.selectedSegmentIndex {
            
        case 0:
            
            mapKitView.mapType = .standard
            
        case 1:
            
            mapKitView.mapType = .satellite
            
        case 2:
            mapKitView.mapType = .hybrid
       
        default:
            break
        }
        
    }
    
    

}
