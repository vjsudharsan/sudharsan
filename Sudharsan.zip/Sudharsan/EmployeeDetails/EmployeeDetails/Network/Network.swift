//
//  Network.swift
//  Network
//
//  Created by Periyasamy R on 16/10/20.
//  Copyright © 2020 Periyasamy R. All rights reserved.
//

//import Foundation
//public protocol APIServiceCallProtocol: APIServiceProtocol {
//    func getCountryList(completion: @escaping APIParsedResponse)
//    func getEmployeeListWithService(completion: @escaping APIParsedResponse)
//}
//
//class Network: APIService, APIServiceCallProtocol {
//    func getCountryList(completion: @escaping APIParsedResponse) {
//        
//        loadMockData(fileName: "countries", modelType: CountryModel.self, completion: {(code, response, error) in
//            completion(code, response, error)
//        })
//    }
//    func getEmployeeListWithService(completion: @escaping APIParsedResponse) {
//        connectNetwork(modelType: EmployeesModel.self, withBaseURl: Constants.API.employees, withParameters: Constants.Common.kEmptyString, withHttpMethod: Constants.Common.KEY_GET, withContentType: Constants.Common.CONTENTTYPE_URL_ENCODE) { (code, response, error) in
//            completion(code, response, error)
//        }
//    }
//}
