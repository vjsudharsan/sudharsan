//
//  UserListViewModel.swift
//  ProjectTask
//
//  Created by nschool on 21/10/20.
//

import Foundation
class UserListViewModel {
    let apiService: APIServiceCallProtocol
    var showAlertClosure: (() -> ())?
    var updateLoadingStatus: (() -> ())?
    var reloadClosure: (() -> ())?
    
    var userListModel: UserListModel? {
        didSet {
            self.reloadClosure?()
        }
    }
    var alertMessage: ServiceError? {
        didSet {
            self.showAlertClosure?()
        }
    }
    var isLoading: Bool = false {
        didSet {
            self.updateLoadingStatus?()
        }
    }
    init(apiService: APIServiceCallProtocol = Network()) {
        self.apiService = apiService
    }
    
    var pageTitle: String {
        return Constants.Common.kUserListTitle
    }
    
    
    func getUserList() {
        self.isLoading = true
        apiService.getUserListWithService() { [weak self] (success, response, error) in
            guard let self = self else { return }
            self.isLoading = false
            if success == ResponseCode.success {
                guard let response = response else {
                    self.alertMessage = error
                    return
                }
                self.userListModel = response as? UserListModel
                
            } else {
                self.alertMessage = error
            }
        }
    }
    
    //TableView
    
    var numberOfSections: Int {
        return 1
    }
    
    var numberOfRowsInSection: Int {
        return self.userListModel?.data?.count ?? 0
    }
    
    func getcellForRowAt(indexpath: IndexPath) -> String {
        
        //
        //         if let id = "\(String(describing: self.userListModel?.data?[indexpath.row].id))" {
        //                   return id
        //               }
        //           return Constants.Common.kEmptyString
        //           }
        
        
        //
        if let email = self.userListModel?.data?[indexpath.row].email {
            return email
        }
        return Constants.Common.kEmptyString
    }
    
    func getSelectObject(indexpath: IndexPath) -> UserDataList? {
        if let userObject = self.userListModel?.data?[indexpath.row] {
            return userObject
        }
        return nil
        // return self.userListModel?.data?[indexpath.row]
        
    }
    
}

