//
//  UserListViewController.swift
//  ProjectTask
//
//  Created by nschool on 21/10/20.
//

import UIKit

class UserListViewController: UIViewController {
    
    var userListViewModel = UserListViewModel()
    
    @IBOutlet weak var userListTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = userListViewModel.pageTitle
        self.initViewModel()
        self.navigationItem.setHidesBackButton(true, animated: true)
        userListTableView.tableFooterView = UIView()
        
        
    }
    
    func initViewModel() {
        
        userListViewModel.updateLoadingStatus = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                if self.userListViewModel.isLoading {
                    // Start Animating
                } else {
                    // Stop Animating
                }
            }
        }
        userListViewModel.showAlertClosure = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                if let errorMessage = self.userListViewModel.alertMessage {
                    print(errorMessage.localizedDescription)
                }
            }
        }
        userListViewModel.reloadClosure = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                // TableView ReloadData
                self.userListTableView.reloadData()
            }
        }
        
        self.userListViewModel.getUserList()
        
    }
    
    
    
}

extension UserListViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return userListViewModel.numberOfSections
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userListViewModel.numberOfRowsInSection
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.userListTableView.dequeueReusableCell(withIdentifier: Constants.TableViewIdentifier.kUserListTableViewCell) as! UserListTableViewCell
        cell.idLabel.text = userListViewModel.getcellForRowAt(indexpath: indexPath)
        cell.accessoryType = .disclosureIndicator
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
}


