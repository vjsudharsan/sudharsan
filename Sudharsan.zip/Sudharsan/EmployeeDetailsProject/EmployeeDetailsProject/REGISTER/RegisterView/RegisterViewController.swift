//
//  RegisterViewController.swift
//  ProjectTask
//
//  Created by nschool on 21/10/20.
//

import UIKit

class RegisterViewController: UIViewController {
    
    var registerViewModel = RegisterViewModel()
    
    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var phoneNumberTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = registerViewModel.pageTitle
        // Do any additional setup after loading the view.
    }
    
    @IBAction func submitRegisterButtonAction(_ sender: UIButton) {
        
        if let userNameTextField = userNameTextField.text , let emailTextField = emailTextField.text ,let passwordTextField = passwordTextField.text, let phoneNumberTextField = phoneNumberTextField.text {
            
            if userNameTextField == "" && emailTextField == "" && passwordTextField == "" && emailTextField == "" && passwordTextField == "" && phoneNumberTextField == "" {
                print("All Fields Are Mandatory!!!")
            } else if userNameTextField == "" {
                print("Please Enter User Name!!!")
            } else if emailTextField == "" {
                print("Please Enter Email!!!")
            } else if passwordTextField == "" {
                print("Please Enter Password!!!")
            } else if phoneNumberTextField == "" {
                print("Please Enter Phone Number!!!")
            } else if !CommonFunction().validateFirstName(name: userNameTextField) {
                print("Please Enter Valid User Name!!!")
            } else if !CommonFunction().validateEmailId(emailID: emailTextField) {
                print("Please Enter Valid Email!!!")
            } else if !CommonFunction().validatePassword(password: passwordTextField) {
                print("Please Enter Valid Password!!!")
            } else if !CommonFunction().validatePhoneNumber(phoneNumber: phoneNumberTextField) {
                print("Please Enter Valid Phone Number!!!")
            } else {
                let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "UserListViewController") as? UserListViewController
                self.navigationController?.pushViewController(vc!, animated: true)
                self.registerViewModel.registerPostAPICall()
            }
            
            
        }
        
        
        
        //        let controller = UserListViewController()
        //        self.navigationController?.pushViewController(controller, animated: true)
        
    }
    
}

extension RegisterViewController: UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == userNameTextField {
            emailTextField.becomeFirstResponder()
        } else if textField == emailTextField {
            passwordTextField.becomeFirstResponder()
        } else if textField == passwordTextField {
            phoneNumberTextField.becomeFirstResponder()
        } else if textField == passwordTextField {
            passwordTextField.resignFirstResponder()
        }
        return true
    }
}
