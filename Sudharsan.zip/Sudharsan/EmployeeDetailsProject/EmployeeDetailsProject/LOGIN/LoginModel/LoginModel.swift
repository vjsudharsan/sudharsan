//
//  LoginModel.swift
//  EmployeeDetailsProject
//
//  Created by Apple on 23/10/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
struct LoginModel: Decodable {
    var token: String?
}
//struct LoginModel: Decodable {
//    var page: Int?
//    var per_page:Int?
//    var total: Int?
//    var total_pages:Int?
//    var data: [Data]?
//    var ad: Ad?
//
//}
//
//struct Data: Decodable {
//    var id:String?
//    var email:String?
//    var first_name:String?
//    var last_name :String?
//    var avatar : String?
//
//}
//
//struct Ad: Decodable  {
//    var company: String?
//    var url:String?
//    var text:String?
//
//}
