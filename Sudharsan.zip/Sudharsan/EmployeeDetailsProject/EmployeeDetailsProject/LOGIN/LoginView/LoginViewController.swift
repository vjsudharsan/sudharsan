//
//  LoginViewController.swift
//  EmployeeDetailsProject
//
//  Created by Apple on 23/10/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordtextField: UITextField!
    var loginViewModel = LoginViewModel()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = loginViewModel.pageTitle
        // Do any additional setup after loading the view.
        initViewModel()
    }
    
    func initViewModel() {
        
        loginViewModel.updateLoadingStatus = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                if self.loginViewModel.isLoading {
                    // Start Animating
                } else {
                    // Stop Animating
                }
            }
        }
        loginViewModel.showAlertClosure = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                if let errorMessage = self.loginViewModel.alertMessage {
                    print(errorMessage.localizedDescription)
                }
            }
        }
        loginViewModel.reloadClosure = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "UserListViewController") as? UserListViewController
                self.navigationController?.pushViewController(vc!, animated: true)
            }
        }
        
        
    }
    
    @IBAction func submitButtonAction(_ sender: UIButton) {
        //
        if let emailText =  emailTextField.text, let passwordText = passwordtextField.text  {
            if emailText == "" && passwordText == "" {
                print("All Fields Are Mandatory")
            } else if emailText == "" {
                print("Enter Email")
            } else if passwordText == "" {
                print("Enter Password")
            } else if !CommonFunction().validateEmailId(emailID: emailText){
                print("Invalid Email")
            }
                                else if !CommonFunction().validatePassword(password: passwordText) {
                                print("Invalid Password")
                            }
            else {
                self.loginViewModel.loginPostAPICall(email: emailText, password: passwordText)
            }
            //
        }
        
        
        
    }
    
    
    @IBAction func newUserButtonAction(_ sender: UIButton) {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "RegisterViewController") as? RegisterViewController
        self.navigationController?.pushViewController(vc!, animated: true)
        
      
        
    }
    
    
}

extension LoginViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == emailTextField {
            self.passwordtextField.becomeFirstResponder()
        } else if textField == passwordtextField {
            self.passwordtextField.resignFirstResponder()
        }
        return true
    }
}
