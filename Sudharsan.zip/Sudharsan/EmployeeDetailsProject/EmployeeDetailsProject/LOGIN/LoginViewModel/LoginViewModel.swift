//
//  LoginViewModel.swift
//  EmployeeDetailsProject
//
//  Created by Apple on 23/10/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
class LoginViewModel {
    let apiService: APIServiceCallProtocol
    var showAlertClosure: (() -> ())?
    var updateLoadingStatus: (() -> ())?
    var reloadClosure: (() -> ())?
    
    var loginModel: LoginModel? {
        didSet {
            self.reloadClosure?()
        }
        
    }
    var alertMessage: ServiceError? {
        didSet {
            self.showAlertClosure?()
        }
    }
    var isLoading: Bool = false {
        didSet {
            self.updateLoadingStatus?()
        }
    }
    
    init(apiService: APIServiceCallProtocol = Network()) {
        self.apiService = apiService
    }
    
    var pageTitle: String {
        return Constants.Common.kLoginTitle
    }
    
    
    func loginPostAPICall(email: String, password: String) {
        self.isLoading = true
        apiService.loginPostMethodAPICall(email: email, password: password) { [weak self] (success, response, error) in
            guard let self = self else { return }
            self.isLoading = false
            if success == ResponseCode.success {
                guard let response = response else {
                    self.alertMessage = error
                    return
                }
                self.loginModel = response as? LoginModel
                
            } else {
                self.alertMessage = error
            }
        }
    }
}
