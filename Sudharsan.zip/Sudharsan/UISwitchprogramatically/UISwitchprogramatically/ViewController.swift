//
//  ViewController.swift
//  UISwitchprogramatically
//
//  Created by Apple on 18/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    lazy var switchDemo: UISwitch = {
        let switchState = UISwitch()
        switchState.frame = CGRect(x: 150, y: 150, width: 0, height: 0)
        switchState.onTintColor = UIColor.cyan
        switchState.thumbTintColor = UIColor.red
        switchState.isOn = false
     return switchState
    }()
    
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addSubview(switchDemo)
        
    }
    
    
    


}

