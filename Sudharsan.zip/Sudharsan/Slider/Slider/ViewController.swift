//
//  ViewController.swift
//  Slider
//
//  Created by Apple on 11/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var slider: UIView!
    @IBOutlet weak var valueLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


    @IBAction func sliderAction(_ sender: Any) {
       valueLabel.text = "\(slider.value)"
    }
}

