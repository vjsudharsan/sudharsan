//
//  Common.swift
//  ColorJsonDecode
//
//  Created by Apple on 05/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import Foundation
struct Constant {
    static let reuseIdentifier = "ColorTableViewCell"
    static let title = "Colors"
}
