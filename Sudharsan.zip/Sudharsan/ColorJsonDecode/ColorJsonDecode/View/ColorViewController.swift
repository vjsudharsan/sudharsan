//
//  ColorViewController.swift
//  ColorJsonDecode
//
//  Created by Apple on 05/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import UIKit

class ColorViewController: UIViewController {
    @IBOutlet weak var colorTable: UITableView!
    var viewModel = ColorViewModel()

    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.SetupBundle()

        // Do any additional setup after loading the view.
    }
}
extension ColorViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return viewModel.numberOfSections()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfRowsinSections(section: section)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = colorTable.dequeueReusableCell(withIdentifier: Constant.reuseIdentifier) as! ColorTableViewCell
        if let object = viewModel.cellRowatIndexPath(indexpath: indexPath) {
            cell.colorLabel.text = object.color
            cell.catagoryLabel.text = object.category
            cell.codeLabel.text = object.code?.hex
            
        }
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return viewModel.titleforHeader(section: section)
    }
    

    
}
