//
//  ColorViewModel.swift
//  ColorJsonDecode
//
//  Created by Apple on 05/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import Foundation
class ColorViewModel {
    var colorModel: ColorModel?
    
    func SetupBundle() {
        colorModel = Bundle.main.decode(ColorModel.self , from: "newproject.json")
    }
    
    func numberOfSections()-> Int {
        return colorModel?.colors?.count ?? 0
    }
    
    func numberOfRowsinSections(section: Int)-> Int {
        return colorModel?.colors?[section].color?.count ?? 0
    }
    
    func cellRowatIndexPath(indexpath: IndexPath)-> ColorElements? {
        if let getObject = colorModel?.colors?[indexpath.row] {
            return getObject
        }
        return nil
    }
    func titleforHeader(section: Int) -> String? {
        if let title = colorModel?.colors?[section].color  {
            return title
        }
        return ""
    }
    
    
}
