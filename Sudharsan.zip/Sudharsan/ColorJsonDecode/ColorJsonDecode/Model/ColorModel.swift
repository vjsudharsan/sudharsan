//
//  ColorModel.swift
//  ColorJsonDecode
//
//  Created by Apple on 05/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import Foundation

struct ColorModel: Decodable {
    var colors: [ColorElements]?
}
struct ColorElements: Decodable {
    var color: String?
    var category: String?
    var type: String?
    var code: CodeElements?
}

struct CodeElements: Decodable {
    var rgba: [Int]?
    var hex: String?
}
