//
//  LoginViewController.swift
//  EmployeeInformation
//
//  Created by Apple on 22/10/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class RegisterViewController: UIViewController {
    
    var registerViewModel = RegisterViewModel()
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var phoneNumberTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = registerViewModel.pageTitle
        // Do any additional setup after loading the view.
    }
}
//
////           @IBAction func registerButtonAction(_ sender: Any) {
////
////            let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "UserListViewController") as? UserListViewController
////            self.navigationController?.pushViewController(vc!, animated: true)
    //      self.registerViewModel.registerPostAPICall()        }
//}



