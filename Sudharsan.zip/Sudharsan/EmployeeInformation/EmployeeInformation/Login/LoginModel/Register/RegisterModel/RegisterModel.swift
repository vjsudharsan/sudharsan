
import Foundation
struct RegisterModel: Decodable {
    var token: String?
    var id: Int?
}

