//
//  LoginModel.swift
//  EmployeeInformation
//
//  Created by Apple on 22/10/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
struct LoginModel: Decodable {
    var token: String?
}
