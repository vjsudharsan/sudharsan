//
//  LoginViewController.swift
//  EmployeeInformation
//
//  Created by Apple on 22/10/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    var loginViewModel = LoginViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = loginViewModel.pageTitle    }
    func initViewModel() {
        
        loginViewModel.updateLoadingStatus = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                if self.loginViewModel.isLoading {
                    // Start Animating
                } else {
                    // Stop Animating
                }
            }
        }
        loginViewModel.showAlertClosure = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                if let errorMessage = self.loginViewModel.alertMessage {
                    print(errorMessage.localizedDescription)
                }
            }
        }
        loginViewModel.reloadClosure = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "UserListViewController") as? UserListViewController
                self.navigationController?.pushViewController(vc!, animated: true)
            }
        }
        
        
    }
    @IBAction func sumbitButtonAction(_ sender: UIButton) {
      
        if let emailText =  emailTextField.text, let passwordText = passwordTextField.text {
            if emailText == "" && passwordText == "" {
                print("All Fields Are Mandatory")
            } else if emailText == "" {
                print("Enter Email")
            } else if passwordText == "" {
                print("Enter Password")
            } else if !CommonFunction().validateEmailId(emailID: emailText) {
                print("invalid email")
            } else if !CommonFunction().validatePassword(password: passwordText) {
                print("invalid password")
            }
              else {
                
            }
        }
        }
        
        
        
}

