//
//  UserListModel.swift
//  ProjectTask
//
//  Created by nschool on 21/10/20.
//

import Foundation
struct  UserListModel: Decodable {
    var page: Int?
    var per_page: Int?
    var total: Int?
    var total_pages: Int?
    var data: [DataList]?
    var ad: Ad?
    }
struct DataList: Decodable {
    var id: Int?
    var email: String?
    var first_name: String?
    var last_name: String?
    var avatar: String?
}
struct Ad: Decodable {
    var company: String?
    var url: String?
    var text: String?
}

