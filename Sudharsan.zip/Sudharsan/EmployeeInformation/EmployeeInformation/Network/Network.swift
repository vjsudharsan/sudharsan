//
//  Network.swift
//  Network
//
//  Created by Periyasamy R on 16/10/20.
//  Copyright © 2020 Periyasamy R. All rights reserved.
//

import Foundation
public protocol APIServiceCallProtocol: APIServiceProtocol {
    
    func getUserListWithService(completion: @escaping APIParsedResponse)
   func loginPostMethodAPICall(email: String, password: String, completion: @escaping APIParsedResponse)
    func registerPostMethodAPICall(completion: @escaping APIParsedResponse)
}

class Network: APIService, APIServiceCallProtocol {
    func loginPostMethodAPICall(email: String, password: String, completion: @escaping APIParsedResponse) {
        let loginParameters = "{\"email\": \"\(email)\", \"password\": \"\(password)\"}"
        let url = Constants.API.baseURL+Constants.API.login
        connectNetwork(modelType: LoginModel.self, withBaseURl: url, withParameters: loginParameters, withHttpMethod: Constants.Common.KEY_POST, withContentType: Constants.Common.CONTENTTYPE_JSON) { (code, response, error) in
            completion(code, response, error)
        }
    }
    
    func getUserListWithService(completion: @escaping APIParsedResponse) {
        connectNetwork(modelType: UserListModel.self , withBaseURl: Constants.API.getuserList, withParameters: Constants.Common.kEmptyString, withHttpMethod:Constants.Common.KEY_GET, withContentType: Constants.Common.CONTENTTYPE_URL_ENCODE) { (code, response, error) in completion(code,response,error)
            
        }
       }
    func registerPostMethodAPICall(completion: @escaping APIParsedResponse) {
        let registerParameters = "{\"email\": \"eve.holt@reqres.in\", \"password\": \"pistol\"}"
        let url = Constants.API.baseURL+Constants.API.register
        connectNetwork(modelType: RegisterModel.self, withBaseURl: url, withParameters: registerParameters, withHttpMethod: Constants.Common.KEY_POST, withContentType: Constants.Common.CONTENTTYPE_JSON) { (code, response, error) in
            completion(code, response, error)
        }
    }
}
