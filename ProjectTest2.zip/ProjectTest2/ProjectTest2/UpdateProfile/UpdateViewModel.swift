import Foundation
class UpdateViewModel {
    var update = UpdateModel()
    var emptyString = ""
    var reloadClosure: (() -> ())?
    
    var updateModel: UpdateModel? {
        didSet {
            self.reloadClosure?()
        }
    }
    
    var userList: UserListData?
    var userId: String {
        return userList?.UserId ?? emptyString
    }
    var first_name: String {
        return userList?.firstname ?? emptyString
    }
    var last_name: String {
        return userList?.lastname ?? emptyString
    }
    var mobile_Number: String {
        return userList?.mobile ?? emptyString
    }
    var email_Id: String {
        return userList?.email ?? emptyString
    }
    func apiUpdatePostMethodCall(firstname: String?, lastName: String?, email: String?, mobilenumber: String?) {
        let params = ["firstname": firstname,"lastName": lastName, "email": email, "mobileNumber": mobilenumber] as Dictionary<String, Any>
           var request = URLRequest(url: URL(string: "http://demo.smartstorez.com/TESTAPI/UserUpdateProfile")!)
           request.httpMethod = "POST"
           request.httpBody = try? JSONSerialization.data(withJSONObject: params, options: [])
           request.addValue("application/json", forHTTPHeaderField: "Content-Type")
           let session = URLSession.shared
           let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
               print(response!)
               do {
                   let json = try JSONSerialization.jsonObject(with: data!) as! Dictionary<String, AnyObject>
                   print(json)
                self.updateModel = self.update
                   DispatchQueue.main.async {
                     // your code here
                    
                   }
               } catch {
                   print("error")
               }
           })
           task.resume()
       }
    
//    func apiUpdatePostMethodCall(firstname: String?, lastName: String?, email: String?, mobilenumber: String?) {
//        let params = ["firstname": firstname,"lastName": lastName, "email": email, "mobileNumber": mobilenumber] as Dictionary<String, Any>
//        let url = URL(string: "http://demo.smartstorez.com/TESTAPI/UserUpdateProfile")!
//        var request = URLRequest(url: url)
//        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
//        request.httpMethod = "POST"
//        request.httpBody = params.percentEncoded()
//        let task = URLSession.shared.dataTask(with: request) { data, response, error in
//            guard let data = data,
//                  let response = response as? HTTPURLResponse,
//                  error == nil else {                                              // check for fundamental networking error
//                print("error", error ?? "Unknown error")
//                return
//            }
//            guard (200 ... 299) ~= response.statusCode else {                    // check for http errors
//                print("statusCode should be 2xx, but is \(response.statusCode)")
//                print("response = \(response)")
//
//                return
//            }
//             let responseString = String(data: data, encoding: .utf8)
//              print("responseString = \(responseString)")
//            do {
//                let jsonDecoder = JSONDecoder()
//                let responseModel = try jsonDecoder.decode(UpdateModel.self, from: data)
//                print(responseModel)
//                self.updateModel = responseModel
//                DispatchQueue.main.async {
//
//                }
//            } catch {
//                print("JSON Serialization error")
//            }
//        }
//        task.resume()
//    }
}
