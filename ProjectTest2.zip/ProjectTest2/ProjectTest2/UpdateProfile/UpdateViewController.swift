//
//  UpdateViewController.swift
//  ProjectTest2
//
//  Created by nschool on 03/12/20.
//

import UIKit

class UpdateViewController: UIViewController {
    
    @IBOutlet weak var textFieldfirstName: UITextField!
    @IBOutlet weak var textFieldlastName: UITextField!
    @IBOutlet weak var textFieldEmail: UITextField!
    @IBOutlet weak var textFieldMobileNumber: UITextField!
    var updateViewModel = UpdateViewModel()
   
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "UPDATE DETAILES"
        textFieldfirstName.text = updateViewModel.first_name
        textFieldlastName.text = updateViewModel.last_name
        textFieldEmail.text = updateViewModel.email_Id
        textFieldMobileNumber.text = updateViewModel.mobile_Number
        initViewModel()
        
    }
    
    func initViewModel() {
        updateViewModel.reloadClosure = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.navigationToUserViewController()
            }
        }
        
    }
    
    func navigationToUserViewController() {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "UserListViewController") as? UserListViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    
    
    
    
    @IBAction func buttonActionUpdate(_ sender: Any) {
        if let firstName = textFieldfirstName.text , let lastName = textFieldlastName.text, let email = textFieldEmail.text, let mobile = textFieldMobileNumber.text {
            self.updateViewModel.apiUpdatePostMethodCall(firstname: firstName, lastName: lastName, email: email, mobilenumber: mobile)
        }
        
        
    }
    
    
    
}
