//
//  UpdateModel.swift
//  ProjectTest2
//
//  Created by nschool on 03/12/20.
//


import Foundation
struct UpdateModel: Decodable {
    var message: String?
    var status: Int?
    var data: Int?
}
