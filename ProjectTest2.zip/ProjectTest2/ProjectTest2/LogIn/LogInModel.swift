//
//  LogInModel.swift
//  ProjectTest2
//
//  Created by nschool on 03/12/20.
//
import Foundation
struct LoginModel: Decodable {
    var message: String?
    var status: Int?
    var data: DataList?
}
struct DataList: Decodable {
    var UserId: String?
    var firstname: String?
    var lastname: String?
    var mobile: String?
    var email: String?
}

