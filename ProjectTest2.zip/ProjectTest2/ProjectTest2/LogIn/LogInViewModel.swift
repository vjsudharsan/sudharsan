//
//  LoginViewModel.swift
//  PracticalProject
//
//  Created by nschool on 01/12/20.
//

import Foundation
class LoginViewModel {
    var reloadClosure: (() -> ())?
    var login: LoginModel?
    var loginModel: LoginModel? {
        didSet {
            self.reloadClosure?()
        }
    }
    func apiPostCall(email: String, password: String) {
           let params = ["email": email, "password": password] as Dictionary<String, String>
           var request = URLRequest(url: URL(string: "http://demo.smartstorez.com/TESTAPI/UserLogin")!)
           request.httpMethod = "POST"
           request.httpBody = try? JSONSerialization.data(withJSONObject: params, options: [])
           request.addValue("application/json", forHTTPHeaderField: "Content-Type")
           let session = URLSession.shared
           let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
               print(response!)
               do {
                   let json = try JSONSerialization.jsonObject(with: data!) as! Dictionary<String, AnyObject>
                   print(json)
                self.loginModel = self.login
                   DispatchQueue.main.async {
                     // your code here
                   }
               } catch {
                   print("error")
               }
           })
           task.resume()
       }
    
//    func apiPostMethodCall(email: String  , password: String) {
//        let params = ["email": email, "password": password] as Dictionary<String, Any>
//        let url = URL(string: "http://demo.smartstorez.com/TESTAPI/UserLogin")!
//        var request = URLRequest(url: url)
//        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
//        request.httpMethod = "POST"
//        request.httpBody = params.percentEncoded()
//        let task = URLSession.shared.dataTask(with: request) { data, response, error in
//            guard let data = data,
//                  let response = response as? HTTPURLResponse,
//                  error == nil else {                                              // check for fundamental networking error
//                print("error", error ?? "Unknown error")
//                return
//            }
//            guard (200 ... 299) ~= response.statusCode else {                    // check for http errors
//                print("statusCode should be 2xx, but is \(response.statusCode)")
//                print("response = \(response)")
//                return
//            }
////            let responseString = String(data: data, encoding: .utf8)
////                print("responseString = \(responseString)")
//            do {
//                let jsonDecoder = JSONDecoder()
//                let responseModel = try jsonDecoder.decode(LoginModel.self, from: data)
//                print(responseModel)
//                self.loginModel = responseModel
//                DispatchQueue.main.async {
//                  // your code here
////                    self.activityView.isHidden = true
////                    self.activity.stopAnimating()
//                }
//            } catch {
//                print("JSON Serialization error")
//            }
//        }
//        task.resume()
//    }
//}
//extension Dictionary {
//    func percentEncoded() -> Data? {
//        return map { key, value in
//            let escapedKey = "\(key)".addingPercentEncoding(withAllowedCharacters: .urlQueryValueAllowed) ?? ""
//            let escapedValue = "\(value)".addingPercentEncoding(withAllowedCharacters: .urlQueryValueAllowed) ?? ""
//            return escapedKey + "=" + escapedValue
//        }
//        .joined(separator: "&")
//        .data(using: .utf8)
//    }
//}
//
//extension CharacterSet {
//    static let urlQueryValueAllowed: CharacterSet = {
//        let generalDelimitersToEncode = ":#[]@" // does not include "?" or "/" due to RFC 3986 - Section 3.4
//        let subDelimitersToEncode = "!$&'()*+,;="
//
//        var allowed = CharacterSet.urlQueryAllowed
//        allowed.remove(charactersIn: "\(generalDelimitersToEncode)\(subDelimitersToEncode)")
//        return allowed
//    }()
}


