//
//  LogInViewController.swift
//  ProjectTest2
//
//  Created by nschool on 03/12/20.
//

import UIKit

class LogInViewController: UIViewController {
    var loginViewModel = LoginViewModel()
    
    @IBOutlet weak var emailTextfield: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initViewModel()
        let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
            backgroundImage.image = UIImage(named: "backgroundImage")
        backgroundImage.contentMode = UIView.ContentMode.scaleAspectFill
            self.view.insertSubview(backgroundImage, at: 0)

        // Do any additional setup after loading the view.
    }
    func initViewModel() {
        loginViewModel.reloadClosure = { [weak self] in
            guard let self = self else {return}
            DispatchQueue.main.async {
         self.navigationToUserViewController()
               
            }
        }
    }
    func navigationToUserViewController() {
        print("success")
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "UserListViewController") as? UserListViewController
        self.navigationController?.pushViewController(vc!, animated: true)
   }
    
    @IBAction func logInButtonActtion(_ sender: Any) {
        if let email = emailTextfield.text, let password = passwordTextField.text
        {
            if email == "" && password == "" {
                print("All fields are Mandatory")
            }
            else if email == "" {
                    print("Enter email")
            } else if password == "" {
                print("Enter password")
               
            } else {
               // self.loginViewModel.apiPostMethodCall(email: email  , password: password)
                self.loginViewModel.apiPostCall(email: email, password: password)
               
            }
        }
    }
    @IBAction func newRegisterButtonAction(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "RegisterViewController") as? RegisterViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    @IBAction func forgotPsswordButtonAction(_ sender: Any) {
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
