//
//  RegisterViewController.swift
//  ProjectTest2
//
//  Created by nschool on 03/12/20.
//

import UIKit

class RegisterViewController: UIViewController {
    var registerViewModel = RegisterViewModel()
    
    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var mobileNumberTextField: UITextField!
    @IBOutlet weak var emailIdTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "REGISTER"
        self.initViewModel()
    }
    
    func initViewModel() {
        registerViewModel.reloadClosure = { [weak self] in
            guard let self = self else {return}
            DispatchQueue.main.async {
         self.navigationToUserViewController()
            }
        }
    }
    func navigationToUserViewController() {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "UserListViewController") as? UserListViewController
        self.navigationController?.pushViewController(vc!, animated: true)
   }
    
    
    @IBAction func registerButtonAction(_ sender: Any) {
        
        if let firstName = firstNameTextField.text, let lastName = lastNameTextField.text, let emailId = emailIdTextField.text, let password = passwordTextField.text, let mobileNumber = mobileNumberTextField.text {
            if firstName == "" && lastName == "" && mobileNumber == "" && emailId == "" && password == "" {
                print("All Fields Are Mandatory")
            }
            else if firstName == "" {
                print("enter first name")
            }
            else if lastName == "" {
                print("enter last name")
            }
            else if mobileNumber == "" {
                print("enter mobileNumber")
            }
            else if emailId == "" {
                print("enter email")
            }
            else if password == ""
            {
                print("enter password")
            }
            else if !CommonFunction().validateFirstName(name: firstName) {
                print("Please Enter Valid First Name")
            } else if !CommonFunction().validateLastName(name: lastName) {
                print("Please Enter Valid LastName")
            } else if !CommonFunction().validateEmailId(emailID: emailId) {
                print("Please Enter Valid Email")
            } else if !CommonFunction().validatePhoneNumber(phoneNumber: mobileNumber) {
                print("Please Enter Valid Mobile Number")
            }else {
                self.registerViewModel.apiPostCall(firstname: firstName, lastname: lastName, mobilenumber: mobileNumber, email: emailId, password: password)
                //self.registerViewModel.postMethod(firstName: firstName, lastName: lastName, mobileNumber: mobileNumber, email: emailId, password: password)
                
            }
        }
    }
}
//EXTENSION TEXTFIELDDELAGATE
extension RegisterViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == firstNameTextField {
            firstNameTextField.resignFirstResponder()
            lastNameTextField.becomeFirstResponder()
        } else if textField == lastNameTextField {
            lastNameTextField.resignFirstResponder()
            mobileNumberTextField.becomeFirstResponder()
        } else if textField == mobileNumberTextField {
            mobileNumberTextField.resignFirstResponder()
            emailIdTextField.becomeFirstResponder()
        } else if textField == emailIdTextField {
            emailIdTextField.resignFirstResponder()
            passwordTextField.becomeFirstResponder()
        } else {
            passwordTextField.resignFirstResponder()
        }
        return true
    }
}

//EXTENSION DONE,CANCEL TOOLBAR
//extension UITextField {
//
//    func addDoneCancelToolbar(onDone: (target: Any, action: Selector)? = nil, onCancel: (target: Any, action: Selector)? = nil) {
//        let onCancel = onCancel ?? (target: self, action: #selector(cancelButtonTapped))
//        let onDone = onDone ?? (target: self, action: #selector(doneButtonTapped))
//        let toolbar: UIToolbar = UIToolbar()
//        toolbar.barStyle = .default
//        toolbar.items = [
//            UIBarButtonItem(title: "Cancel", style: .plain, target: onCancel.target, action: onCancel.action),
//            UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: self, action: nil),
//            UIBarButtonItem(title: "Done", style: .done, target: onDone.target, action: onDone.action)
//        ]
//        toolbar.sizeToFit()
//        self.inputAccessoryView = toolbar
//    }
//
//    // Default actions:
//    @objc func doneButtonTapped() { self.resignFirstResponder() }
//    @objc func cancelButtonTapped() { self.resignFirstResponder() }
//
//}
