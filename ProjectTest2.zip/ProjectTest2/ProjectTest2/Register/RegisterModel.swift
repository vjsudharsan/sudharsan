//
//  RegisterModel.swift
//  PracticalProject
//
//  Created by nschool on 01/12/20.
//

import Foundation

struct  RegisterModel: Decodable {
    var message: String?
    var status: Int?
    var data: String?
}
struct RegisterData: Decodable {
    var UserId: Int?
    var Username: String?
}
