//
//  UserListViewController.swift
//  ProjectTest2
//
//  Created by nschool on 03/12/20.
//

import UIKit

class UserListViewController: UIViewController {
    
    @IBOutlet weak var UserListTable: UITableView!
    var userListViewModel = UserListViewModel()
    var userListCellidentfier = "UserListTableViewCell"
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initViewModel()
        
        // Do any additional setup after loading the view.
    }
    func initViewModel() {
        userListViewModel.reloadClosure = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.UserListTable.reloadData()
            }
        }
        self.userListViewModel.getMethod()
    }
}
extension UserListViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return userListViewModel.numberOfSection
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userListViewModel.numberOfRowsInSctions
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UserListTable.dequeueReusableCell(withIdentifier: userListCellidentfier) as! UserListTableViewCell
        if let dataObject = userListViewModel.getObject(indexpath: indexPath) {
            cell.labelUser.text = dataObject.UserId
            cell.labelFirstName.text = dataObject.firstname
            cell.labelLastName.text = dataObject.lastname
            cell.labelEmail.text = dataObject.email
            cell.labelMobileNumber.text = dataObject.mobile
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let userDetails = self.userListViewModel.getObject(indexpath: indexPath)
        if let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "UpdateViewController") as? UpdateViewController {
            vc.updateViewModel.userList = userDetails
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
}

