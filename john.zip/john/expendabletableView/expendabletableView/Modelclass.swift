//
//  Modelclass.swift
//  expendabletableView
//
//  Created by Apple on 07/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

//import Foundation
//
//struct clubs {
//    var clubname: String?
//    var clubimage: String?
//    var members: [members]?
//}
//
//struct members {
//    var playername: String?
//    var fcname: String?
//    var goals: String?
//    var image: String?
//}
