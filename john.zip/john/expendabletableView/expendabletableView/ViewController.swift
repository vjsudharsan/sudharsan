//
//  ViewController.swift
//  expendabletableView
//
//  Created by Apple on 07/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var cellIdentifier = "FirstTableViewCell"
    @IBOutlet weak var myTableView: UITableView!
    var collapseHandlerArray = [String]()
    
    let section = ["1", "2", "3", "4", "5"]
    
    let sectionItems = [["one", "two", "three"], ["one", "two", "three"], ["one", "two", "three"], ["one", "two", "three"],["one", "two", "three"]]
    let imageItems = [["albino", "arsenal", "di maria"], ["iniesta", "kaka", "ramos"], ["ronaldo", "santi", "sunil"],["albino", "arsenal", "di maria"],["ronaldo", "santi", "sunil"] ]
    let sectionImage = [["arsenal"], ["liverpool"], ["barcelona"], ["juventus"], ["liverpool"]]
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.myTableView.tableFooterView = UIView()
        self.tablesetup()
//        // Do any additional setup after loading the view, typically from a nib.
        
//
//        let football = clubs(clubname:"JUVENTUS", clubimage: "juventus", members:[members(playername: "DYBALA", fcname: "AC Milan", goals: "123", image: "dybala"), members(playername: "RONALDO", fcname: "REAL MADRID ", goals:"23", image: "ronaldo"), members(playername: "DI - MARIA", fcname: "ATK", goals: "53", image: "di maria"), members(playername: "MBAPPEE", fcname: "PSG", goals:"47", image: "mbappe")])
//
//        //soccer = football
//
//        let football1 = clubs(clubname: " BARCELONA", clubimage: "barcelona", members: [members(playername: "KAKA", fcname: "ARSENAL", goals:" 54", image: "kaka"), members(playername: " DAVID LUIZ", fcname: "CHELSEA", goals:"52", image: "david luiz"), members(playername: "MESSI", fcname: "LIVERPOOL", goals: "96", image: "messi"), members(playername: "SANTIAGO", fcname: "BAYERN MUNICH ", goals: "143", image: "santi")])
//
//        //soccer1 = football1
//
//        let football2 = clubs(clubname: "LIVERPOOL", clubimage: "liverpool", members:[members(playername: "SERGIO RAMOS", fcname: "CHILIE", goals: "78", image: "ramos"), members(playername: "ZLATAN", fcname: "SWEDEN FC", goals: "99", image: "zlatan"), members(playername: "ALBINO GOMEZ ", fcname: "INDIA FC", goals:"83", image: "albino"), members(playername: "OGBECHEZH", fcname: " NYGERIA FC", goals:"78", image: "ogbeche")])
//
//        //soccer2 = football2
//
//
//        let football3 = clubs(clubname: "ARSENAL", clubimage: "arsenal",members:[members(playername: "NEYMAR", fcname:"BRAZIL FC", goals: "45", image: "neymar"), members(playername: "SUNIL CHETTRI", fcname: "INDIA FC", goals: "74", image: "sunil"), members(playername: "INIESTA", fcname:"ENGLISH FC", goals: "95", image: "iniesta"), members(playername: "GAVANI", fcname: "FC GOA", goals: "89", image: "cavani")])
//
//        soccer = [football, football2, football1, football3]

    }
    func tablesetup(){
        myTableView.estimatedRowHeight = 500
        myTableView.dataSource = self
        myTableView.delegate = self
        myTableView.separatorColor = .none
        myTableView.separatorStyle = .singleLine
        myTableView.tableFooterView = UIView()
        myTableView.register(FirstTableViewCell.self, forCellReuseIdentifier: cellIdentifier)
        
        
    }


}
extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
      return section.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.collapseHandlerArray.contains(self.section[section]){
            return sectionItems[section].count
        }else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = myTableView.dequeueReusableCell(withIdentifier: "cellIdentifier", for: indexPath as IndexPath) as! FirstTableViewCell
        cell.clubNameLabel.text = sectionItems[indexPath.section][indexPath.row]
        cell.playerNameLabel.text = sectionItems[indexPath.section][indexPath.row]
        cell.priceTagLabel.text = sectionItems[indexPath.section][indexPath.row]
        cell.imageLayer.image = UIImage(named: imageItems[indexPath.section][indexPath.row] as! String)
        cell.layer.cornerRadius = 2.0
        cell.layer.borderWidth = 3.0
        cell.layer.borderColor = UIColor.black.cgColor
        cell.accessoryType = .detailButton
        return cell
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 80
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerview = UIView()
        let headerLabel = UILabel()
       
        headerLabel.text = self.section[section]
        headerLabel.textAlignment = .center
        headerLabel.numberOfLines = 0
        headerLabel.textColor = .black
        headerLabel.lineBreakMode = .byWordWrapping
        headerLabel.frame = CGRect(x:20, y: 0, width: self.view.frame.width-40, height: 80)
        headerview.addSubview(headerLabel)
        
        let headerImage = UIImageView()
//        headerImage.image = UIImage(named: sectionImage[section] as! String)
        headerImage.frame = CGRect(x: 75, y: 0, width:80, height:80)
        headerview.addSubview(headerImage)
        return headerview
        
        let headerButton = UIButton()
        headerButton.tag = section
        if self.collapseHandlerArray.contains(self.section[section]) {
            headerButton.setTitle("HIDE", for: .normal)
        } else {
            headerButton.setTitle("SHOW", for: .normal)
        }
        
        headerview.addSubview(headerButton)
        return headerButton
    }
    
    
    
    @objc func sectionButtonAction(sender: UIButton) {
        if let buttonTitle = sender.title(for: .normal) {
           if buttonTitle == "SHOW"{
                self.collapseHandlerArray.append(self.section[sender.tag])
            sender.setTitle("HIDE", for: .normal)
           } else {
            while self.collapseHandlerArray.contains(self.section[sender.tag]) {
                if let itemToRemoveIndex = self.collapseHandlerArray.index(of: self.section[sender.tag]) {
                    self.collapseHandlerArray.remove(at: itemToRemoveIndex)
                    sender.setTitle("SHOW", for: .normal)
                }
            }
            }
        }
        
        self.myTableView.reloadSections(IndexSet(integer: sender.tag), with: .none)
    }
    

}

