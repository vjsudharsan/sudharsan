//
//  FirstTableViewCell.swift
//  expendabletableView
//
//  Created by Apple on 07/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import UIKit

class FirstTableViewCell: UITableViewCell {
    @IBOutlet weak var imageLayer: UIImageView!
    @IBOutlet weak var playerNameLabel: UILabel!
    @IBOutlet weak var clubNameLabel: UILabel!
    @IBOutlet weak var priceTagLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
