//
//  ProfileViewController.swift
//  FinalProjectNschool
//
//  Created by Apple on 25/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var imageLayer: UIImageView!
    @IBOutlet weak var firstTextField: UITextField!
    @IBOutlet weak var lastTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var phoneTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var submitButton: UIButton!
    @IBOutlet weak var logoutButton: UIButton!
    
    
    var profileViewModel = ProfileViewModel()
    var userViewController = UserListViewController()
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = " PROFILE "
        self.initViewModel()
        
        firstTextField.text = profileViewModel.firstname
        lastTextField.text = profileViewModel.lastname
        emailTextField.text = profileViewModel.email
        phoneTextField.text = profileViewModel.mobile
        passwordTextField.text = profileViewModel.UserId
        
        // Do any additional setup after loading the view.
    }
    
    
    func initViewModel() {
        profileViewModel.reloadClosure = { [weak self] in
            guard let self = self else {return}
            DispatchQueue.main.async {
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
    
    
    @IBAction func submitButtonAction(_ sender: UIButton) {
        if let first = firstTextField.text, let last = lastTextField.text, let mobile = phoneTextField.text, let userid = passwordTextField.text {
            if first == "" && last == "" && mobile == "" {
                print("all fileds should be filled")
                self.showAlertMessageWithTitle(title: "INFO", message: "No field Should Be Empty")
            }
            else if first == "" {
                print("Enter the First Name")
                self.showAlertMessageWithTitle(title: "INFO", message: "Enter the First Name")
            }
            else if last == "" {
                print("Enter the Last Name")
                self.showAlertMessageWithTitle(title: "INFO", message: "Enter the Last Name")
            }
            else if mobile == "" {
                print("Enter the Mobile number")
                self.showAlertMessageWithTitle(title: "INFO", message: "Enter the Mobile Number")
            }
            else if !Constants().validateFirstName(name: first) {
                print("Enter a valid first Name")
                self.showAlertMessageWithTitle(title: "ALERT", message: "Enter a valid First Name")
            } else if !Constants().validateLastName(name: last) {
                print("Enter a valid last Name")
                self.showAlertMessageWithTitle(title: "ALERT", message: "Enter a Valid last Name")
            }
            else if !Constants().validatePhoneNumber(phoneNumber: mobile) {
                print("Enter a valid mobile number")
                self.showAlertMessageWithTitle(title: "ALERT", message: "Enter a valid Mobile Number")
            } else {
                self.profileViewModel.apiPostCall(UserId: userid, firstname: first, lastname: last, mobile: mobile)
                
                
                
            }
        }
        
        
    }
    
    @IBAction func logoutButtonAction(_ sender: UIButton) {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController
        self.navigationController?.pushViewController(vc!, animated: true)
        //
        //        self.navigationController?.popToRootViewController(animated: true)
        
        
    }
    //
    //    func navigateToUserList() {
    //        print("Details updated Sucessfully")
    //
    //        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "UserListViewController") as? UserListViewController
    //        self.navigationController?.pushViewController(vc!, animated: true)
    //
    //    }
    
    func showAlertMessageWithTitle(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
        
    }
    
    
    
}
extension ProfileViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == firstTextField {
            firstTextField.resignFirstResponder()
            lastTextField.becomeFirstResponder()
        } else if textField == lastTextField {
            lastTextField.resignFirstResponder()
            emailTextField.becomeFirstResponder()
        } else if textField == emailTextField {
            emailTextField.resignFirstResponder()
            phoneTextField.becomeFirstResponder()
        } else if textField == phoneTextField {
            phoneTextField.resignFirstResponder()
            passwordTextField.becomeFirstResponder()
        } else if textField == passwordTextField {
            passwordTextField.resignFirstResponder()
        }
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        var maxLength: Int?
        
        let CurrentString: NSString = textField.text! as NSString
        if textField == firstTextField {
            maxLength = 20
        }
        if textField == lastTextField {
            maxLength = 20
        }
        if textField == phoneTextField {
            maxLength = 10
        }
        if textField ==  passwordTextField {
            maxLength = 16
        }
        
        
        let newString: NSString =
            CurrentString.replacingCharacters(in: range, with: string) as NSString
        return newString.length <= maxLength ?? 0
    }
}
