//
//  ProfileModel.swift
//  FinalProjectNschool
//
//  Created by Apple on 25/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import Foundation
struct ProfileModel: Decodable {
    var message: String?
    var status: Int?
    var data: Int?
}
