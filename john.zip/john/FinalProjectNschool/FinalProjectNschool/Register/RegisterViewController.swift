//
//  RegisterViewController.swift
//  FinalProjectNschool
//
//  Created by Apple on 25/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import UIKit

class RegisterViewController: UIViewController {
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var firstLabel: UILabel!
    @IBOutlet weak var firstTextField: UITextField!
    @IBOutlet weak var lastLabel: UILabel!
    @IBOutlet weak var lastTextField: UITextField!
    @IBOutlet weak var phoneLabel: UILabel!
    @IBOutlet weak var phoneTextField: UITextField!
    @IBOutlet weak var mailLabel: UILabel!
    @IBOutlet weak var mailTextField: UITextField!
    @IBOutlet weak var passwordLabel: UILabel!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var backgroundLayer: UIImageView!
    @IBOutlet weak var submitButton: UIButton!
    
    
    var registerViewModel = RegisterViewModel()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = " REGISTER "
        self.initViewModel()
        
        // Do any additional setup after loading the view.
        self.passwordTextField.isSecureTextEntry = true
        submitButton.layer.cornerRadius = 10
        
    }
    func initViewModel() {
        registerViewModel.reloadClosure = { [weak self] in
            guard let self = self else {return}
            DispatchQueue.main.async {
                self.navigationToUserListView()
                
                
            }
        }
    }
    
    func navigationToUserListView() {
        print("Registered Successfully")
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "UserListViewController") as? UserListViewController
        self.navigationController?.pushViewController(vc!, animated: true)
        
    }
    
    
    @IBAction func submitButtonAction(_ sender: UIButton) {
        
        if let firstName = firstTextField.text, let lastName = lastTextField.text, let phoneNumber = phoneTextField.text, let email = mailTextField.text, let password = passwordTextField.text {
            if firstName == "" && lastName == "" && phoneNumber == "" && email == "" &&  password == "" {
                print("All Fields are Mandatory")
                self.ShowAlertWithTitle(title: "INFO", message: " All Fields are Mandatory")
            } else if firstName == "" {
                print("Enter the first Name")
                self.ShowAlertWithTitle(title: "INFO", message: "Enter the First Name")
            } else if lastName == "" {
                print("Enter the last name")
                self.ShowAlertWithTitle(title: "INFO", message: "Enter the Last Name")
            } else if phoneNumber == "" {
                print("Enter the phone number ")
                self.ShowAlertWithTitle(title: "INFO", message: "Enter the Phone Number")
            } else if email == "" {
                print(" Enter the email id")
                self.ShowAlertWithTitle(title: "INFO", message: "Enter the Email ID")
            } else if password == "" {
                print(" Enter the Password")
                self.ShowAlertWithTitle(title: "INFO", message: "Enter the Password")
            } else if !Constants().validateFirstName(name: firstName) {
                print(" Please enter the valid first name ")
                self.ShowAlertWithTitle(title: " ALERT ", message: "Please Enter a Valid First Name (Min 4 chars and Max 20 chars)")
            } else if !Constants().validateLastName(name: lastName){
                print("please enter the valid last name")
                self.ShowAlertWithTitle(title: "Alert", message: "Please Enter a Valid Last Name (Min 1 char and Max 20 chars)")
            } else if !Constants().validatePhoneNumber(phoneNumber: phoneNumber) {
                print("Please enter the valid phone number")
                self.ShowAlertWithTitle(title: "Alert", message: "Please Enter a Valid Mobile Number ")
            } else if !Constants().isValidEmail(email: email) {
                print("please enter valid email")
                self.ShowAlertWithTitle(title: "Alert", message: "Please Enter a valid Email ID")
            } else if !Constants().validatePassword(password: password){
                print("please enter valid password")
                self.ShowAlertWithTitle(title: "Alert", message: "Please Enter a valid Password (Min 8 chars should contain atleast 2 numeric chars)")
            } else {
                self.registerViewModel.apiPostCall(firstname: firstName, lastName: lastName, phone: phoneNumber, email: email, password: password)
                
            }
            
            
        }
        
        
    }
    func ShowAlertWithTitle(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style:.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    
}





extension RegisterViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == firstTextField {
            firstTextField.resignFirstResponder()
            lastTextField.becomeFirstResponder()
        } else if textField == lastTextField {
            lastTextField.resignFirstResponder()
            phoneTextField.becomeFirstResponder()
        } else if textField == phoneTextField {
            phoneTextField.resignFirstResponder()
            mailTextField.becomeFirstResponder()
        } else if textField == mailTextField {
            mailTextField.resignFirstResponder()
            passwordTextField.becomeFirstResponder()
        } else if textField == passwordTextField {
            passwordTextField.resignFirstResponder()
        }
        return true
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        var maxLength: Int?
        let currentString: NSString = textField.text! as NSString
        
        if textField == firstTextField {
            maxLength = 20
        }
        if textField == lastTextField {
            maxLength = 20
        }
        if textField == phoneTextField {
            maxLength = 10
        }
        if textField == mailTextField {
            maxLength = 25
        }
        if textField == passwordTextField {
            maxLength = 16
        }
        
        
        let newString: NSString =
            currentString.replacingCharacters(in: range, with: string) as NSString
        return newString.length <= maxLength ?? 0
    }
    
    
}
