//
//  RegisterModel.swift
//  FinalProjectNschool
//
//  Created by Apple on 25/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import Foundation
struct RegisterModel: Decodable {
    var message: String?
    var status: Int?
    var data: SubDatas?
}
struct SubDatas: Decodable {
    var UserId: Int?
    var Username: String?
}
