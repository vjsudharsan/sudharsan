//
//  RegisterViewModel.swift
//  FinalProjectNschool
//
//  Created by Apple on 25/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import Foundation
import UIKit
class RegisterViewModel {
    
    var reloadClosure:(() -> ())?
    
    var registerModelClass: RegisterModel?{
        didSet {
            self.reloadClosure?()
        }
        
    }
    
    func apiPostCall(firstname: String, lastName: String, phone: String, email: String, password: String) {
        
        let params = ["firstname": firstname,"lastname": lastName,"mobile": phone,"email": email,"password": password] as Dictionary<String, String>
        
        var request = URLRequest(url: URL(string: "http://demo.smartstorez.com/TESTAPI/UserRegister")!)
        request.httpMethod = "POST"
        request.httpBody = try? JSONSerialization.data(withJSONObject: params, options: [])
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let session = URLSession.shared
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            print(response!)
            do {
                let json = try JSONSerialization.jsonObject(with: data!) as! Dictionary<String, AnyObject>
                print(json)
                let jsonDecoder = JSONDecoder()
                let responseModel = try jsonDecoder.decode(RegisterModel.self, from: data!)
                print(responseModel)
                self.registerModelClass = responseModel
                DispatchQueue.main.async {
                    // your code here
                }
            } catch {
                print("error")
            }
        })
        
        task.resume()
    }
    
    
    
}
