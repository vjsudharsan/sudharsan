//
//  LoginModel.swift
//  FinalProjectNschool
//
//  Created by Apple on 25/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import Foundation
struct LoginModel: Decodable {
    var message: String?
    var status: Int?
    var data: DataElements?
}

struct DataElements: Decodable {
    var UserId: String?
    var firstname: String?
    var lastname: String?
    var mobile: String?
    var email: String?
    
}
