//
//  LoginViewController.swift
//  FinalProjectNschool
//
//  Created by Apple on 25/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet weak var backgroundLayer: UIImageView!
    @IBOutlet weak var logoLayer: UIImageView!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var passwordLabel: UILabel!
    @IBOutlet weak var emailTextField:UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var newUserButton: UIButton!
    @IBOutlet weak var logInButton: UIButton!
    
    
    var loginViewModel = LoginViewModel()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = " LOG IN "
        self.initViewModel()
        
        // Do any additional setup after loading the view.
        
        
        self.passwordTextField.isSecureTextEntry = true
        navigationItem.hidesBackButton = true
        
        
        //        emailTextField.addTarget(self, action: #selector(LoginViewController.textFieldDidChange(_:)),for: .editingChanged)
        //        passwordTextField.addTarget(self, action: #selector(LoginViewController.textFieldDidChange(_:)), for: .editingChanged)
        
    }
    
    func initViewModel() {
        loginViewModel.reloadClosure = { [weak self] in
            guard let self = self else {return}
            DispatchQueue.main.async {
                self.navigateToUserListScreen()
            }
        }
    }
    
    //    @objc func textFieldDidChange(_ textField: UITextField) {
    //        if emailTextField.text == "" || passwordTextField.text == "" {
    //            logInButton.isEnabled = false
    //            logInButton.backgroundColor = .black
    //        }
    //        else {
    //            logInButton.isEnabled = true
    //            logInButton.backgroundColor = .red
    //        }
    //    }
    
    
    @IBAction func newUserButtonAction(sender: UIButton) {
        
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "RegisterViewController") as? RegisterViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    
    @IBAction func loginButtonAction(sender: UIButton) {
        if let email = emailTextField.text, let password = passwordTextField.text {
            if email == "" && password == "" {
                print( "All Fields Are Mandatory")
                self.showAlertsWithTitle(title: "INFO", Message: "All Fields are MAndatory")
            }
            else if email == "" {
                print("Enter the Email")
                self.showAlertsWithTitle(title: "INFO", Message: "Enter The Mail ID")
            }
            else if password == "" {
                print("Enter the Password")
                self.showAlertsWithTitle(title: "INFO", Message: "Enter The Password")
            }
            else if !Constants().isValidEmail(email: email){
                print("Enter a Valid Email")
                self.showAlertsWithTitle(title: "INFO", Message: "Enter a valid Email")
            }
            else if !Constants().validatePassword(password: password){
                print("Enter a valid password")
                self.showAlertsWithTitle(title: "INFO ", Message: "Enter a Valid Password")
            } else {
                self.loginViewModel.apiPostCall(email: email, password: password)
                
            } 
            
        }
        
    }
    
    func navigateToUserListScreen() {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "UserListViewController") as? UserListViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    func showAlertsWithTitle(title: String, Message: String) {
        
        let alert = UIAlertController(title: title, message: Message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
    }
    
}





extension LoginViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == emailTextField {
            self.emailTextField.resignFirstResponder()
            self.passwordTextField.becomeFirstResponder()
        }
        else if textField == passwordTextField {
            self.passwordTextField.resignFirstResponder()
        }
        
        return true
    }
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        var MaxLength: Int?
        
        let CurrentString: NSString = textField.text! as NSString
        if textField == emailTextField {
            MaxLength = 30
            
        }
        else if textField == passwordTextField {
            MaxLength = 16
        }
        
        let newString: NSString =
            CurrentString.replacingCharacters(in: range, with: string) as NSString
        return newString.length <= MaxLength ?? 0
    }
}

