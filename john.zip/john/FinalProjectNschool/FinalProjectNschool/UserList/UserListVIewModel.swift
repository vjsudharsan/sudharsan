//
//  UserListVIewModel.swift
//  FinalProjectNschool
//
//  Created by Apple on 25/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import Foundation
class UserListViewModel {
    
    var reloadClosures: (() -> ())?
    
    var userListModelClass: UserListModel? {
        didSet {
            self.reloadClosures?()
        }
    }
    
    func getMethod() {
        var request = URLRequest(url: URL(string: "http://demo.smartstorez.com/TESTAPI/GetUsersList")!)
        request.httpMethod = "GET"
        
        URLSession.shared.dataTask(with: request, completionHandler: {data, response, error -> Void in do {
            let jsonDecoder = JSONDecoder()
            let responseModel = try jsonDecoder.decode(UserListModel.self, from: data!)
            print(responseModel)
            self.userListModelClass = responseModel
        } catch {
            print("JSON Serialization error")
            }
            
        }).resume()
        
    }
    
    var numberOfSection: Int {
        return 1
    }
    var numberOfRowsInSection: Int {
        return userListModelClass?.data?.count ?? 0
    }
    
    func cellRowAtindexPath(indexpath: IndexPath) -> DataList? {
        if let getData = userListModelClass?.data?[indexpath.row] {
            return getData
        }
        return nil
    }
}
