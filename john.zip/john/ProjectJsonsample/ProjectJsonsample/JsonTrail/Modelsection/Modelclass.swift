//
//  Modelclass.swift
//  ProjectJsonsample
//
//  Created by Apple on 31/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
struct Modelclass: Decodable {
    var firstName: String?
    var lastName: String?
    var gender: String?
    var age: Int?
    var address: Addresselements?
    var phoneNumbers: [PhoneElements]?
}

struct Addresselements: Decodable  {
    var streetAddress: String?
    var city: String?
    var state: String?
    var postalCode: String?
}
struct  PhoneElements: Decodable {
    var type: String?
    var number: String?
}
