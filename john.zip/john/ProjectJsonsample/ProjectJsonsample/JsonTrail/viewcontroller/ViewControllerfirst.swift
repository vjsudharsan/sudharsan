//
//  ViewControllerfirst.swift
//  ProjectJsonsample
//
//  Created by Apple on 31/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class ViewControllerfirst: UIViewController {
    
    var viewModel = ViewModelsection()
    @IBOutlet weak var mytableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.setUPBundle()
        mytableView.tableFooterView = UIView()
        // Do any additional setup after loading the view.
    }
    
}
extension ViewControllerfirst: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return viewModel.numberofSection()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberofRowsinSection()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = mytableView.dequeueReusableCell(withIdentifier:cellIdentifier.reuseIdentifier) as! AlphaTableViewCell
        if let object = viewModel.cellForRow(indexPath: indexPath), let age = object.age {
            cell.firstNameLabel.text = object.firstName
            cell.lastNameLabel.text = object.lastName
            cell.genderLabel.text = object.gender
            cell.ageLabel.text = String(age)
            cell.addressLabel.text = object.address?.city
            cell.phoneNumberLabel.text = object.phoneNumbers?[indexPath.row].number
        }
        return cell
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return cellIdentifier.title
    }
}
