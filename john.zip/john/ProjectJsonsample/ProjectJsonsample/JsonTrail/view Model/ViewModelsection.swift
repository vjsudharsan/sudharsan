//
//  ViewModelsection.swift
//  ProjectJsonsample
//
//  Created by Apple on 31/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation

class ViewModelsection {
    var modelClass: Modelclass?
    
    func setUPBundle() {
        modelClass = Bundle.main.decode(Modelclass.self, from: "sampleJsonFile.json")
    }
    func numberofSection() -> Int {
        return cellIdentifier.returnCount
    }
    func numberofRowsinSection() -> Int {
        return cellIdentifier.returnCount
    }
    
    func cellForRow(indexPath: IndexPath) -> Modelclass? {
        if let object = modelClass {
            return object
        }
        return nil
    }
}
