//
//  commondetails.swift
//  ProjectJsonsample
//
//  Created by Apple on 31/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
struct cellIdentifier {
    static let reuseIdentifier = "AlphaTableViewCell"
    static let returnCount = 1
    static let title = "DETAILS"
}
