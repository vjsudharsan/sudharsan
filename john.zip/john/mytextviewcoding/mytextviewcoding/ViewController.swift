//
//  ViewController.swift
//  mytextviewcoding
//
//  Created by Apple on 07/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    lazy var FirstTextView: UITextView = {
        var textView = UITextView()
        //        textView = UITextView(frame: CGRect(x: 20.0, y: 90.0, width: 250.0, height: 100.0))
        //        self.automaticallyAdjustsScrollViewInsets = false
        //        textView.backgroundColor = UIColor(red: 39/255, green: 53/255, blue: 182/255, alpha: 1)
        //        textView.center = self.view.center
        textView.textAlignment = NSTextAlignment.natural
        textView.backgroundColor = UIColor.white
        textView.font = UIFont.systemFont(ofSize: 20)
        textView.textColor = UIColor.black
        textView.text = "hi, i am sanjeev rajan, my adress 1/2, 23c, anna nagar erode. My phone number: +91 8956423568, and visit my web page www.google.com"
        textView.autocapitalizationType = UITextAutocapitalizationType.sentences
        //        textView.font = UIFont.boldSystemFont(ofSize: 20)
        //        textView.font = UIFont(name: "Verdana", size: 17)
        textView.isSelectable = true
        textView.isEditable = false
        textView.dataDetectorTypes = UIDataDetectorTypes.all
        textView.layer.cornerRadius = 10
        textView.keyboardType = .default
        textView.returnKeyType = .default
        textView.layer.borderWidth = 5.0
        textView.autocorrectionType = UITextAutocorrectionType.yes
        textView.spellCheckingType = UITextSpellCheckingType.yes
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.layer.borderColor = UIColor.gray.cgColor
        
        
        
        return textView
        
        
        
        
        
        
        
        
        
        
    }()
    
    lazy var ButtonSend: UIButton = {
        let SendButton = UIButton()
        SendButton.setTitle("SEND" , for: .normal)
        SendButton.setTitleColor(.white, for: .normal)
        SendButton.backgroundColor = .black
        SendButton.layer.cornerRadius = 40.0
        SendButton.translatesAutoresizingMaskIntoConstraints = false
        SendButton.layer.borderWidth = 5.0
        SendButton.layer.borderColor = UIColor.gray.cgColor
        return SendButton
    }()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setup()
        self.createButton()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    func setup() {
        self.view.addSubview(FirstTextView)
        self.view.addSubview(ButtonSend)
        FirstTextView.delegate = self
        
        NSLayoutConstraint.activate([FirstTextView.leadingAnchor.constraint(equalTo:self.view.leadingAnchor, constant: 20), FirstTextView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20), FirstTextView.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 25),FirstTextView.bottomAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.bottomAnchor, constant: -500)])
        
        
        NSLayoutConstraint.activate([ButtonSend.topAnchor.constraint(equalTo: self.FirstTextView.bottomAnchor, constant: 20), ButtonSend.widthAnchor.constraint(equalToConstant: 80), ButtonSend.heightAnchor.constraint(equalToConstant: 80), ButtonSend.centerXAnchor.constraint(equalTo: self.view.centerXAnchor)])
        
    }
    func createButton() {
        ButtonSend.addTarget(self, action: #selector(sendButtonAction(_:)), for: .touchUpInside)
        
    }
    
    @objc func sendButtonAction(_ sender: UIButton?) {
        print("submitted sucessfully")
        print(FirstTextView.text)
        guard let text = FirstTextView.text else {
            return
        }
        print(text)
    }
}


//
//extension ViewController: UITextViewDelegate {
//    func textViewDidChange(_ textView: UITextView) {
//        print(textView.text);
//    }
//
//    func textViewDidBeginEditing(_ textView: UITextView) {
//        print("editing beginned")
//    }
//    func textViewDidEndEditing(_ textView: UITextView) {
//        print("editing finished")
//    }
//
//    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
//
//        if(text == "\n"){
//            textView.resignFirstResponder()
//            return false
//        }
//        return true
//    }
//}


extension ViewController: UITextViewDelegate {
    func textViewDidChange(_ textView: UITextView) {
        print(textView.text);
    }
    func textViewDidBeginEditing(_ textView: UITextView) {
            print("editing beginned")
    }
    func textViewDidEndEditing(_ textView: UITextView) {
            print("editing finished")
    }
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        let newText = (textView.text as NSString).replacingCharacters(in: range, with: text)
        return newText.count <= 200
        if (text == "\n") {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
    
        }


    



