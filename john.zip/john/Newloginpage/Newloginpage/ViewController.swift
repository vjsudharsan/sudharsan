//
//  ViewController.swift
//  Newloginpage
//
//  Created by Apple on 12/11/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    lazy var screenscrollview: UIScrollView = {
        let scrollview = UIScrollView ()
        scrollview.backgroundColor = .white
        scrollview.translatesAutoresizingMaskIntoConstraints = false
        scrollview.isUserInteractionEnabled = true
        scrollview.showsVerticalScrollIndicator = true
        scrollview.showsHorizontalScrollIndicator = true
        return scrollview
    }()
    
    
    lazy var stackviewform: UIStackView = {
        let stackview = UIStackView(arrangedSubviews: [labelone, FirstTextField, labletwo, SecondTextField, lablethree, ThirdTextField, lablefour, mobileTextField, lablefive, passwordTextField, lablesix, ConfirmTextField, ButtonSubmit])
        stackview.distribution = .fillEqually
        stackview.axis = .vertical
        stackview.alignment = .fill
        stackview.spacing = 15
        stackview.isLayoutMarginsRelativeArrangement = true
        stackview.translatesAutoresizingMaskIntoConstraints = false
        stackview.layoutMargins = UIEdgeInsets (top:200 , left:20 , bottom:400 , right:20 )
        return stackview
    }()
    
    lazy var labelone: UILabel = {
        let firstlabel = UILabel()
        firstlabel.text = "First Name"
        firstlabel.textColor = .orange
        firstlabel.backgroundColor = .white
        firstlabel.textAlignment = .left
        firstlabel.font = UIFont.systemFont(ofSize: 20)
        firstlabel.translatesAutoresizingMaskIntoConstraints = false
        firstlabel.numberOfLines = 0
        return firstlabel
    }()
    
    lazy var FirstTextField: UITextField = {
        let firstname = UITextField()
        firstname.placeholder = "Enter first name"
        firstname.textAlignment = .left
        firstname.textColor = .black
        firstname.keyboardType = .default
        firstname.backgroundColor = .white
        firstname.translatesAutoresizingMaskIntoConstraints = false
        return firstname
    }()
    
    lazy var labletwo: UILabel = {
        let secondlabel = UILabel()
        secondlabel.text = "Last Name"
        secondlabel.textColor = .orange
        secondlabel.backgroundColor = .white
        secondlabel.textAlignment = .left
        secondlabel.font = UIFont.systemFont(ofSize: 20)
        secondlabel.translatesAutoresizingMaskIntoConstraints = false
        secondlabel.numberOfLines = 0
        return secondlabel
    }()
    
    lazy var SecondTextField: UITextField = {
        let lastname = UITextField()
        lastname.placeholder = " Enter last name"
        lastname.textAlignment = .left
        lastname.textColor = .black
        lastname.keyboardType = .default
        lastname.backgroundColor = .white
        lastname.translatesAutoresizingMaskIntoConstraints = false
       return lastname
    }()
    
    lazy var lablethree: UILabel = {
        let thirdlabel = UILabel()
        thirdlabel.text = "Email"
        thirdlabel.textColor = .orange
        thirdlabel.backgroundColor = .white
        thirdlabel.textAlignment = .left
        thirdlabel.font = UIFont.systemFont(ofSize: 20)
        thirdlabel.translatesAutoresizingMaskIntoConstraints = false
        thirdlabel.numberOfLines = 0
       return thirdlabel
    }()
    
    lazy var ThirdTextField: UITextField = {
        let email = UITextField ()
        email.placeholder = "Enter the mail id"
        email.textAlignment = .left
        email.textColor = .black
        email.backgroundColor = .white
        email.keyboardType = .default
        email.translatesAutoresizingMaskIntoConstraints = false
        return email
    }()
    
    lazy var lablefour: UILabel = {
        let Fourthlabel = UILabel()
        Fourthlabel.text = "mobile number"
        Fourthlabel.textColor = .orange
        Fourthlabel.textAlignment = .left
        Fourthlabel.backgroundColor = .white
        Fourthlabel.font = UIFont.systemFont(ofSize: 20)
        Fourthlabel.translatesAutoresizingMaskIntoConstraints = false
        Fourthlabel.numberOfLines = 0
       return Fourthlabel
    }()
    
    lazy var mobileTextField: UITextField = {
        let phone = UITextField()
        phone.placeholder = "enter the phone number"
        phone.textAlignment = .left
        phone.textColor = .black
        phone.backgroundColor = .white
        phone.keyboardType = .numberPad
        phone.translatesAutoresizingMaskIntoConstraints = false
        return phone
    }()
    
    lazy var lablefive: UILabel = {
        let fifthlabel = UILabel()
        fifthlabel.text = "password"
        fifthlabel.textColor = .orange
        fifthlabel.textAlignment = .left
        fifthlabel.backgroundColor = .white
        fifthlabel.font = UIFont.systemFont(ofSize: 20)
        fifthlabel.translatesAutoresizingMaskIntoConstraints = false
        fifthlabel.numberOfLines = 0
        return fifthlabel
    }()
    
    lazy var passwordTextField: UITextField = {
        let password = UITextField()
        password.placeholder = "enter the password"
        password.textColor = .black
        password.textAlignment = .left
        password.backgroundColor = .white
        password.keyboardType = .default
        password.isSecureTextEntry = true
        password.translatesAutoresizingMaskIntoConstraints = false
        return password
    }()
    
    lazy var lablesix: UILabel = {
        let sixthlabel = UILabel()
        sixthlabel.text = "confirm password"
        sixthlabel.textColor = .orange
        sixthlabel.textAlignment = .left
        sixthlabel.backgroundColor = .white
        sixthlabel.font = UIFont.systemFont(ofSize: 20)
        sixthlabel.translatesAutoresizingMaskIntoConstraints = false
        sixthlabel.numberOfLines = 0
        return sixthlabel
    }()

    lazy var ConfirmTextField: UITextField = {
        let confirmpassword = UITextField()
        confirmpassword.placeholder = "Re enter the password"
        confirmpassword.textColor = .black
        confirmpassword.textAlignment = .left
        confirmpassword.keyboardType = .default
        confirmpassword.backgroundColor = .white
        confirmpassword.isSecureTextEntry = true
        confirmpassword.translatesAutoresizingMaskIntoConstraints = false
        return confirmpassword
    }()
    
    lazy var ButtonSubmit: UIButton = {
        let Submitbutton = UIButton()
        Submitbutton.setTitle("submit" , for: .normal)
        Submitbutton.setTitleColor(.white, for: .normal)
        Submitbutton.backgroundColor = .gray
        Submitbutton.layer.cornerRadius = 9.0
        Submitbutton.translatesAutoresizingMaskIntoConstraints = false
        return Submitbutton
    }()
    
    override func loadView() {
        super.loadView()
        self.setupview()
        self.layoutUIview()
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupview()
         ButtonSubmit.isEnabled = false
        ButtonSubmit.backgroundColor = .gray
        ButtonSubmit.addTarget(self, action: #selector(ButtonSubmitAction(_:)), for: .touchUpInside)
        FirstTextField.addTarget(self, action: #selector(ViewController.textFieldDidChange(_:)), for: .editingChanged)
        SecondTextField.addTarget(self, action: #selector(ViewController.textFieldDidChange(_:)), for: .editingChanged)
        ThirdTextField.addTarget(self, action: #selector(ViewController.textFieldDidChange(_:)), for: .editingChanged)
        mobileTextField.addTarget(self, action: #selector(ViewController.textFieldDidChange(_:)), for: .editingChanged)
        passwordTextField.addTarget(self, action: #selector(ViewController.textFieldDidChange(_:)), for: .editingChanged)
        ConfirmTextField.addTarget(self, action: #selector(ViewController.textFieldDidChange(_:)), for: .editingChanged)
        
        
        mobileTextField.addDoneCancelToolbar(onDone:(target: self, action: #selector (ToolbarNumericTextField)))
  

        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    @objc func ToolbarNumericTextField(_sender: UIButton){
        print("done");
        if let mobilenumber = mobileTextField.text {
            print(mobilenumber)
        }
        mobileTextField.resignFirstResponder()
        passwordTextField.becomeFirstResponder()
    }
    
    @objc func textFieldDidChange(_ textfield:UITextField) {
        if FirstTextField.text == "" || SecondTextField.text == "" || ThirdTextField.text == "" || mobileTextField.text == "" || passwordTextField.text == "" || ConfirmTextField.text == "" {
            ButtonSubmit.isEnabled = false
            ButtonSubmit.backgroundColor = .gray
        }
        else {
            ButtonSubmit.isEnabled = true
            ButtonSubmit.backgroundColor = .black
        }
    }
    
    @objc func ButtonSubmitAction(_ sender: UIButton) {
        print("successfully submitted")
    }


        func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
            var maxlength: Int?
            let currentstring: NSString = textField.text! as NSString
            if textField == FirstTextField {
                maxlength = 30
            }
            else if textField == SecondTextField {
                maxlength = 30
            }
            else if textField == ThirdTextField {
                maxlength = 30
            }
            else if textField == mobileTextField {
                maxlength = 10
            }
            else if textField == passwordTextField {
                maxlength = 20
            }
            else if textField == ConfirmTextField {
                maxlength = 20
            }
            else
            {
                maxlength = 25
            }
            let newString: NSString = currentstring.replacingCharacters(in: range, with: string ) as NSString
            return newString.length <= maxlength ?? 0
        }



    func layoutUIview() {
        self.view.addSubview(screenscrollview)
        NSLayoutConstraint.activate([screenscrollview.leadingAnchor.constraint(equalTo: self.view.leadingAnchor), screenscrollview.trailingAnchor.constraint(equalTo: self.view.trailingAnchor), screenscrollview.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor), screenscrollview.bottomAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.bottomAnchor), screenscrollview.centerXAnchor.constraint(equalTo: self.view.centerXAnchor)])
    }
    


    func setupview() {
       
        screenscrollview.addSubview(stackviewform)
        self.stackviewform.addSubview(FirstTextField)
        FirstTextField.delegate = self
        self.stackviewform.addSubview(SecondTextField)
        SecondTextField.delegate = self
        self.stackviewform.addSubview(ThirdTextField)
        ThirdTextField.delegate = self
        self.stackviewform.addSubview(mobileTextField)
        mobileTextField.delegate = self
        self.stackviewform.addSubview(passwordTextField)
        passwordTextField.delegate = self
        self.stackviewform.addSubview(ConfirmTextField)
        ConfirmTextField.delegate = self
        
        NSLayoutConstraint.activate([stackviewform.leadingAnchor.constraint(equalTo: screenscrollview.leadingAnchor), stackviewform.trailingAnchor.constraint(equalTo: screenscrollview.trailingAnchor), stackviewform.safeAreaLayoutGuide.topAnchor.constraint(equalTo: screenscrollview.topAnchor), stackviewform.bottomAnchor.constraint(equalTo: screenscrollview.bottomAnchor), stackviewform.widthAnchor.constraint(equalTo: screenscrollview.widthAnchor),])
        NSLayoutConstraint.activate([stackviewform.heightAnchor.constraint(greaterThanOrEqualToConstant: 44)])
        }

}
extension ViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField.text == FirstTextField.text {
            FirstTextField.resignFirstResponder()
            SecondTextField.becomeFirstResponder()
        } else if textField.text == SecondTextField.text {
           SecondTextField.resignFirstResponder()
            ThirdTextField.becomeFirstResponder()
        } else if textField.text == ThirdTextField.text {
            ThirdTextField.resignFirstResponder()
            mobileTextField.becomeFirstResponder()
        } else if textField.text == mobileTextField.text {
            mobileTextField.resignFirstResponder()
            passwordTextField.becomeFirstResponder()
        } else if textField.text == passwordTextField.text {
            passwordTextField.resignFirstResponder()
            ConfirmTextField.becomeFirstResponder()
        } else {
            ConfirmTextField.resignFirstResponder()
        }
        return true
    }
}



extension UITextField {
    func addDoneCancelToolbar(onDone: (target: Any, action: Selector)? = nil, onCancel: (target: Any, action: Selector)? = nil) {
        let onCancel = onCancel ?? (target: self, action: #selector(cancelbuttonTapped))
        let onDone = onDone ?? (target: self, action: #selector(donebuttonTapped))

        let toolbar: UIToolbar = UIToolbar()
        toolbar.barStyle = .default
        toolbar.items = [UIBarButtonItem(title:"Cancel", style: .plain, target: onCancel.target, action: onCancel.action), UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: self, action: nil), UIBarButtonItem(title: "Done", style: .plain, target: onDone.target, action: onDone.action)]

        toolbar.sizeToFit()
        self.inputAccessoryView = toolbar
    }
    @objc func donebuttonTapped() { self.resignFirstResponder()}
    @objc func cancelbuttonTapped() { self.resignFirstResponder()}
}
