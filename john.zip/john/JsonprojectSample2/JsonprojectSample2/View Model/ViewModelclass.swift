//
//  ViewModelclass.swift
//  JsonprojectSample2
//
//  Created by Apple on 05/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import Foundation

class ViewModelclass {
    
    var modelClassController: ModelClass?
    
    
    func setUPBundle() {
        modelClassController = Bundle.main.decode(ModelClass.self, from: "sampleJsonNew.json")
    }
    

    
    
    
    
    
}
