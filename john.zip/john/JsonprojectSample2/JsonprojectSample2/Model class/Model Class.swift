//
//  Model Class.swift
//  JsonprojectSample2
//
//  Created by Apple on 05/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import Foundation

struct ModelClass: Decodable {
    var firstName: String?
    var lastName: String?
    var gender: String?
    var age: Int?
    var address: AddressElements?
    var phoneNumbers: [PhoneElements]?
}

struct  AddressElements: Decodable {
    var streetAddress: String?
    var city: String?
    var state: String?
    var postalCode: String?
}

struct PhoneElements: Decodable {
    var type: String?
    var number: String?
}
