//
//  JsonViewController.swift
//  JsonprojectSample2
//
//  Created by Apple on 05/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import UIKit

class JsonViewController: UIViewController {
    
    
    var ViewModel = ViewModelclass()
    
    
    @IBOutlet weak var firstLabel: UILabel!
    @IBOutlet weak var lastLabel: UILabel!
    @IBOutlet weak var genderLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var streetLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var stateLabel: UILabel!
    @IBOutlet weak var postalLabel: UILabel!
    @IBOutlet weak var PhoneTypeLabel: UILabel!
    @IBOutlet weak var phoneNoLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ViewModel.setUPBundle()
       
      
        // Do any additional setup after loading the view.
        if let object = ViewModel.modelClassController, let ageID = object.age {
            
            firstLabel.text = object.firstName
            lastLabel.text = object.lastName
            genderLabel.text = object.gender
            ageLabel.text = String(ageID)
            streetLabel.text = object.address?.streetAddress
            cityLabel.text = ViewModel.modelClassController?.address?.postalCode
            stateLabel.text = object.address?.state
            postalLabel.text = object.address?.postalCode
            
            
            
            
            
            
            
            
            
            
        }
        
        
    }
    

   
    
    
}
