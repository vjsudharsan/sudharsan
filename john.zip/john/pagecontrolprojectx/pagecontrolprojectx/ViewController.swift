//
//  ViewController.swift
//  pagecontrolprojectx
//
//  Created by Apple on 30/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIScrollViewDelegate {
    let scrollingView = UIScrollView()
    var images = ["albino", "arsenal","barcelona","cavani","david luiz","di maria","dybala","iniesta","juventus","kaka","liverpool","mbappe","messi","neymar","ogbeche","ramos","ronaldo","santi", "sunil", "zlatan"]
    var layoutFrame: CGRect = CGRect(x:0 , y:0, width: 0, height: 0)
    let pageControl = UIPageControl()
    
override func viewDidLoad() {
        super.viewDidLoad()
    
        // Do any additional setup after loading the view, typically from a nib.
    
    scrollingView.frame = CGRect(x: self.view.frame.origin.x, y: self.view.frame.origin.y, width: self.view.frame.size.width, height: self.view.frame.size.height)
    scrollingView.delegate = self
    scrollingView.isPagingEnabled = true
    scrollingView.bounces = false
    scrollingView.showsHorizontalScrollIndicator = false
    scrollingView.showsVerticalScrollIndicator = false
    self.view.addSubview(scrollingView)
    self.pagecontrolConfiguration()
    
    for index in 0..<20 {
        layoutFrame.origin.x = self.scrollingView.frame.size.width * CGFloat(index)
        layoutFrame.size = self.scrollingView.frame.size
        
        
        let subView = UIView()
        subView.frame = CGRect(x: self.view.frame.origin.x, y: self.view.frame.origin.y, width: self.view.frame.size.width, height:self.view.frame.size.height)
        let addedsubview = UIImageView(frame: layoutFrame)
//        addedsubview.frame = CGRect(x: self.view.frame.origin.x, y: self.view.frame.origin.y, width: self.view.frame.size.width, height:self.view.frame.size.height)
        addedsubview.contentMode = .center
        addedsubview.image = UIImage(named: images[index])
      self.scrollingView.addSubview(subView)
      self.scrollingView.addSubview(addedsubview)
    }

    
    self.scrollingView.contentSize = CGSize(width: self.scrollingView.frame.size.width * 20, height: self.scrollingView.frame.size.height)
    pageControl.addTarget(self, action: #selector(self.pageChangerAction(sender:)), for: UIControl.Event.valueChanged)
    
    
    }

    
    @objc func pageChangerAction(sender: AnyObject) -> () {
       let x = CGFloat(pageControl.currentPage) * scrollingView.frame.size.width
        scrollingView.setContentOffset(CGPoint(x: x, y: 0), animated: true)
    }

    func pagecontrolConfiguration() {
        self.pageControl.numberOfPages = images.count
        self.pageControl.currentPage = 0
        self.pageControl.tintColor = UIColor.green
        self.pageControl.currentPageIndicatorTintColor = .cyan
        self.pageControl.pageIndicatorTintColor = .black
        self.pageControl.frame = CGRect(x: self.view.frame.origin.x+180, y: self.view.frame.origin.y+100, width: 0, height: 0)
        self.view.addSubview(pageControl)
    }

    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let pageNo = round(scrollView.contentOffset.x / scrollView.frame.size.width)
        pageControl.currentPage = Int(pageNo)
    }
    
}

