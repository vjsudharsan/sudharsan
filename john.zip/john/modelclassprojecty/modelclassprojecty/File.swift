//
//  File.swift
//  modelclassprojecty
//
//  Created by Apple on 14/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//
//
//import Foundation

import Foundation


struct clubs {
    var clubname: String?
    var clubimage: String?
    var members: [members]?
}

struct members {
    var playername: String?
    var fcname: String?
    var goals: String?
    var image: String?
}
