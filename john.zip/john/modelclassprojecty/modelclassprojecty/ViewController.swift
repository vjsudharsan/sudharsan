//
//  ViewController.swift
//  modelclassprojecty
//
//  Created by Apple on 14/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var firstcell = "cellfolder"
    lazy var firsttable: UITableView = {
        let table = UITableView(frame: .zero, style: .grouped)
        table.translatesAutoresizingMaskIntoConstraints = false
        table.backgroundColor = .white
        return table
    }()
    
    var soccer: [clubs]?
    
    override func loadView() {
        super.loadView()
        self.setupview()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addSubview(firsttable)
        self.tablesetup()
        
        
        let football = clubs(clubname:"JUVENTUS", clubimage: "juventus", members:[members(playername: "DYBALA", fcname: "AC Milan", goals: "123", image: "dybala"), members(playername: "RONALDO", fcname: "REAL MADRID ", goals:"23", image: "ronaldo"), members(playername: "DI - MARIA", fcname: "ATK", goals: "53", image: "di maria"), members(playername: "MBAPPEE", fcname: "PSG", goals:"47", image: "mbappe")])
        
        //soccer = football
        
        let football1 = clubs(clubname: " BARCELONA", clubimage: "barcelona", members: [members(playername: "KAKA", fcname: "ARSENAL", goals:" 54", image: "kaka"), members(playername: " DAVID LUIZ", fcname: "CHELSEA", goals:"52", image: "david luiz"), members(playername: "MESSI", fcname: "LIVERPOOL", goals: "96", image: "messi"), members(playername: "SANTIAGO", fcname: "BAYERN MUNICH ", goals: "143", image: "santi")])
        
        //soccer1 = football1
        
        let football2 = clubs(clubname: "LIVERPOOL", clubimage: "liverpool", members:[members(playername: "SERGIO RAMOS", fcname: "CHILIE", goals: "78", image: "ramos"), members(playername: "ZLATAN", fcname: "SWEDEN FC", goals: "99", image: "zlatan"), members(playername: "ALBINO GOMEZ ", fcname: "INDIA FC", goals:"83", image: "albino"), members(playername: "OGBECHEZH", fcname: " NYGERIA FC", goals:"78", image: "ogbeche")])
        
        //soccer2 = football2
        
        
        let football3 = clubs(clubname: "ARSENAL", clubimage: "arsenal",members:[members(playername: "NEYMAR", fcname:"BRAZIL FC", goals: "45", image: "neymar"), members(playername: "SUNIL CHETTRI", fcname: "INDIA FC", goals: "74", image: "sunil"), members(playername: "INIESTA", fcname:"ENGLISH FC", goals: "95", image: "iniesta"), members(playername: "GAVANI", fcname: "FC GOA", goals: "89", image: "cavani")])
        
        soccer = [football, football2, football1, football3]

    }
    
    func tablesetup(){
        firsttable.estimatedRowHeight = 500
        firsttable.dataSource = self
        firsttable.delegate = self
        firsttable.separatorColor = .none
        firsttable.separatorStyle = .singleLine
        firsttable.tableFooterView = UIView()
        firsttable.register(cellfolder.self, forCellReuseIdentifier: firstcell)
        
        
    }
    func setupview(){
        self.view.addSubview(firsttable)
        
        
        NSLayoutConstraint.activate([firsttable.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 10),firsttable.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -10),firsttable.topAnchor.constraint(equalTo: self.view.topAnchor), firsttable.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)])
    }
    
    
}
extension ViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return soccer?.count ?? 0
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return soccer?[section].members?.count ?? 0

    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = firsttable.dequeueReusableCell(withIdentifier: firstcell, for: indexPath) as? cellfolder else {
            return UITableViewCell()
        }
        cell.name.text = soccer?[indexPath.section].members?[indexPath.row].playername
        cell.fc1.text = soccer?[indexPath.section].members?[indexPath.row].fcname
        cell.goals.text = soccer?[indexPath.section].members?[indexPath.row].goals
        cell.imagefield.image = UIImage(named: (soccer?[indexPath.section].members?[indexPath.row].image ?? nil)!)
        cell.layer.cornerRadius = 2.0
        cell.layer.borderWidth = 3.0
        cell.layer.borderColor = UIColor.black.cgColor
        cell.accessoryType = .detailButton
        cell.backgroundColor = .white
        return cell
    }
    
    
    
}

extension ViewController: UITableViewDelegate {

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerview = UIView()
        let headerLabel = UILabel()
        headerLabel.text = soccer?[section].clubname
        headerLabel.textAlignment = .center
        headerLabel.numberOfLines = 0
        headerLabel.textColor = .red
        headerLabel.lineBreakMode = .byWordWrapping
        headerLabel.frame = CGRect(x:20, y: 0, width: self.view.frame.width-40, height: 80)
        headerview.addSubview(headerLabel)
        
    let headerImage = UIImageView()
        headerImage.image = UIImage(named: (soccer?[section].clubimage ?? nil)!)
        headerImage.frame = CGRect(x: 75, y: 0, width:80, height:80)
        headerview.addSubview(headerImage)
     return headerview
    }
    

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 80
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
   
   
//
}










