//
//  cellfolder.swift
//  modelclassprojecty
//
//  Created by Apple on 14/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

//
//  tablecell.swift
//  Tableviewcustomcoding
//
//  Created by Apple on 01/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class cellfolder: UITableViewCell {
    
    lazy var imagefield: UIImageView = {
        var images = UIImageView()
        images = UIImageView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
        images.layer.cornerRadius = 30.0
        images.clipsToBounds = true
        images.translatesAutoresizingMaskIntoConstraints = false
        return images
    }()
    
    lazy var name: UILabel = {
        let playerName = UILabel()
        playerName.textColor = .blue
        playerName.backgroundColor = .white
        playerName.translatesAutoresizingMaskIntoConstraints = false
        playerName.lineBreakMode = .byWordWrapping
        playerName.textAlignment = .left
        playerName.numberOfLines = 0
        return playerName
    }()
    
    lazy var fc1: UILabel = {
        let fc = UILabel()
        fc.textColor = .blue
        fc.backgroundColor = .white
        fc.translatesAutoresizingMaskIntoConstraints = false
        fc.numberOfLines = 0
        fc.lineBreakMode = .byWordWrapping
        fc.textAlignment = .left
        return fc
        
    }()
    
    lazy var goals: UILabel = {
        let goal = UILabel()
        goal.textColor = .black
        goal.backgroundColor = .white
        goal.translatesAutoresizingMaskIntoConstraints = false
        goal.numberOfLines = 0
        goal.lineBreakMode = .byWordWrapping
        goal.textAlignment = .right
        return goal
    }()
    

        override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .default, reuseIdentifier: reuseIdentifier)
        self.setup()


    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    
    //
    //    override func awakeFromNib() {
    //        super.awakeFromNib()
    //        self.setup()
    //        // Initialization code
    //    }
    //
    //    override func setSelected(_ selected: Bool, animated: Bool) {
    //        super.setSelected(selected, animated: animated)
    //    }
    func setup(){
        self.contentView.addSubview(imagefield)
        self.contentView.addSubview(name)
        self.contentView.addSubview(fc1)
        self.contentView.addSubview(goals)
        
        
        
        
        // Configure the view for the selected state
        
        NSLayoutConstraint.activate([imagefield.leadingAnchor.constraint(equalTo: self.contentView.leadingAnchor, constant: 20), imagefield.heightAnchor.constraint(equalToConstant: 80), imagefield.widthAnchor.constraint(equalToConstant: 80), imagefield.centerYAnchor.constraint(equalTo: self.contentView.centerYAnchor)])
        
        NSLayoutConstraint.activate([name.topAnchor.constraint(equalTo: self.contentView.topAnchor, constant: 10), name.leadingAnchor.constraint(equalTo: self.imagefield.trailingAnchor, constant: 20)])
        
        NSLayoutConstraint.activate([fc1.leadingAnchor.constraint(equalTo: self.imagefield.trailingAnchor, constant: 20), fc1.topAnchor.constraint(equalTo: self.name.bottomAnchor, constant: 15), fc1.bottomAnchor.constraint(equalTo: self.contentView.bottomAnchor, constant: -10)])
        
        NSLayoutConstraint.activate([goals.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor, constant: -25),goals.centerYAnchor.constraint(equalTo: self.contentView.centerYAnchor)])
        
        
        
        
        
    }
}

