//
//  ViewController.swift
//  PageDesignProgramatically
//
//  Created by nschool on 27/10/20.
//

import UIKit

class ViewController: UIViewController {
    
    lazy var recipelogo:UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(named: "fried rice")
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
        
    }()
    
    lazy var findLabel:UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Let's Find Recipe Food"
        label.textAlignment = .center
        label.textColor = .white
        label.layer.shadowColor = UIColor.black.cgColor
        label.layer.shadowRadius = 3.0
        label.layer.shadowOpacity = 1.0
        label.layer.shadowOffset = CGSize(width: 4, height: 4)
        label.lineBreakMode = .byWordWrapping
        label.font = UIFont.systemFont(ofSize: 25)
        return label
        
    }()
    
    
    lazy var labelSignIn: UILabel = {
        let subLabel = UILabel()
        subLabel.translatesAutoresizingMaskIntoConstraints = false
        subLabel.text = "SIGN UP"
        subLabel.numberOfLines = 0
        subLabel.textAlignment = .center
        subLabel.textColor = .white
        subLabel.layer.shadowColor = UIColor.black.cgColor
        subLabel.layer.shadowRadius = 1.0
        subLabel.layer.shadowOpacity = 1.0
        subLabel.layer.shadowOffset = CGSize(width: 2, height: 2)
        subLabel.lineBreakMode = .byWordWrapping
        subLabel.font = UIFont.systemFont(ofSize: 30)
        return subLabel
    }()
    
    
    lazy var msg: UILabel = {
        let msgLabel = UILabel()
        msgLabel.translatesAutoresizingMaskIntoConstraints = false
        msgLabel.text = "Already have an account?"
        msgLabel.numberOfLines = 0
        msgLabel.textAlignment = .center
        msgLabel.textColor = .white
        msgLabel.layer.shadowColor = UIColor.black.cgColor
        msgLabel.layer.shadowRadius = 1.0
        msgLabel.layer.shadowOpacity = 1.0
        msgLabel.layer.shadowOffset = CGSize(width: 1, height: 1)
        msgLabel.lineBreakMode = .byWordWrapping
        msgLabel.font = UIFont.systemFont(ofSize: 20)
        return msgLabel
    }()
    
    lazy var mainLogin: UIButton = {
        let mainbutton = UIButton()
        mainbutton.setTitle("LOGIN", for: .normal)
        mainbutton.setTitleColor(.white, for: .normal)
        mainbutton.backgroundColor = .blue
        mainbutton.layer.cornerRadius = 10
        mainbutton.layer.borderWidth = 1.0
        mainbutton.layer.borderColor = UIColor.white.cgColor
        //button.addTarget(self, action: #selector(applybuttonAction(_:)), for: .touchUpInside)
        return mainbutton
    }()
    
    lazy var stackView: UIStackView = {
        let stackView = UIStackView(arrangedSubviews: [facebook, twitter, whatsapp])
        stackView.alignment = .fill
        stackView.distribution = .fillEqually
        stackView.axis = .horizontal
        stackView.spacing = 15
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.isLayoutMarginsRelativeArrangement = true
        stackView.layoutMargins = UIEdgeInsets(top: 15, left: 15, bottom: 15, right: 15)
        stackView.backgroundColor = .clear
        return stackView
    }()
    lazy var facebook: UIButton = {
        let button = UIButton()
        button.setTitle("facebook", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .blue
        button.layer.cornerRadius = 10
        button.layer.borderWidth = 1.0
        button.layer.borderColor = UIColor.white.cgColor
        //button.addTarget(self, action: #selector(applybuttonAction(_:)), for: .touchUpInside)
        return button
    }()
    
    lazy var twitter: UIButton = {
        let button = UIButton()
        button.setTitle("twitter", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .orange
        button.layer.cornerRadius = 10
        button.layer.borderWidth = 1.0
        button.layer.borderColor = UIColor.white.cgColor
        return button
    }()
    
    lazy var whatsapp: UIButton = {
        let button = UIButton()
        button.setTitle("whatsapp", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .purple
        button.layer.borderWidth = 1.0
        button.layer.cornerRadius = 10
        button.layer.borderColor = UIColor.white.cgColor
        button.translatesAutoresizingMaskIntoConstraints = false
        //        button.addTarget(self, action: #selector(buttonAction(_:)), for: .touchUpInside)
        return button
    }()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
        backgroundImage.image = UIImage(named: "background")
        self.view.insertSubview(backgroundImage, at: 0)
        // Do any additional setup after loading the view.
        self.setUpView()
    }
    func setUpView(){
        self.view.addSubview(recipelogo)
        self.view.addSubview(findLabel)
        self.view.addSubview(labelSignIn)
        self.view.addSubview(stackView)
        self.view.addSubview(msg)
        self.view.addSubview(mainLogin)
        //self.view.addSubview(mainLogin)
        
        let leadingConstraint = recipelogo.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 120)
        let trailingConstraint = recipelogo.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -120)
        let topConstraint = recipelogo.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 50)
        let heightConstraint = recipelogo.heightAnchor.constraint(equalToConstant: 150)
        let widthConstraint = recipelogo.widthAnchor.constraint(equalToConstant:50)
        NSLayoutConstraint.activate([leadingConstraint, trailingConstraint, topConstraint, heightConstraint, widthConstraint])
        
        let findLabelleadingConstraint = findLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15)
        let findTrailingConstraint = findLabel.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15)
        let findTopConstraint = findLabel.topAnchor.constraint(equalTo: recipelogo.bottomAnchor, constant: 15)
        let findHeightConstraint = findLabel.heightAnchor.constraint(greaterThanOrEqualToConstant: 40)
        NSLayoutConstraint.activate([findLabelleadingConstraint, findTrailingConstraint, findTopConstraint, findHeightConstraint])
        
        let signInTitleLeadingConstraint = labelSignIn.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15)
        let  signInTitleTrailingConstraint = labelSignIn.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15)
        let  signInTitleTopConstraint = labelSignIn.topAnchor.constraint(equalTo: findLabel.bottomAnchor, constant: 60)
        let  signInTitleHeightConstraint = labelSignIn.heightAnchor.constraint(greaterThanOrEqualToConstant: 20)
        NSLayoutConstraint.activate([signInTitleLeadingConstraint, signInTitleTrailingConstraint, signInTitleTopConstraint, signInTitleHeightConstraint])
        
        
        let stackViewLeadingConstraint = stackView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15)
        let stackViewTrailingconstraint = stackView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15)
        let stackViewTopConstraint = stackView.topAnchor.constraint(equalTo: labelSignIn.bottomAnchor, constant: 20)
        NSLayoutConstraint.activate([stackViewLeadingConstraint, stackViewTrailingconstraint, stackViewTopConstraint,])
        
        
        let msgLeadingConstraint = msg.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15)
        let msgTrailingConstraint = msg.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15)
        let msgTopanchorConstraint = msg.topAnchor.constraint(equalTo: stackView.bottomAnchor, constant: 20)
        let  msgHeightConstraint = msg.heightAnchor.constraint(greaterThanOrEqualToConstant: 20)
        NSLayoutConstraint.activate([msgLeadingConstraint, msgTrailingConstraint, msgHeightConstraint, msgTopanchorConstraint])
        
        //        let mainloginLeadingConstraint = mainLogin.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15)
        //        let mainloginTrailingconstraint = mainLogin.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15)
        //        let mainloginTopConstraint = mainLogin.topAnchor.constraint(equalTo: msg.bottomAnchor, constant: 20)
        //        let  mainloginhightconstraint = mainLogin.heightAnchor.constraint(greaterThanOrEqualToConstant: 20)
        //        NSLayoutConstraint.activate([mainloginLeadingConstraint, mainloginTrailingconstraint, mainloginTopConstraint, mainloginhightconstraint])
    }
    
}

