//
//  ViewController.swift
//  InnovationTaskMap
//
//  Created by Apple on 05/02/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController {
    
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var locationTableView: UITableView!
    
    var viewmodelclass = Viewmodel()
    var reuseIdentifier = "LocationTableViewCell"
    
    var locationManager = CLLocationManager()
    var currentLocation: CLLocation?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initViewModel()
        
        
        
        if (CLLocationManager.locationServicesEnabled())
        {
            locationManager = CLLocationManager()
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.requestAlwaysAuthorization()
            locationManager.startUpdatingLocation()
        }
    }
     // reload closure call
    func initViewModel() {
        viewmodelclass.reloadClosures = {
            [weak self] in
            guard let self = self else { return}
            DispatchQueue.main.async {
                self.locationTableView.reloadData()
            }
        }
        self.viewmodelclass.getMethod()
    }
    // image loading code from URL
    func PlaceholderImage(image:UIImage?, imageView:UIImageView?,imgUrl:String,compate:@escaping (UIImage?) -> Void){
        if image != nil && imageView != nil {
            imageView!.image = image!
        }
        var urlcatch = imgUrl.replacingOccurrences(of: "/", with: "#")
        let documentpath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        urlcatch = documentpath + "/" + "\(urlcatch)"
        let image = UIImage(contentsOfFile:urlcatch)
        if image != nil && imageView != nil
        {
            imageView!.image = image!
            compate(image)
        }else {
            if let url = URL(string: imgUrl){
                DispatchQueue.global(qos: .background).async {
                    () -> Void in
                    let imgdata = NSData(contentsOf: url)
                    DispatchQueue.main.async {
                        () -> Void in
                        imgdata?.write(toFile: urlcatch, atomically: true)
                        let image = UIImage(contentsOfFile:urlcatch)
                        compate(image)
                        if image != nil  {
                            if imageView != nil  {
                                imageView!.image = image!
                            }
                        }
                    }
                }
            }
        }
    }
    
    
    
    
    
    
}

extension ViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        
        // annotation pin code
        let location = locations.last! as CLLocation
        let userLocation:CLLocation = locations[0] as CLLocation
        let myAnnotation: MKPointAnnotation = MKPointAnnotation()
        myAnnotation.coordinate = CLLocationCoordinate2DMake(userLocation.coordinate.latitude, userLocation.coordinate.longitude)
        myAnnotation.title = "Current location"
        mapView.addAnnotation(myAnnotation)
        
        
        // current location getting code
        currentLocation = location
        let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        
        self.mapView.setRegion(region, animated: true)
        self.locationTableView.reloadData()
        
    }
    
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return viewmodelclass.numberOfSection
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewmodelclass.numberOfRowsInSection
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = locationTableView.dequeueReusableCell(withIdentifier: reuseIdentifier) as! LocationTableViewCell
        
        if let getObject = viewmodelclass.cellRowAtIndexpath(indexpath: indexPath), let image = getObject.icon, let lat = getObject.geometry?.location?.lat, let lng = getObject.geometry?.location?.lng, let logo = getObject.icon {
            PlaceholderImage(image: UIImage(named: "theater"), imageView: cell.imageLayer, imgUrl: logo) {(image) in
                cell.theatreLabel.text = getObject.name
                cell.imageLayer.image = image
            }
            
            
            // distance calculation code( have to declare current location globally in above extension)
            if let currentLocation = currentLocation {
                
                let DestinationLocation = CLLocation(latitude: lat, longitude: lng)
                let distance = currentLocation.distance(from: DestinationLocation) / 1000
                print(String(format: "The distance to this place is %.01fkm", distance))
                cell.locationLabel.text = String(format: "The distance to this place is %.01fkm", distance)
            }
            return cell
        }
        
        
        
        
        
        return cell
    }
    
    
}
