//
//  Model class.swift
//  InnovationTaskMap
//
//  Created by Apple on 05/02/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import Foundation
import MapKit


struct mapModel: Decodable {
    var html_attributions: [String]
    var next_page_token: String?
    var results: [ResultElements]?
    var status: String?
}

struct ResultElements: Decodable {
    var business_status: String?
    var geometry: geometryElements?
    var icon: String?
    var name: String?
    var opening_hours: HoursElements?
    var photos: [PhotoElements]?
    var place_id: String?
    var plus_code: SubItems?
    var rating: Double?
    var reference: String?
    var scope: String?
    var types:[String]?
    var user_ratings_total: Int?
    var vicinity: String?
    
    
}

struct geometryElements: Decodable {
    var location: locationElements?
    var viewport: viewPortItems?
}

struct locationElements: Decodable {
    var lat: Double?
    var lng: Double?
}

struct viewPortItems: Decodable {
    var northeast: locationElements?
    var southwest: locationElements?
}

struct HoursElements: Decodable {
    var open_now: Bool?
}

struct PhotoElements: Decodable {
    var height: Int?
    var html_attributions:[String]?
    var photo_reference: String?
    var width: Int?
}

struct  SubItems: Decodable {
    var compound_code: String?
    var global_code: String?
}
