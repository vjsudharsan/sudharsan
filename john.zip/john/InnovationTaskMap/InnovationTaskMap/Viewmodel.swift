//
//  Viewmodel.swift
//  InnovationTaskMap
//
//  Created by Apple on 05/02/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import Foundation


class Viewmodel {
    var reloadClosures:(() -> ())?
    var modelClass: mapModel? {
        didSet {
            self.reloadClosures?()
        }
    }
    
    
    func getMethod() {
        var request = URLRequest(url: URL(string: "https://maps.googleapis.com/maps/api/place/nearbysearch/json?types=movie_theater&location=11.016844,76.955833&radius=50000&sensor=true&key=AIzaSyAoBimyGS5412B53_5GM05__J7UoiVDuJg")!)
        request.httpMethod = "GET"
        
        URLSession.shared.dataTask(with: request, completionHandler: {data, response, error -> Void in do {
            let jsonDecoder = JSONDecoder()
            let responseModel = try jsonDecoder.decode(mapModel?.self, from: data!)
            print(responseModel)
            self.modelClass = responseModel
        } catch {
            print("JSON Serialization error")
            }
            
        }).resume()
        
    }
    
    
    var numberOfSection: Int {
        return 1
    }
    
    var numberOfRowsInSection: Int {
        return modelClass?.results?.count ?? 0
    }
    
    
    func cellRowAtIndexpath(indexpath: IndexPath) -> ResultElements? {
        if let getData = modelClass?.results?[indexpath.row] {
            return getData
        }
        return nil
    }
}
