//
//  File.swift
//  modelviewviewmodel
//
//  Created by Apple on 28/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation

struct RegisterDetails {
    var Department: String?
    var Subelements: [Details]?
    
}

struct Details {
    var Name: String?
    var Rollno: String?
    var college: String?
}

//struct idmodel: Decodable {
//    var id: String?
//    var type: String?
//    var name: String?
//    var ppu: Int?
//    var batters: BattersDetails?
//    var topping: ToppingDetails?
//
//}
//struct BattersDetails: Decodable {
//    var batter: [BattersElement]?
//    var batter1: [BattersElement]?
//    var batter2: [BattersElement]?
//    var batter3: [BattersElement]?
//}
//struct BattersElement: Decodable {
//    var id: String?
//    var type: String?
//}
//struct ToppingDetails: Decodable {
//    var Topping: [BattersElement]?
//    var Topping1: [BattersElement]?
//    var Topping2: [BattersElement]?
//    var Topping3: [BattersElement]?
//    var Topping4: [BattersElement]?
//    var Topping5: [BattersElement]?
//    var Topping6: [BattersElement]?



//struct fruits: Decodable {
//    var fruit: String?
//    var size: String?
//    var color: String?
//    
//}
//
//
//struct quiz: Decodable {
//    var quiz: quizelements?
//
//    
//}
//
//struct quizelements: Decodable {
//    var sport: sportelement?
//    var maths: mathelement?
//}
//
//struct sportelement: Decodable {
//    var q1: Questions?
//}
//
//struct mathelement: Decodable {
//    var q1: Questions?
//    var q2: Questions?
//}
//
//struct Questions: Decodable {
//    var question: String?
//    var answer: String?
//    var options: [String]?
//}
//
//struct GlossaryModel: Decodable {
//    var glossary: Glossaryelements?
//}
//
//struct Glossaryelements: Decodable {
//    var title: String?
//    var GlossDiv: GlossDivition?
//}
//
//struct GlossDivition: Decodable {
//    var title: String?
//    var GlossList: GlossListing?
//}
//
//struct GlossListing: Decodable {
//    var GlossEntry: GlossEntery?
//}
//
//struct GlossEntery: Decodable {
//    var ID: String?
//    var SortAs: String?
//    var GlossTerm: String?
//    var Acronym: String?
//    var Abbrev: String?
//    var GlossSee: String?
//    var GlossDef: GlossDefenition?
//}
//struct GlossDefenition: Decodable {
//    var para: String?
//    var GlossSeeAlso: [String]?
//    
//}
//
//
//
//
//
struct WebAppModel: Decodable {
    var webApp: Webappelements?

}
struct Webappelements: Decodable {
    var servlet: [ServeletContent]?
    var servletmapping: ServerMapping?
    var taglib: Taglibrary?
}

struct ServeletContent: Decodable {
    var servletname: String?
    var servletclass: String?
    var initparam: Initparameters?
    var Initparams: Initparams?
    var initparamet : Initparamet?
   

}
struct Initparameters: Decodable {
    var configGlossaryinstallationAt: String?
    var configGlossaryadminEmail: String?
    var configGlossarypoweredBy: String?
    var configGlossarypoweredByIcon: String?
    var configGlossarystaticPath: String?
    var templateProcessorClass: String?
    var templateLoaderClass: String?
    var templatePath: String?
    var templateOverridePath: String?
    var defaultListTemplate: String?
    var defaultFileTemplate: String?
    var useJSP: Bool?
    var jspListTemplate: String?
    var jspFileTemplate: String?
    var cachePackageTagsTrack: Int?
    var cachePackageTagsStore: Int?
    var cachePackageTagsRefresh: Int?
    var cacheTemplatesTrack: Int?
    var cacheTemplatesStore: Int?
    var cacheTemplatesRefresh: Int?
    var cachePagesTrack: Int?
    var cachePagesStore: Int?
    var cachePagesRefresh: Int?
    var cachePagesDirtyRead: Int?
    var searchEngineListTemplate: String?
    var searchEngineFileTemplate: String?
    var searchEngineRobotsDb: String?
    var useDataStore: String?
    var dataStoreClass: String?
    var redirectionClass: String?
    var dataStoreName: String?
    var dataStoreDriver: String?
    var dataStoreUrl: String?
    var dataStoreUser: String?
    var dataStorePassword: String?
    var dataStoreTestQuery: String?
    var dataStoreLogFile: String?
    var dataStoreInitConns: Int?
    var dataStoreMaxConns: Int?
    var dataStoreConnUsageLimit: Int?
    var dataStoreLogLevel: String?
    var maxUrlLength: Int?
}

struct  Initparams: Decodable {
    var mailHost: String?
    var mailHostOverride: String?
}


struct Initparamet: Decodable {
    var templatePath: String?
    var log: Int?
    var logLocation: String?
    var logMaxSize: String?
    var dataLog: Int?
    var dataLogLocation: String?
    var dataLogMaxSize: String?
    var removePageCache: String?
    var removeTemplateCache: String?
    var fileTransferFolder: String?
    var lookInContext: Int?
    var adminGroupID: Int?
    var betaServer: Bool?
}

struct ServerMapping: Decodable {
    var cofaxCDS: String?
    var cofaxEmail: String?
    var cofaxAdmin: String?
    var fileServlet: String?
    var cofaxTools: String

}
struct Taglibrary: Decodable {
    var tagliburi: String?
    var tagliblocation: String?

}

