//
//  RegisterVIewModel.swift
//  modelviewviewmodel
//
//  Created by Apple on 28/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation

class RegisterViewModel {
    var registerModel: RegisterDetails?
    
    
    
    
    let register = [RegisterDetails(Department: "B.Sc - IT", Subelements: [Details(Name: "HARI", Rollno: "789697", college: "IIT"),Details(Name: "KAVIN", Rollno: "235689", college: " KKR"), Details(Name: "PRAVEEN", Rollno: "458962", college: "PSG"), Details(Name: "SURESH", Rollno: "742365", college: "GRG")])]
    
    //    let register1 = RegisterDetails(Department: "BCA", Subelements: [Details(Name: "Praveen", Rollno: "123589", college: "NSCHOOL"), Details(Name: "Dinesh", Rollno: "635987", college: "SNR")])
    
    var numberofsection: Int {
        return 1
    }

    func numberofRowsInSection() -> Int {
        return registerModel?.Subelements?.count ?? 0
    }
    func getObject(indexpath: IndexPath) -> Details? {
        if let object = registerModel?.Subelements?[indexpath.row] {
            return object
        }
        return nil
    }
    
//    func getdepartmentList() -> Int {
//        return registerModel?.Department?.count ?? 0
//    }
//
//    func getstateListCount() -> Int {
//        return registerModel?.Subelements?.count ?? 0
//    }
//
    
    
}
