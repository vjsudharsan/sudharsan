//
//  RegisterViewController.swift
//  modelviewviewmodel
//
//  Created by Apple on 28/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class RegisterViewController: UIViewController {
    @IBOutlet weak var mytableView: UITableView!
    let viewModel = RegisterViewModel()

    

    override func viewDidLoad() {
        super.viewDidLoad()
        mytableView.tableFooterView = UIView()

        // Do any additional setup after loading the view.
    }
    
}
extension RegisterViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {

        return viewModel.numberofsection
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        return viewModel.numberofRowsInSection()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = mytableView.dequeueReusableCell(withIdentifier: Cellidenty.reuseableidentifier) as! RegisterTableViewCell
        cell.nameLabel.text = viewModel.getObject(indexpath: indexPath)?.Name
        cell.rollNoLabel.text = viewModel.getObject(indexpath: indexPath)?.Rollno
        cell.collegeNameLabel.text = viewModel.getObject(indexpath: indexPath)?.college
        return cell
    }
 
    
}
