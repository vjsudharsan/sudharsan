//
//  constants.swift
//  modelviewviewmodel
//
//  Created by Apple on 28/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation

struct Cellidenty {
    static let reuseableidentifier = "RegisterTableViewCell"
}
