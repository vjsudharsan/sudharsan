//
//  ViewController.swift
//  imageview programatical
//
//  Created by Apple on 25/11/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    lazy var imageviewlogo: UIImageView = {
        let imagelogo = UIImageView()
        imagelogo.image = UIImage(named: "whatsapp")
        imagelogo.translatesAutoresizingMaskIntoConstraints = false
        return imagelogo
    }()
    
    lazy var labelname: UILabel = {
        let name = UILabel()
        name.text = " User Name"
        name.textColor = .orange
        name.textAlignment = .left
        name.backgroundColor = .white
        name.font = UIFont.systemFont(ofSize: 20)
        name.translatesAutoresizingMaskIntoConstraints = false
        return name
    }()
    
    lazy var nameTextField: UITextField = {
        let nameField = UITextField()
        nameField.placeholder = " Enter The User Name"
        nameField.textColor = .black
        nameField.backgroundColor = .white
        nameField.textAlignment = .left
        nameField.translatesAutoresizingMaskIntoConstraints = false
        return nameField
    }()
    
    lazy var labelpassword: UILabel = {
        let password = UILabel()
        password.text =  " Password "
        password.textColor = .orange
        password.textAlignment = .left
        password.backgroundColor = .white
        password.font = UIFont.systemFont(ofSize: 20)
        password.translatesAutoresizingMaskIntoConstraints = false
        return password
    }()
    
    
    lazy var passwordTextField: UITextField = {
        let passwordField = UITextField()
        passwordField.placeholder = "Enter the password"
        passwordField.textColor = .black
        passwordField.textAlignment = .left
        passwordField.backgroundColor = .white
        passwordField.translatesAutoresizingMaskIntoConstraints = false
        return passwordField
    }()
    
    lazy var buttonlogin: UIButton = {
        let loginbutton = UIButton()
        loginbutton.setTitle(" Log in", for: .normal)
        loginbutton.setTitleColor(.black, for: .normal)
        loginbutton.backgroundColor = .cyan
        loginbutton.translatesAutoresizingMaskIntoConstraints = false
        loginbutton.layer.cornerRadius = 9.0
        return loginbutton
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupview()
    }
    // Do any additional setup after loading the view, typically from a nib.
    
    func setupview(){
        self.view.addSubview(imageviewlogo)
        self.view.addSubview(labelname)
        self.view.addSubview(nameTextField)
        nameTextField.delegate = self
        self.view.addSubview(labelpassword)
        self.view.addSubview(passwordTextField)
        passwordTextField.delegate = self
        self.view.addSubview(buttonlogin)
        
        NSLayoutConstraint.activate([imageviewlogo.widthAnchor.constraint(equalToConstant: 110), imageviewlogo.heightAnchor.constraint(equalToConstant: 110), imageviewlogo.centerXAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.centerXAnchor), imageviewlogo.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 25)])
        
        NSLayoutConstraint.activate([labelname.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 25), labelname.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -25), labelname.topAnchor.constraint(equalTo: self.imageviewlogo.bottomAnchor, constant: 20)])
        
        NSLayoutConstraint.activate([nameTextField.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 25), nameTextField.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -25), nameTextField.topAnchor.constraint(equalTo: self.labelname.bottomAnchor, constant: 20), nameTextField.heightAnchor.constraint(greaterThanOrEqualToConstant: 44)])
        
        NSLayoutConstraint.activate([labelpassword.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 25), labelpassword.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -25), labelpassword.topAnchor.constraint(equalTo: self.nameTextField.bottomAnchor, constant: 20)])
        
        NSLayoutConstraint.activate([passwordTextField.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 25), passwordTextField.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -25), passwordTextField.topAnchor.constraint(equalTo: self.labelpassword.bottomAnchor, constant: 20), passwordTextField.heightAnchor.constraint(greaterThanOrEqualToConstant: 44)])
        
        NSLayoutConstraint.activate([buttonlogin.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 25), buttonlogin.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -25), buttonlogin.topAnchor.constraint(equalTo: self.passwordTextField.bottomAnchor, constant: 20), buttonlogin.heightAnchor.constraint(greaterThanOrEqualToConstant: 44)])
        
        
        
    }
    
    
    
    
    
    
    
    
    
}




extension ViewController : UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return true
    }
}


