//
//  ViewController.swift
//  ModelClass
//
//  Created by Apple on 10/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    //[Accesorys(watches: "fasttrack", shoes: "nike", sunglass: "raybon"),Accesorys(watches: "casio", shoes: "Bata", sunglass: "gucci")]
    
    
    
    var items: [Accesorys]?
    
    let iteambrands = "itembrand"
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.tableFooterView = UIView()
        let object = Accesorys(watches: "fasttrack", shoes: "nike", sunglass: "raybon", subItems: [SubItems(itemName: "Bata", itemImage: "BataImage")])
        items = [object]
        // Do any additional setup after loading the view, typically from a nib
        
    }
}
extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func tableview(_ tableview: UITableView, numberofSection section: Int) -> Int {
        return items?.count ?? 0
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items?[section].subItems?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
        // let model = items[indexPath.row]
        
        if let itemImage = items?[indexPath.section].subItems?[indexPath.row].itemImage, let itemName = items?[indexPath.section].subItems?[indexPath.row].itemName {
            cell?.detailTextLabel?.text = itemImage
            cell?.textLabel?.text = itemName
        }
        
        cell?.accessoryType = .detailButton
        cell?.backgroundColor = .green
        cell?.selectionStyle = .gray
        return cell ?? UITableViewCell()
        
}
}

        // Do any additional setup after loading the view, typically from a nib.

