//
//  tablemodelclass.swift
//  ModelClass
//
//  Created by Apple on 10/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
struct Accesorys {
    var watches: String?
    var shoes: String?
    var sunglass: String?
    var subItems: [SubItems]?
}
struct SubItems {
    var itemName: String?
    var itemImage: String?
}
