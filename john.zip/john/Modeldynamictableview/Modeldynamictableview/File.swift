//
//  File.swift
//  Modeldynamictableview
//
//  Created by Apple on 10/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation

struct  Countries{
    var teamName: String?
    var Details: [Details]?
    
    }

struct  Details  {
    
    var playerimage: String?
    var playername: String?
    var playerstyle: String?
    var strikerate: String?
}
