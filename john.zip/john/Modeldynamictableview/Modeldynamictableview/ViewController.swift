//
//  ViewController.swift
//  Modeldynamictableview
//
//  Created by Apple on 10/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tableviewLayer: UITableView!
    var reuseIdentifier = "tablecell"
    var Teams: [Countries]?
    var dataModels = [Countries]()
   
    

    override func viewDidLoad() {
        super.viewDidLoad()
        tableviewLayer.tableFooterView = UIView()
        
        let cricket = Countries(teamName: "INDIA", Details: [Details(playerimage: "rohit", playername: "Rohit Sharma", playerstyle: "Right Hand Batsman", strikerate: "183.19")])
         Teams = [cricket]
        // Do any additional setup after loading the view, typically from a nib.
    }

}


extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return Teams?.count ?? 0
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Teams?[section].Details?.count ?? 0
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        
//        let cell = tableviewLayer.dequeueReusableCell(withIdentifier: reuseIdentifier) as! Majorcell
        let cell = tableviewLayer.dequeueReusableCell(withIdentifier: reuseIdentifier) as! tablecell
        //getting the hero for the specified position
        
        
        model = dataModels [indexPath.row]
        
        //displaying values
      
        
        return cell
        
    }
    
  
}
