//
//  ViewController.swift
//  PageViewController
//
//  Created by Apple on 02/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var pageViewControllers: UIPageViewController!
    var controls = [UIViewController]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
 pageViewControllers = UIPageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal                    , options: nil)
        pageViewControllers.dataSource = self
        pageViewControllers.delegate = self
    
        
        
        addChild(pageViewControllers)
        view.addSubview(pageViewControllers.view)
//        self.pageContollerSetup()
        
        NSLayoutConstraint.activate([pageViewControllers.view.leadingAnchor.constraint(equalTo: self.view.leadingAnchor), pageViewControllers.view.trailingAnchor.constraint(equalTo: self.view.trailingAnchor), pageViewControllers.view.topAnchor.constraint(equalTo: self.view.topAnchor), pageViewControllers.view.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)])

        
        let firstViewController = FirstViewController()
        firstViewController.view.backgroundColor = .blue
        controls.append(firstViewController)
        
        let secondViewController = SecondViewController()
        secondViewController.view.backgroundColor = .cyan
        controls.append(secondViewController)
        
        let thirdViewController = ThirdViewController()
        thirdViewController.view.backgroundColor = .yellow
        controls.append(thirdViewController)
        
        pageViewControllers.setViewControllers([controls[0]], direction: .forward, animated: false)
        
        }
}
extension ViewController: UIPageViewControllerDelegate, UIPageViewControllerDataSource {
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        if let index = controls.firstIndex(of: viewController){
            if index > 0 {
                return controls[index - 1]
            }else {
                return nil
            }
        }
        return nil
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        if let index = controls.firstIndex(of: viewController) {
            if index < controls.count - 1{
                return controls[index + 1]
            } else {
                return nil
            }
        }
        return nil
    }
    
 
    
}
