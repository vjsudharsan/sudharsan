//
//  Modelclass.swift
//  ZohoTask
//
//  Created by Apple on 04/02/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import Foundation
