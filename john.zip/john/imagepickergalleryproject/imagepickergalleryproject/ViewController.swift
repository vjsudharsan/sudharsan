//
//  ViewController.swift
//  imagepickergalleryproject
//
//  Created by Apple on 09/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    
    
    @IBOutlet weak var imageLayer: UIImageView!
    @IBOutlet weak var buttonLayer: UIButton!
    
    let imageLoader = UIImagePickerController()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func buttonWork(_ sender: Any){
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
            imageLoader.delegate = self
            imageLoader.sourceType = .savedPhotosAlbum
            imageLoader.allowsEditing = false
            present(imageLoader, animated: true, completion: nil)
        }
        
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        
        if let picture = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            imageLayer.image = picture
        }
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            dismiss(animated: true, completion: nil)
    }
   
    }
}
