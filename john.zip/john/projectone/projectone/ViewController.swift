//
//  ViewController.swift
//  projectone
//
//  Created by Apple on 06/11/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    lazy var customlabel: UILabel = {
        let teamlabel = UILabel()
        teamlabel.text = " Team Name"
        teamlabel.textAlignment = .center
        teamlabel.textColor = .blue
        teamlabel.font = UIFont.systemFont(ofSize: 30)
        teamlabel.translatesAutoresizingMaskIntoConstraints = false
        teamlabel.numberOfLines = 0
        teamlabel.lineBreakMode = .byWordWrapping
        return teamlabel
    }()
    lazy var customTextField: UITextField = {
        let teamname = UITextField()
        teamname.placeholder = " Enter the team name "
        teamname.textAlignment = .center
        teamname.textColor = .white
        teamname.backgroundColor = .red
        teamname.font = UIFont.systemFont(ofSize: 25)
        teamname.borderStyle = UITextField.BorderStyle.roundedRect
        teamname.translatesAutoresizingMaskIntoConstraints = false
        teamname.keyboardType = UIKeyboardType.namePhonePad
        return teamname
        
    }()
    lazy var newlabel: UILabel = {
        let scorelabel = UILabel()
        scorelabel.text = " Team Score"
        scorelabel.textAlignment = .center
        scorelabel.textColor = .blue
        scorelabel.font = UIFont.systemFont(ofSize: 30)
        scorelabel.translatesAutoresizingMaskIntoConstraints = false
        scorelabel.numberOfLines = 0
        scorelabel.lineBreakMode = .byWordWrapping
        return scorelabel
        }()
    lazy var newTextField: UITextField = {
        let score = UITextField()
        score.placeholder = " Enter the Score"
        score.textAlignment = .center
        score.textColor = .white
        score.backgroundColor = .red
        score.font = UIFont.systemFont(ofSize: 25)
        score.borderStyle = UITextField.BorderStyle.roundedRect
        score.translatesAutoresizingMaskIntoConstraints = false
        score.keyboardType = UIKeyboardType.numbersAndPunctuation
        return score
    }()
    
    lazy var primaryButton: UIButton = {
        let nextbutton = UIButton ()
        nextbutton.setTitle("Next", for: .normal)
        nextbutton.backgroundColor = .blue
        nextbutton.setTitleColor(.white, for:.normal)
        nextbutton.layer.cornerRadius = 9.0
        nextbutton.translatesAutoresizingMaskIntoConstraints = false
        return nextbutton
        
        }()
    
    lazy var secondaryButton: UIButton = {
        let cancelbutton = UIButton ()
        cancelbutton.setTitleColor(.white, for: .normal)
        cancelbutton.setTitle("Cancel", for: .normal)
        cancelbutton.backgroundColor = .blue
        cancelbutton.layer.cornerRadius = 9.0
        cancelbutton.translatesAutoresizingMaskIntoConstraints = false
        return cancelbutton
        
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupview()
        primaryButton.addTarget(self, action: #selector (primaryButtonAction(_sender:)), for: .touchUpInside)
        secondaryButton.addTarget(self, action: #selector(secondaryButtonAction(_sender:)), for: .touchUpInside)
       
        // Do any additional setup after loading the view, typically from a nib.
        self.view.backgroundColor = .white
        primaryButton.isEnabled = false
        primaryButton.backgroundColor = .blue
        customTextField.addTarget(self, action: #selector(ViewController.textFieldDidChange(_:)), for: .editingChanged)
        newTextField.addTarget(self, action: #selector(ViewController.textFieldDidChange(_:)), for: .editingChanged)
        
    }
    @objc func primaryButtonAction (_sender: UIButton) {
     print(" next button activated")
    }
    @objc func secondaryButtonAction (_sender: UIButton) {
    print (" cancel button activated")
        }
    @objc func textFieldDidChange(_ textfield:UITextField){
        if customTextField.text == "" || newTextField.text == ""{
            primaryButton.isEnabled = false
            primaryButton.backgroundColor = .blue
        }
        else
        {
            primaryButton.isEnabled = true
            primaryButton.backgroundColor = .green
        }
    }
    
    
    
    func setupview() {
        self.view.addSubview(customlabel)
        self.view.addSubview(customTextField)
        customTextField.delegate = self
        self.view.addSubview(newlabel)
        self.view.addSubview(newTextField)
        newTextField.delegate = self
        self.view.addSubview(primaryButton)
        self.view.addSubview(secondaryButton)
        
        NSLayoutConstraint.activate([customlabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15), customlabel.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15), customlabel.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 15)])
        
        NSLayoutConstraint.activate([customTextField.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15), customTextField.trailingAnchor.constraint(equalTo:self.view.trailingAnchor, constant: -15), customTextField.topAnchor.constraint(equalTo: self.customlabel.bottomAnchor, constant: 15), customTextField.heightAnchor.constraint(greaterThanOrEqualToConstant: 44)])
        
        NSLayoutConstraint.activate([newlabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15), newlabel.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15), newlabel.topAnchor.constraint(equalTo: self.customTextField.bottomAnchor, constant: 15)])
        
        NSLayoutConstraint.activate([newTextField.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15),newTextField.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15), newTextField.topAnchor.constraint(equalTo: self.newlabel.bottomAnchor, constant: 15), newTextField.heightAnchor.constraint(greaterThanOrEqualToConstant: 44)])
        
        NSLayoutConstraint.activate([primaryButton.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 30), primaryButton.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -30), primaryButton.topAnchor.constraint(equalTo: self.newTextField.bottomAnchor, constant: 20)])
        
        NSLayoutConstraint.activate([secondaryButton.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 30), secondaryButton.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -30), secondaryButton.topAnchor.constraint(equalTo: self.primaryButton.bottomAnchor, constant: 20)])
}
}
extension ViewController: UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == customTextField {
            customTextField.resignFirstResponder()
            newTextField.becomeFirstResponder()
        }
        else
        {
            newTextField.resignFirstResponder()
        }
        
     return true
    }
    
}

