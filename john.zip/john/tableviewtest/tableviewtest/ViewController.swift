//
//  ViewController.swift
//  tableviewtest
//
//  Created by Apple on 26/11/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var tablelistview: UITableView!
    var grocerylist = ["onion", "gabbage", "brinjal", "lemon","tomato", "potato" ]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}
extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return grocerylist.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tablelistview.dequeueReusableCell(withIdentifier: "listTableViewCell") as! listTableViewCell
        cell.labelName.text = grocerylist[indexPath.row]
        return cell
    }
    
    
}







