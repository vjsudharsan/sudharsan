//
//  placeTableViewCell.swift
//  Segmentcontrollprogramatic
//
//  Created by Apple on 23/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class placeTableViewCell: UITableViewCell {
    lazy var rowImage: UIImageView = {
        var cellimage = UIImageView ()
        cellimage.translatesAutoresizingMaskIntoConstraints = false
        return cellimage
    }()
    lazy var rowLable: UILabel = {
        var cellLabel = UILabel ()
        cellLabel.backgroundColor = .white
        cellLabel.font = UIFont.systemFont(ofSize: 20)
        cellLabel.translatesAutoresizingMaskIntoConstraints = false
        return cellLabel
    }()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .default, reuseIdentifier: reuseIdentifier)
        self.cellsetup()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func cellsetup() {
        self.contentView.addSubview(rowLable)
        
        NSLayoutConstraint.activate([rowLable.leadingAnchor.constraint(equalTo: self.contentView.leadingAnchor, constant: 10),rowLable.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor, constant: -10),rowLable.topAnchor.constraint(equalTo: self.contentView.topAnchor, constant: 10),rowLable.bottomAnchor.constraint(equalTo: self.contentView.bottomAnchor, constant: -10)])
    }

}
