//
//  MapViewController.swift
//  Segmentcontrollprogramatic
//
//  Created by Apple on 23/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit
import MapKit

class MapViewController: UIViewController {
    lazy var mkmapview: MKMapView = {
        var mapview = MKMapView()
        mapview.translatesAutoresizingMaskIntoConstraints = false
        return mapview
    }()
    let locationmapview = CLLocationManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .brown
        self.mapsetup()
        self.authorizationStatusCheck()
        
        
        let locations =
            [Location(title:"Coimbatore",latitude: 11.017363, longitude: 76.958885),
             Location(title:"Chennai",latitude: 13.067439, longitude: 80.237617),
            Location(title:"Salam",latitude: -6.802353,longitude: 39.279556),
            Location(title: "kanyakumari",latitude: 8.088306,longitude: 77.538452),
            Location(title:"Namakal",latitude: 11.229592,longitude: 78.171158),
            Location(title:"Thanjur",latitude: 10.786999,longitude: 79.137825),
            Location(title: "tuthucorin",latitude: 8.764166,longitude: 78.134834),
            Location(title:"Madurai",latitude: 9.939093,longitude: 78.121719)]

        self.fetchHotelsonMap(locations)

        // Do any additional setup after loading the view.
    }
    func locationmanager() {
        if CLLocationManager.locationServicesEnabled() {
            
        }else {
            
        }
    }
    func authorizationStatusCheck(){
        switch CLLocationManager.authorizationStatus() {
        case.authorizedAlways:mkmapview.showsUserLocation = true
        case.authorizedWhenInUse: break
        case.denied: break
        case.notDetermined: locationmapview.requestWhenInUseAuthorization()
        mkmapview.showsUserLocation = true
        case.restricted:break
        }
    }
    func fetchHotelsonMap(_ locations:[Location]) {
        for Location in locations {
            let annotations = MKPointAnnotation()
            annotations.title = Location.title
            annotations.coordinate = CLLocationCoordinate2D(latitude: Location.latitude, longitude: Location.longitude)
            mkmapview.addAnnotation(annotations)
            
            
        }
    }

    func mapsetup() {
        self.view.addSubview(mkmapview)
        
        NSLayoutConstraint.activate([mkmapview.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 10),mkmapview.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: 0),mkmapview.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 0),mkmapview.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: 0)])
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
