//
//  ViewController.swift
//  Segmentcontrollprogramatic
//
//  Created by Apple on 23/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
//    var segmentControlButton = UISegmentedControl(items: ["Place","Map","Contact"])
//    @objc var segmentButton = [UIViewController]()
    let placevc = PlaceViewController()
    let mapvc = MapViewController()
    let contactvc = ContactViewController()
    
    lazy var SegmentControlButtons: UISegmentedControl = {
        var SegmentButton = UISegmentedControl(items: ["Place","Map","Contact"])
//        SegmentButton.selectedSegmentIndex = 3
//        SegmentButton.setTitle("Place", forSegmentAt: 0)
//        SegmentButton.setTitle("Map", forSegmentAt: 1)
//        SegmentButton.setTitle("Contact", forSegmentAt: 2)
        SegmentButton.translatesAutoresizingMaskIntoConstraints = false
        return SegmentButton
    }()
    lazy var MainEmptyview: UIView = {
        var Emptyview = UIView()
        Emptyview.backgroundColor = .yellow
        Emptyview.translatesAutoresizingMaskIntoConstraints = false
        return Emptyview
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setupview()
        // Do any additional setup after loading the view, typically from a nib.
    }
    func setupview() {
        addChild(placevc)
        addChild(mapvc)
        addChild(contactvc)
        
        self.MainEmptyview.addSubview(placevc.view)
        self.MainEmptyview.addSubview(mapvc.view)
        self.MainEmptyview.addSubview(contactvc.view)
        
        
        placevc.didMove(toParent: self)
        mapvc.didMove(toParent: self)
        contactvc.didMove(toParent: self)
        placevc.view.isHidden = false
        mapvc.view.isHidden = true
        contactvc.view.isHidden = true
        
        
        self.view.addSubview(SegmentControlButtons)
        self.view.addSubview(MainEmptyview)
//        SegmentControlButtons.frame = CGRect(x: 35, y: 100, width: 350, height: 50)
//        MainEmptyview.frame = CGRect(x: 50, y: 100, width: 350, height:100)
        SegmentControlButtons.addTarget(self, action: #selector(segmentButtonAction(sender:)), for: .valueChanged)
        
        

        NSLayoutConstraint.activate([SegmentControlButtons.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 20),SegmentControlButtons.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20),SegmentControlButtons.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 20)])
        NSLayoutConstraint.activate([MainEmptyview.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 0),MainEmptyview.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: 0),MainEmptyview.topAnchor.constraint(equalTo: self.SegmentControlButtons.bottomAnchor, constant: 0),MainEmptyview.bottomAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.bottomAnchor, constant: 0)])
    }
    @objc func segmentButtonAction(sender: UISegmentedControl) {
        placevc.view.isHidden = true
        mapvc.view.isHidden = true
        contactvc.view.isHidden = true
        if SegmentControlButtons.selectedSegmentIndex == 0 {
            placevc.view.isHidden = false
        }else if SegmentControlButtons.selectedSegmentIndex == 1 {
            mapvc.view.isHidden = false
        } else {
            contactvc.view.isHidden = false
        }
    }


}




