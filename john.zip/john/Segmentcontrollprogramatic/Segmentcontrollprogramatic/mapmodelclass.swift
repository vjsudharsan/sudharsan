//
//  mapmodelclass.swift
//  Segmentcontrollprogramatic
//
//  Created by Apple on 23/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import MapKit
struct Location {
    let title: String
    let latitude: CLLocationDegrees
    let longitude: CLLocationDegrees
}
