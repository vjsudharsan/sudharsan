//
//  ContactViewController.swift
//  Segmentcontrollprogramatic
//
//  Created by Apple on 23/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class ContactViewController: UIViewController {
//    let Collectionidenti = CollectionViewCell()
    var items = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"]
    
    lazy var collectionviewLayout: UICollectionView = {
        let collectionview = UICollectionView()
        collectionview.translatesAutoresizingMaskIntoConstraints = false
        return collectionview
    }()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .green
        self.setup()
        self.setupcollectionviewvertical()
        

        // Do any additional setup after loading the view.
    }
    func setup() {
        self.view.addSubview(collectionviewLayout)
        collectionviewLayout.delegate = self
        collectionviewLayout.dataSource = self
        
        
        NSLayoutConstraint.activate([collectionviewLayout.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 10),collectionviewLayout.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -10),collectionviewLayout.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 10),collectionviewLayout.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -10)])
    }
    func setupcollectionviewvertical() {
        collectionviewLayout.setContentOffset(collectionviewLayout.contentOffset, animated:false) // Stops collection view if it was scrolling.
        let cellSize = CGSize(width:collectionviewLayout.frame.size.width/5 , height:100)
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.itemSize = cellSize
        layout.sectionInset = UIEdgeInsets(top: 1, left: 1, bottom: 1, right: 1)
        layout.minimumLineSpacing = 15.0
        layout.minimumInteritemSpacing = 15.0
        collectionviewLayout.setCollectionViewLayout(layout, animated: true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension ContactViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return items.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
         let cell = collectionviewLayout.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath as IndexPath) as! CollectionViewCell
        cell.cellLable.text = items[indexPath.row]
        return cell
    }
    
    
}
