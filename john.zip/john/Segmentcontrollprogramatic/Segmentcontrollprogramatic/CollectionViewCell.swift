//
//  CollectionViewCell.swift
//  Segmentcontrollprogramatic
//
//  Created by Apple on 24/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    lazy var cellLable: UILabel = {
        var LableName = UILabel()
        LableName.font = UIFont.systemFont(ofSize: 20)
        LableName.textAlignment = .left
        LableName.translatesAutoresizingMaskIntoConstraints = false
        LableName.textColor = .white
        return LableName
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.cellsetup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func cellsetup(){
        self.contentView.addSubview(cellLable)
        
        NSLayoutConstraint.activate([cellLable.leadingAnchor.constraint(equalTo: self.contentView.trailingAnchor, constant: 10),cellLable.trailingAnchor.constraint(equalTo: self.contentView.leadingAnchor, constant: -10),cellLable.topAnchor.constraint(equalTo: self.contentView.topAnchor, constant: 10),cellLable.bottomAnchor.constraint(equalTo: self.contentView.bottomAnchor, constant: -10),])
    }
}
