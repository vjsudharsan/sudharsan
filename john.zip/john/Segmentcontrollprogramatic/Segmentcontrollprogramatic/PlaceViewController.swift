//
//  PlaceViewController.swift
//  Segmentcontrollprogramatic
//
//  Created by Apple on 23/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class PlaceViewController: UIViewController {
    lazy var placeTableView: UITableView = {
        var PlaceTable = UITableView()
        PlaceTable.backgroundColor = .white
        PlaceTable.layer.borderWidth = 3.0
//        PlaceTable.layer.borderColor = UIColor.black.cgColor
        PlaceTable.translatesAutoresizingMaskIntoConstraints = false
        return PlaceTable
    }()
    let States = ["coimbatore","Chennai","Salam","kanyakumari","Namakal","Thanjur","tuthucorin","Madurai"]

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .red
        self.tablesetupview()
        self.setup()

        // Do any additional setup after loading the view.
    }
    func tablesetupview() {
        
        self.view.addSubview(placeTableView)
        
        NSLayoutConstraint.activate([placeTableView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 10),placeTableView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: 0),placeTableView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 0),placeTableView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: 0)])
    }
    func setup(){
        placeTableView.delegate = self
        placeTableView.dataSource = self
        placeTableView.register(placeTableViewCell.self, forCellReuseIdentifier: "placeTableViewCell")
        placeTableView.estimatedRowHeight = 50
        placeTableView.tableFooterView = UIView()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension PlaceViewController: UITableViewDelegate,UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return States.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = placeTableView.dequeueReusableCell(withIdentifier: "placeTableViewCell", for: indexPath) as? placeTableViewCell else {
            return UITableViewCell()
        }
        cell.rowLable.text = States[indexPath.row]
        cell.accessoryType = .detailButton
        return cell
    }
    
    
}
