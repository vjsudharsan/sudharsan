//
//  ViewController.swift
//  defaulttableview
//
//  Created by Apple on 27/11/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var CarsTableView: UITableView!
    let listofCars = ["SWIFT", "ALTROZ", "CRETA", "VOlVO V3", "XUV 500", "BMW X3", "GLOSTER", "SONET", "GLC - BENZ", "HURACAN"]
    let listofBrand = ["SUZUKI","TATA","HYUNDAI","VOLVO","MAHINDRA","BMW","MG","KIA","BENZ","LAMBORGHINI"]
    let listofLogo = ["suzuki","tata","hyundai","volvo","mahindra","bmw","mg","kia","benz","lambo"]
    

    override func viewDidLoad() {
        super.viewDidLoad()
        CarsTableView.tableFooterView = UIView()
    
        

        // Do any additional setup after loading the view, typically from a nib.
    }


}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberofsections section: Int) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listofCars.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var space = CarsTableView.dequeueReusableCell(withIdentifier: "space")
        space = UITableViewCell(style: .subtitle, reuseIdentifier: "space")
        space?.textLabel?.text = listofCars[indexPath.row]
        space?.detailTextLabel?.text = listofBrand[indexPath.row]
        space?.accessoryType = .disclosureIndicator
        space?.selectionStyle = .default
        space?.imageView?.image = UIImage(named: "\(listofLogo[indexPath.row])")
        return space ?? UITableViewCell()
    }
    
    
}
