//
//  ViewController.swift
//  SwitchSampleCodingProject
//
//  Created by Apple on 04/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var subSwitch: UISwitch!
    @IBOutlet weak var firstLabel: UILabel!
    @IBOutlet weak var secondLabel: UILabel!
    @IBOutlet weak var MainSwitch: UISwitch!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        subSwitch = UISwitch()
        subSwitch.frame.origin = CGPoint(x: MainSwitch.frame.origin.x, y: MainSwitch.frame.origin.y+100)
        subSwitch.setOn(true, animated: true)
        self.view.addSubview(subSwitch)
        subSwitch.addTarget(self, action: #selector(secondSwitchAction(_:)), for: UISwitch.Event.valueChanged)
    }

    
    @IBAction func turnSwitchAction(_ sender: UISwitch) {
       
        let switchStatus:Bool = sender.isOn
        if (switchStatus) {
        
            
            firstLabel.text = "first switch turned off"
            secondLabel.text = "second switch turned on"
            subSwitch.setOn(false, animated: true)
        } else {
            firstLabel.text = "first switch turned on"
            secondLabel.text = "second switch turned off"
            subSwitch.setOn(true, animated: true)
            
        }
    }

    @objc func secondSwitchAction(_ senObj: UISwitch) {
        
        let switchStatus:Bool = senObj.isOn
        if (switchStatus) {
            firstLabel.text = "first switch turned on"
            secondLabel.text = "second switch turned off"
            MainSwitch.setOn(false, animated: true)
        } else {
            firstLabel.text = "first switch turned off"
            secondLabel.text = "second switch turned on"
            MainSwitch.setOn(true, animated: true)
        }
    }
    
    
    
}

