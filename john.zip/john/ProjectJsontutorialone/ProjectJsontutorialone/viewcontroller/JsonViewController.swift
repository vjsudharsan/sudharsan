//
//  JsonViewController.swift
//  ProjectJsontutorialone
//
//  Created by Apple on 31/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class JsonViewController: UIViewController {
    
    var viewModel = ViewModelSegment()
    @IBOutlet weak var tableViewContent: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
       viewModel.BundleSetup()
        tableViewContent.tableFooterView = UIView()
    }
    

}
extension JsonViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return viewModel.numberofSection()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberofRowsinSection(section: section)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableViewContent.dequeueReusableCell(withIdentifier: CommonConstants.reuseIdentifier) as! FirstTableViewCell
        if let object = viewModel.cellRowatIndexPath(indexpath: indexPath), let userID = object.userId {
            cell.userIDLabel.text = String(userID)
            cell.FirstNameLabel.text = object.firstName
            cell.lastNameLabel.text = object.lastName
            cell.PhoneNumberLabel.text = object.phoneNumber
            cell.emailIDLabel.text = object.emailAddress
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return viewModel.headerTitle(section: section)
    }
    
}
