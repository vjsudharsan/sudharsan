//
//  ModelclassSegment.swift
//  ProjectJsontutorialone
//
//  Created by Apple on 31/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation

struct ModelclassSegment: Decodable {
    var users: [UserElements]?
}

struct UserElements: Decodable {
    var userId: Int?
    var firstName: String?
    var lastName: String?
    var phoneNumber: String?
    var emailAddress: String?
    var subUsers: [UserElements]?
}

