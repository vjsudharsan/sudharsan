//
//  Constants.swift
//  ProjectJsontutorialone
//
//  Created by Apple on 31/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
struct CommonConstants {
    static let reuseIdentifier = "FirstTableViewCell"

}
