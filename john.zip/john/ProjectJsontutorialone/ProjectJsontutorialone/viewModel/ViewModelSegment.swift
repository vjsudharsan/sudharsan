//
//  ViewModelSegment.swift
//  ProjectJsontutorialone
//
//  Created by Apple on 31/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation


class ViewModelSegment {
    var modelClass: ModelclassSegment?
    
    
    func BundleSetup() {
        modelClass = Bundle.main.decode(ModelclassSegment.self, from: "newproject.json")
    }
    
    func numberofSection() -> Int {
          return modelClass?.users?.count ?? 0
    }
    
    func numberofRowsinSection(section: Int) -> Int {
      return modelClass?.users?[section].subUsers?.count ?? 0
        
    }
    
    func cellRowatIndexPath(indexpath: IndexPath) -> UserElements? {
        if let getObject = modelClass?.users?[indexpath.section].subUsers?[indexpath.row] {
            return getObject
        }
        return nil
    }
    func headerTitle(section: Int) -> String {
        
        if let title = modelClass?.users?[section].lastName {
            return title
        }
        return ""
    }
}
