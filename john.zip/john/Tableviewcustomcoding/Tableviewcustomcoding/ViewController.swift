//
//  ViewController.swift
//  Tableviewcustomcoding
//
//  Created by Apple on 01/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var firstcell = "tablecell"
    lazy var firsttable: UITableView = {
        let table = UITableView(frame: .zero, style: .grouped)
        table.translatesAutoresizingMaskIntoConstraints = false
        table.backgroundColor = .white
      return table
    }()
    // mobiles
    let images  = ["Samsung","Nokia","Vivo","Oppo","Redmi","Oneplus"]
    let brands = ["SAMSUNG","NOKIA", "VIVO","OPPO", "REDMI", "ONEPLUS"]
    let models = ["M31","1100", "S1 pro", " F17", "Poco x3 "," Nord"]
    let price = ["Rs 15,999","Rs 13,999","Rs 18,999","Rs 19,999","Rs 20,999","Rs 19,599"]
    
    //watches
    
    let watchimages = ["sonata", "titan", "fastrack", "armani", "rado","rolex"]
    let watchbrands = ["SONATA", "TITAN","FASTTRACK", "ARMANI","RADO", "ROLEX"]
    let watchmodels = [" Sporton 31", "Classic", "Y300", "AR 458", " Cool 100", "King 1000"]
    let watchprice = ["Rs 5,999", "Rs 8,999", "Rs 5,999", "Rs 10,999", "Rs 3,999", "Rs 20,999"]
    
    // glasses
    
    let glassimages = ["rayban", "hugo", "tomford", "valentino" ,"versace", "burberry"]
    let glassbrands = ["RAY.BAN", "HUGO", "TOM FORD", "VALENTINO", "VERSACE", "BURBERRY"]
    let glassmodels = [" Star boy", " Hzx 100", " TF 5000", "Cool star", "Rocker 1000", "Smoker 7000"]
    let glassprice = ["Rs 2,999", "Rs 3,999", "Rs 3,599", "Rs 5,999", "Rs 8,999", "Rs 9,999"]
    
    // shoes
    
    let shoeimages = ["fila", "reebok", "puma", "addidas", "nikee", "bata"]
    let shoebrands = ["FILA", "REEBOK", "PUMA", "ADDIDAS", "NIKE", "BATA"]
    let shoemodels = ["C-200", "R 350", "Puma 800", " ADZ 1289", "Nike 5500", "Bata 3300"]
    let shoeprice = ["7,999", "3,999", "8,999", "4,999", "9,999", "2,999"]
    
    let products = ["MOBILES","WATCHES","SUN GLASSES","SHOES"]
    let productimages = ["mobiles title","watch title","sunglass title","shoes title"]

    
    
        override func loadView() {
        super.loadView()
        self.setupview()
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addSubview(firsttable)
        self.tablesetup()
        // Do any additional setup after loading the view, typically from a nib.
    }

    func tablesetup(){
        firsttable.estimatedRowHeight = 500
        firsttable.dataSource = self
        firsttable.delegate = self
        firsttable.separatorColor = .none
        firsttable.separatorStyle = .singleLine
        firsttable.tableFooterView = UIView()
        firsttable.register(tablecell.self, forCellReuseIdentifier: firstcell)
        
        
    }
    func setupview(){
        self.view.addSubview(firsttable)
    
        
        NSLayoutConstraint.activate([firsttable.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 10),firsttable.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -10),firsttable.topAnchor.constraint(equalTo: self.view.topAnchor), firsttable.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)])
    }
    
    
}
extension ViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return products.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return brands.count
        }
        else if section == 1 {
            return watchbrands.count
        }
        else if section == 2 {
            return glassbrands.count
        }
        else{
            return shoebrands.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let room = firsttable.dequeueReusableCell(withIdentifier: firstcell, for: indexPath) as? tablecell else {
            return UITableViewCell()
        }
        if indexPath.section == 0 {
           room.imagefield.image = UIImage(named: images[indexPath.row])
            room.lablebrandname.text = brands[indexPath.row]
            room.lablemodelname.text = models[indexPath.row]
            room.lablepricetag.text = price[indexPath.row]
            room.layer.borderWidth = 2.0
            room.layer.cornerRadius = 10.0
            room.layer.borderColor = UIColor.black.cgColor
            room.accessoryType = .disclosureIndicator
            return room
            }
        else if indexPath.section == 1 {
            room.imagefield.image = UIImage(named: watchimages[indexPath.row])
            room.lablebrandname.text = watchbrands[indexPath.row]
            room.lablemodelname.text = watchmodels[indexPath.row]
            room.lablepricetag.text = watchprice[indexPath.row]
            room.layer.cornerRadius = 10.0
            room.layer.borderWidth = 2.0
            room.layer.borderColor = UIColor.black.cgColor
            room.accessoryType = .disclosureIndicator
            return room
        }
        else if indexPath.section == 2 {
            room.imagefield.image = UIImage(named: glassimages[indexPath.row])
            room.lablebrandname.text = glassbrands[indexPath.row]
            room.lablemodelname.text = glassmodels[indexPath.row]
            room.lablepricetag.text = glassprice[indexPath.row]
            room.layer.cornerRadius = 10.0
            room.layer.borderWidth = 2.0
            room.layer.borderColor = UIColor.black.cgColor
            room.accessoryType = .disclosureIndicator
            return room
        }
        else {
            room.imagefield.image = UIImage(named: shoeimages[indexPath.row])
            room.lablebrandname.text = shoebrands[indexPath.row]
            room.lablemodelname.text = shoemodels[indexPath.row]
            room.lablepricetag.text = shoeprice[indexPath.row]
            room.layer.cornerRadius = 10.0
            room.layer.borderWidth = 2.0
            room.layer.borderColor = UIColor.black.cgColor
            room.accessoryType = .disclosureIndicator
            return room
        }
        
 
    }
    
    
    
    
}
extension ViewController: UITableViewDelegate{

//    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
//        if section == 0 {
//            return "MOBILES"
//        } else if section == 1{
//            return "WATCHES"
//        }else if section == 2 {
//            return "COOLERS"
//        } else {
//            return "SHOES"
//        }
//    }
    
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let titleview = UIView()
        let productlable = UILabel()
        productlable.text = products[section]
        productlable.textAlignment = .center
        productlable.numberOfLines = 0
        productlable.textColor = .black
        productlable.lineBreakMode = .byWordWrapping
//        productlable.frame = CGRect(x: 20, y: 0, width: self.view.frame.width-30, height: 80)
        productlable.frame = CGRect(x:20, y: 0, width: self.view.frame.width-40, height: 80)
        titleview.addSubview(productlable)

        let productLogo = UIImageView()
        productLogo.image = UIImage(named: productimages[section])
        productLogo.frame = CGRect(x: 75, y: 0, width:80, height:80)
        titleview.addSubview(productLogo)
        return titleview
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 80
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}









