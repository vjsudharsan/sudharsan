//
//  ViewController.swift
//  Buttontesting
//
//  Created by Apple on 04/11/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var textFieldCountry: UITextField!
    @IBOutlet weak var textFieldState: UITextField!
    @IBOutlet weak var textFieldCity: UITextField!
    @IBOutlet weak var textFieldVillage: UITextField!
    @IBOutlet weak var textFieldPincode: UITextField!
    
    // Button
    @IBOutlet weak var buttonSubmit: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        textFieldPincode?.addDoneCancelToolbar(onDone: (target: self, action: #selector(doneButtonTappedForMyNumericTextField)))
    }
    @objc func doneButtonTappedForMyNumericTextField() {
        print("Done");
        if let Pincode = textFieldPincode.text {
            print(Pincode)
        }
        textFieldPincode.resignFirstResponder()
        
    }

    @IBAction func buttonSubmitAction(_ sender : UIButton) {
        print(sender.tag)
        if sender.tag == 1 {
            if let Country = textFieldCountry.text, let State = textFieldState.text, let City = textFieldCity.text, let Village = textFieldVillage.text, let Pincode = textFieldPincode.text {
                if Country.isEmpty {
                    print("Country name is empty")
                }
                else
                {
                    print("Country : \(Country)")
                }
                if State.isEmpty {
                    print("State name is empty")
                }
                else
                {
                    print(" State : \(State)")
                }
                if City.isEmpty {
                    print(" City name is empty")
                }
                else
                {
                    print("City : \(City)")
                }
                if Village.isEmpty {
                    print("Village name is empty")
                }
                else
                {
                    print("Village : \(Village)")
                }
                if Pincode.isEmpty {
                    print("Pincode is empty")
                }
                else
                {
                    print("Pincode : \(Pincode)")
                }
            }
        }
        else
        {
            print("Activated cancell button")
        }
        
    }

}
extension ViewController : UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == textFieldCountry {
            textFieldCountry.resignFirstResponder()
            textFieldState.becomeFirstResponder()
        }
        if textField == textFieldState {
            textFieldState.resignFirstResponder()
            textFieldCity.becomeFirstResponder()
        }
        if textField == textFieldCity {
            textFieldCity.resignFirstResponder()
            textFieldVillage.becomeFirstResponder()
        }
        if textField == textFieldVillage {
            textFieldVillage.resignFirstResponder()
            textFieldPincode.becomeFirstResponder()
        }
        else {
            textFieldPincode.resignFirstResponder()
        }
        return true
    }
    func textField(_ textField: UITextField,shouldChangeCharactersIn Range: NSRange, replacementString string: String) -> Bool
    {
        var maxLength: Int?
        let currentString: NSString = textField.text! as NSString
        if textField == textFieldCountry {
            maxLength = 15
        }
        else if textField == textFieldState {
            maxLength = 15
        }
        else if textField == textFieldCity {
            maxLength = 15
        }
        else if textField == textFieldVillage {
            maxLength = 15
        }
        else if textField == textFieldPincode {
            maxLength = 6
        }
   
        let newString: NSString =
            currentString.replacingCharacters(in: Range, with: string) as NSString
        return newString.length <= maxLength ?? 0
        
    }
  
}
extension UITextField {
    func addDoneCancelToolbar(onDone: (target: Any, action: Selector)? = nil, onCancel: (target: Any, action: Selector)? = nil) {
        let onCancel = onCancel ?? (target: self, action: #selector(cancelButtonTapped))
        let onDone = onDone ?? (target: self, action: #selector(doneButtonTapped))
        let toolbar: UIToolbar = UIToolbar()
        toolbar.barStyle = .default
        toolbar.items = [
            UIBarButtonItem(title: "Cancel", style: .plain, target: onCancel.target, action: onCancel.action),
            UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: self, action: nil),
            UIBarButtonItem(title: "Done", style: .done, target: onDone.target, action: onDone.action)
        ]
        toolbar.sizeToFit()
        
        self.inputAccessoryView = toolbar
        // Default actions:
        
        
    }
    
    @objc func doneButtonTapped() { self.resignFirstResponder() }
    @objc func cancelButtonTapped() { self.resignFirstResponder() }
    
}
