//
//  Firstmodelclass.swift
//  Dynamictableboard
//
//  Created by Apple on 11/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation

struct cricket {
    var Playername : String?
    var Playertype : String?
    var playerclass : String?
}
