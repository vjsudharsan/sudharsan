//
//  ViewController.swift
//  Dynamictableboard
//
//  Created by Apple on 11/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var reuseIdentifier = "FirstTableViewCell"
      var sports : [cricket]?
    var Datamodels = [cricket]()
    
   
    @IBOutlet weak var Firstableview: UITableView!
   
    override func viewDidLoad() {
        super.viewDidLoad()
        Firstableview.tableFooterView = UIView()
        
    let  object = cricket[()]
        

        
        
        // Do any additional setup after loading the view, typically from a nib.
        
     
        
    }


}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return sports?.count ?? 0
    }
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
   let cell = Firstableview.dequeueReusableCell(withIdentifier:"FirstTableViewCell") as! FirstTableViewCell
        
//        if let strikerate = sports?[indexPath.section].subfield?[indexPath.row].strikrate,
//        let average = sports?[indexPath.section].subfield?[indexPath.row].average,
//            let battingaverage = sports?[indexPath.section].subfield?[indexPath.row].battingaverage
    
        if let _ = sports?[indexPath.row].Playername,
            let _ = sports?[indexPath.row].Playertype,
            let _ = sports?[indexPath.row].playerclass
        {
            
            
            let model: cricket
    
            model = Datamodels[indexPath.row]
    
            cell.Firstlabel.text = model.Playername
            
            cell.Secondlabel.text = model.Playertype
            cell.Thirdlabel.text = model.playerclass
//
            
            
            
            
            
        }
        
        
        
        
     return cell
    }
    
  
}
