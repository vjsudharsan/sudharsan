//
//  FirstTableViewCell.swift
//  Dynamictableboard
//
//  Created by Apple on 11/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class FirstTableViewCell: UITableViewCell {
    @IBOutlet weak var Firstimage: UIImageView!
    @IBOutlet weak var Firstlabel: UILabel!
    @IBOutlet weak var Secondlabel: UILabel!
    @IBOutlet weak var Thirdlabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
