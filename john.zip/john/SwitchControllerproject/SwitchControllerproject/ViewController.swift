//
//  ViewController.swift
//  SwitchControllerproject
//
//  Created by Apple on 04/01/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import UIKit
class ViewController: UIViewController {
    
    // This UISwitch object is create programmatically in source code.
    var switch1 : UISwitch!
    // Reference to the test label.
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var label2: UILabel!
    
    // Reference to the UISwitch in Main.storyboard.
    @IBOutlet weak var ModelSwitch: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Get the first UISwitch object's x, y location value.
        let switch0Frame: CGRect = ModelSwitch.frame
        let switch0Y: CGFloat = switch0Frame.origin.y
        let switch0X:CGFloat = switch0Frame.origin.x
        
        // Create the second UISwitch object.
        switch1 = UISwitch()
        
        // Set the second UISwitch object's x, y location value. The second UISwitch is located below the first one.
        switch1.frame.origin = CGPoint(x: switch0X, y:switch0Y + 100)
        
        // The second UISwitch is turned on by default.
        switch1.setOn(true, animated: true)
        
        // Register a function to process second UISwitch's value changed event.
        switch1.addTarget(self, action: #selector(turnSecondSwitch), for: UIControl.Event.valueChanged)
        
        // Add the second UISwitch to the screen root view.
        self.view.addSubview(switch1)
        
    }
    // This function will be invoked when the first UISwitch component is pressed.
    @IBAction func turnSwitch(_ sender: UISwitch) {
        
        // Get first UISwitch current status.
        let switchStatus:Bool = sender.isOn
        
        // Change the label text and second UISwitch status accordingly.
        if(switchStatus){
            label.text = "First switch is turned on"
            label2.text = "Second switch is turned off"
            
            switch1.setOn(false, animated: true)
        }else{
            label.text = "First switch is turned off"
            label2.text = "Second switch is turned on"
            
            switch1.setOn(true, animated: true)
        }
        
    }
    
    // This function will be called when user turn on/off the second UISwitch object.
    @objc func turnSecondSwitch(srcObj: UISwitch){
        
        // Get second UISwitch current status.
        let switchStatus:Bool = srcObj.isOn
        
        // Change the label text and first UISwitch status accordingly.
        if(switchStatus){
            label.text = "First switch turned off"
            label2.text = "Second switch is turned on"
            
            ModelSwitch.setOn(false, animated: true)
        }else{
            label.text = "First switch turned on"
            label2.text = "Second switch is turned off"
            
            ModelSwitch.setOn(true, animated: true)
        }
        
    }
    
}

