//
//  modellist.swift
//  Mapviewmkproject
//
//  Created by Apple on 09/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import MapKit

struct Villages {
    var villageName: String
    var lattitude: CLLocationDegrees
    var longitude: CLLocationDegrees
}
