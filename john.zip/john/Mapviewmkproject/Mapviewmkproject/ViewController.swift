//
//  ViewController.swift
//  Mapviewmkproject
//
//  Created by Apple on 09/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController {
    @IBOutlet weak var routeMap: MKMapView!
    
    
    
    
    
    
    
    
    lazy var mymapview: MKMapView = {
        let mymap = MKMapView()
        return mymap
        
    }()
    
    let myRouteMap = CLLocationManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.AuthorizationCheck()
        
        let areas = [Villages(villageName: "brook fields", lattitude:11.0168, longitude:76.9558), Villages(villageName: "fun mall",lattitude:11.025,longitude:77.0108) ]
        self.fetchVillagesonmap(areas)
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    func locationService(){
        if CLLocationManager.locationServicesEnabled(){
    }
    else {
    
    }
}
    
    
    func AuthorizationCheck(){
        switch CLLocationManager.authorizationStatus(){
            
        case .notDetermined:
            myRouteMap.requestWhenInUseAuthorization()
            routeMap.showsUserLocation = true
        case .restricted:
            break
        case .denied:
            break
        case .authorizedAlways:
            routeMap.showsUserLocation = true
        case .authorizedWhenInUse:
            break
        
        }
        
        
    }

    func fetchVillagesonmap(_ areas: [Villages]){
        for Villages in areas {
            let annotations = MKPointAnnotation()
//            annotations.title = Villages.villageName
            annotations.coordinate = CLLocationCoordinate2D(latitude: Villages.lattitude, longitude: Villages.longitude)
            routeMap.addAnnotation(annotations)
            
            
        }
        
    }
}
