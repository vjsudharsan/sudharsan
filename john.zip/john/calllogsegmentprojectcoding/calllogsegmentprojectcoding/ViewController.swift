//
//  ViewController.swift
//  calllogsegmentprojectcoding
//
//  Created by Apple on 23/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let allVc = AllViewController()
    let missedVc = MissedViewController()
    let receivedVc = ReceivedViewController()
    
    lazy var dummyView: UIView = {
        var mainView = UIView()
        mainView.translatesAutoresizingMaskIntoConstraints = false
        mainView.backgroundColor = .cyan
        return mainView
    }()

    lazy var segmentSection: UISegmentedControl = {
        var segmentHandler = UISegmentedControl(items: ["All", "Missed", "Received"])
        segmentHandler.translatesAutoresizingMaskIntoConstraints = false
        segmentHandler.backgroundColor = .white
        segmentHandler.tintColor = .black
        return segmentHandler
    }()
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupview()
        // Do any additional setup after loading the view, typically from a nib.
    }

    func setupview() {
        
        self.dummyView.addSubview(allVc.view)
        self.dummyView.addSubview(missedVc.view)
        self.dummyView.addSubview(receivedVc.view)
        
        addChild(allVc)
        addChild(missedVc)
        addChild(receivedVc)
        
        allVc.didMove(toParent: self)
        missedVc.didMove(toParent: self)
        receivedVc.didMove(toParent: self)
        allVc.view.isHidden = true
        
        
        
        
        
        
        
        
        
        
        
        
        missedVc.view.isHidden = true
        receivedVc.view.isHidden = true
        
        self.view.addSubview(segmentSection)
        self.view.addSubview(dummyView)
        
        
        segmentSection.addTarget(self, action: #selector(segmentHandlingAction(sender:)), for: .valueChanged)
        
        NSLayoutConstraint.activate([segmentSection.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 20 ), segmentSection.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20), segmentSection.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 10)])
        
        NSLayoutConstraint.activate([dummyView.topAnchor.constraint(equalTo: self.segmentSection.bottomAnchor, constant: 10), dummyView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 0), dummyView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: 0), dummyView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: 0)])
    }

    @objc func segmentHandlingAction(sender: UISegmentedControl) {
        
        allVc.view.isHidden = true
        missedVc.view.isHidden = true
        receivedVc.view.isHidden = true
        
        if segmentSection.selectedSegmentIndex == 0 {
            allVc.view.isHidden = false
        }
        else if segmentSection.selectedSegmentIndex == 1 {
            missedVc.view.isHidden = false
        }
        else {
            receivedVc.view.isHidden = false
        }
    }
    
    
    
    
    
}

