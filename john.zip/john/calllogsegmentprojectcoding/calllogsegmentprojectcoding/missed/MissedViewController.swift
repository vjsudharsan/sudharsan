//
//  MissedViewController.swift
//  calllogsegmentprojectcoding
//
//  Created by Apple on 23/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class MissedViewController: UIViewController {

    lazy var missedTableView: UITableView = {
        var missedTable = UITableView()
//        missedTable.backgroundColor = .cyan
        missedTable.translatesAutoresizingMaskIntoConstraints = false
        return missedTable
    }()
    
    
    let contactNames =  ["durai anna","hari","kavin","sanjeev","dinesh","appa","amma","brother","machi","frnd 1","nschool","periyasamy sir"]
    let contactNumbers = ["9842186976","8956426389","9856741238","9698763556","7418694323","8870598487","9842186976","8956426389","9856741238","9698763556","7418694323","8870598487"]
    let callDetails = [" 05.32 PM", "01.32PM", "Dec 22 08.57PM ","Dec 22 11.05 AM"," Dec 22 09.27AM","Dec 21 08.23 PM","Dec 21 06.45PM","Dec 20 09.56 PM","Dec 19 11.11 AM","Dec 19 10.00AM","Dec 18 10.10AM","DEC 17 09.23PM"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .cyan
        self.tablesetup()
        self.tablesetupview()
        
        // Do any additional setup after loading the view.
    }
    
    func tablesetupview(){
        self.view.addSubview(missedTableView)
        
        NSLayoutConstraint.activate([missedTableView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 0), missedTableView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 0), missedTableView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: 0), missedTableView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: 0)])
    }
    
    
    
    func tablesetup() {
        missedTableView.delegate = self
        missedTableView.dataSource = self
        missedTableView.register(missedTableViewCell.self, forCellReuseIdentifier: "missedTableViewCell")
        missedTableView.estimatedRowHeight = 60
        missedTableView.tableFooterView = UIView()
        
    }
    
    
}
extension MissedViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return callDetails.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = missedTableView.dequeueReusableCell(withIdentifier: "missedTableViewCell", for: indexPath) as? missedTableViewCell else {
            return UITableViewCell()
        }
        cell.contactNameLable.text = contactNames[indexPath.row]
        cell.contactNumberLable.text = contactNumbers[indexPath.row]
        cell.callDetailsLable.text = callDetails[indexPath.row]
        //        cell.layer.borderColor = UIColor.white.cgColor
        //        cell.layer.borderWidth = 3.0
        //        cell.layer.cornerRadius = 3.0
        //        cell.layer.backgroundColor = UIColor.orange.cgColor
        
        return cell
    }
    
    
}

