//
//  ReceivedViewController.swift
//  calllogsegmentprojectcoding
//
//  Created by Apple on 23/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class ReceivedViewController: UIViewController {

    lazy var receivedTableView: UITableView = {
        var receivedTable = UITableView()
//        receivedTable.backgroundColor = .red
        receivedTable.translatesAutoresizingMaskIntoConstraints = false
        return receivedTable
    }()
    
    
    let contactNames =  ["sanjeev","dinesh","appa","amma","brother","machi","frnd 1","durai anna","hari","kavin","nschool","periyasamy sir"]
    let contactNumbers = ["9842186976","8956426389","9856741238","9698763556","7418694323","8870598487","9842186976","8956426389","9856741238","9698763556","7418694323","8870598487"]
    let callDetails = [" 05.32 PM", "01.32PM", "Dec 22 08.57PM ","Dec 22 11.05 AM"," Dec 22 09.27AM","Dec 21 08.23 PM","Dec 21 06.45PM","Dec 20 09.56 PM","Dec 19 11.11 AM","Dec 19 10.00AM","Dec 18 10.10AM","DEC 17 09.23PM"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .cyan
        self.tablesetup()
        self.tablesetupview()
        
        // Do any additional setup after loading the view.
    }
    
    func tablesetupview(){
        self.view.addSubview(receivedTableView)
        
        NSLayoutConstraint.activate([receivedTableView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 0), receivedTableView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 0), receivedTableView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: 0), receivedTableView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: 0)])
    }
    
    
    
    func tablesetup() {
        receivedTableView.delegate = self
        receivedTableView.dataSource = self
        receivedTableView.register(receivedTableViewCell.self, forCellReuseIdentifier: "receivedTableViewCell")
        receivedTableView.estimatedRowHeight = 60
        receivedTableView.tableFooterView = UIView()
        
    }
    
    
}
extension ReceivedViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return callDetails.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = receivedTableView.dequeueReusableCell(withIdentifier: "receivedTableViewCell", for: indexPath) as? receivedTableViewCell else {
            return UITableViewCell()
        }
        cell.contactNameLable.text = contactNames[indexPath.row]
        cell.contactNumberLable.text = contactNumbers[indexPath.row]
        cell.callDetailsLable.text = callDetails[indexPath.row]
        //        cell.layer.borderColor = UIColor.white.cgColor
        //        cell.layer.borderWidth = 3.0
        //        cell.layer.cornerRadius = 3.0
        //        cell.layer.backgroundColor = UIColor.orange.cgColor
        
        return cell
    }
    
    
}

