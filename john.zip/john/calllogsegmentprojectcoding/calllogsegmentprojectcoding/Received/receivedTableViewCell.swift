//
//  receivedTableViewCell.swift
//  calllogsegmentprojectcoding
//
//  Created by Apple on 24/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class receivedTableViewCell: UITableViewCell {

    lazy var contactNameLable: UILabel = {
        var nameLabel = UILabel ()
        nameLabel.backgroundColor = .white
        nameLabel.font = UIFont.systemFont(ofSize: 20)
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.textColor = .black
        nameLabel.textAlignment = .left
        return nameLabel
    }()
    
    lazy var contactNumberLable: UILabel = {
        var numberLable = UILabel()
        numberLable.backgroundColor = .white
        numberLable.font = UIFont.systemFont(ofSize: 15)
        numberLable.translatesAutoresizingMaskIntoConstraints = false
        numberLable.textColor = .black
        numberLable.textAlignment = .left
        return numberLable
    }()
    
    
    lazy var callDetailsLable: UILabel = {
        var detailsLable = UILabel()
        detailsLable.backgroundColor = .white
        detailsLable.font = UIFont.systemFont(ofSize: 12)
        detailsLable.translatesAutoresizingMaskIntoConstraints = false
        detailsLable.textColor = .black
        detailsLable.textAlignment = .left
        return detailsLable
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .default, reuseIdentifier: reuseIdentifier)
        self.setup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    func setup(){
        
        self.contentView.addSubview(contactNameLable)
        self.contentView.addSubview(contactNumberLable)
        self.contentView.addSubview(callDetailsLable)
        
        
        NSLayoutConstraint.activate([contactNameLable.topAnchor.constraint(equalTo: self.contentView.topAnchor, constant: 10), contactNameLable.leadingAnchor.constraint(equalTo: self.contentView.leadingAnchor, constant: 10), contactNameLable.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor, constant: -10)])
        
        
        NSLayoutConstraint.activate([contactNumberLable.topAnchor.constraint(equalTo: self.contactNameLable.bottomAnchor, constant: 10), contactNumberLable.leadingAnchor.constraint(equalTo: self.contentView.leadingAnchor, constant: 10), contactNumberLable.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor, constant: -10)])
        
        NSLayoutConstraint.activate([callDetailsLable.topAnchor.constraint(equalTo: self.contactNumberLable.bottomAnchor, constant: 10), callDetailsLable.leadingAnchor.constraint(equalTo: self.contentView.leadingAnchor, constant: 10), callDetailsLable.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor, constant: -10), callDetailsLable.bottomAnchor.constraint(equalTo: self.contentView.bottomAnchor, constant: -10)])
        
    }
    
    
    
}


