//
//  Addswift.swift
//  Customtableview
//
//  Created by Apple on 10/12/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation


import UIKit

class DataModel {
    
    var country: String?
    var city: String?
    
    init(country: String?, city: String?) {
        self.country = country
        self.city = city
        
    }
}
