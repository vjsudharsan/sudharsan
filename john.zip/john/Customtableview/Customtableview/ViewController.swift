//
//  ViewController.swift
//  Customtableview
//
//  Created by Apple on 30/11/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var profileViewList: UITableView!
    var lablenamelist = [" SURESH KUMAR", "KAVIN", "HARIKRISHNA"]
    var labelmaillist = ["johnpeter9955@gmail.com", "kavinbe005@gmail.com", "harikrishna@gmail.com"]
    var labelnumberlist = ["8870598487", "8596235478", "8936521478"]
    

    override func viewDidLoad() {
        super.viewDidLoad()
        profileViewList.tableFooterView = UIView()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

extension ViewController: UITableViewDataSource, UITableViewDelegate{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return lablenamelist.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let room = profileViewList.dequeueReusableCell(withIdentifier: "Celltableview", for: indexPath as IndexPath) as! Celltableview
     
        room.labelName.text = lablenamelist[indexPath.row]
        room.labelMailid.text = labelmaillist[indexPath.row]
        room.labelCellnumber.text = labelnumberlist[indexPath.row]
        room.accessoryType = .disclosureIndicator
        
       return room
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
   
}
