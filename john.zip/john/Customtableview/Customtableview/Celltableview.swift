//
//  Celltableview.swift
//  Customtableview
//
//  Created by Apple on 30/11/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class Celltableview: UITableViewCell {
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelMailid: UILabel!
    @IBOutlet weak var labelCellnumber: UILabel!
    @IBOutlet weak var tata: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
