//
//  RegisterViewController.swift
//  LoginScreen
//
//  Created by nschool on 12/11/20.
//

import UIKit

class RegisterViewController: UIViewController {

    lazy var labelCreateAccount: UILabel = {
       let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Create Account"
        label.textAlignment = .left
        label.textColor = .white
        label.lineBreakMode = .byWordWrapping
        label.numberOfLines = .zero
        //label.font = label.font.withSize(50)
        label.font = UIFont(name: "HelveticaNeue-UltraLight", size: 30)
        return label
    }()
    
    lazy var labelFileds: UILabel = {
       let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Please fill the input below here"
        label.textAlignment = .left
        label.textColor = .lightGray
        label.lineBreakMode = .byWordWrapping
        label.numberOfLines = .zero
        //label.font = label.font.withSize(50)
        //label.font = UIFont(name: "HelveticaNeue-UltraLight", size: 30)
        return label
    }()
    //arrangedSubviews: [textFieldFullName, textFieldPhone, textFieldEmail, textFieldPassword, textFieldConfirmPassword]
    lazy var stackViewTextField: UIStackView = {
       let stackView = UIStackView(arrangedSubviews: [textFieldFullName, textFieldPhone, textFieldEmail, textFieldPassword, textFieldConfirmPassword])
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.isLayoutMarginsRelativeArrangement = true
        stackView.alignment = .fill
        stackView.distribution = .fillEqually
        stackView.axis = .vertical
        stackView.spacing = 20
        stackView.layoutMargins = UIEdgeInsets(top: 15, left: 15, bottom: 15, right: 15)
        return stackView
    }()
    
    lazy var textFieldFullName: UITextField = {
       let textField = UITextField()
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.placeholder = "FULL NAME"
        textField.textAlignment = .left
        textField.backgroundColor = .lightGray
        textField.layer.cornerRadius = 10
        textField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 15, height: textField.frame.height))
        textField.leftViewMode = .always
        return textField
    }()
    lazy var textFieldPhone: UITextField = {
       let textField = UITextField()
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.placeholder = "PHONE"
        textField.textAlignment = .left
        textField.backgroundColor = .lightGray
        textField.layer.cornerRadius = 10
        textField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 15, height: textField.frame.height))
        textField.leftViewMode = .always
        return textField
    }()
    lazy var textFieldEmail: UITextField = {
       let textField = UITextField()
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.placeholder = "EMAIL"
        textField.textAlignment = .left
        textField.backgroundColor = .lightGray
        textField.layer.cornerRadius = 10
        textField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 15, height: textField.frame.height))
        textField.leftViewMode = .always
        return textField
    }()
    
    lazy var textFieldPassword: UITextField = {
       let textField = UITextField()
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.placeholder = "PASSWORD"
        textField.textAlignment = .left
        textField.backgroundColor = .lightGray
        textField.layer.cornerRadius = 10
        textField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 15, height: textField.frame.height))
        textField.leftViewMode = .always
        return textField
    }()
    
    lazy var textFieldConfirmPassword: UITextField = {
       let textField = UITextField()
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.placeholder = "CONFIRM PASSWORD"
        textField.textAlignment = .left
        textField.backgroundColor = .lightGray
        textField.layer.cornerRadius = 10
        textField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 15, height: textField.frame.height))
        textField.leftViewMode = .always
        return textField
    }()
    
    lazy var buttonSignUp: UIButton = {
       let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("SIGN UP", for: .normal)
        button.setTitleColor(.black, for: .normal)
        button.backgroundColor = .cyan
        button.layer.cornerRadius = 15
        return button
    }()
//
//    lazy var stackViewSignIn: UIStackView = {
//       let stackView = UIStackView(arrangedSubviews: [labelAccount,buttonSignIn])
//        stackView.translatesAutoresizingMaskIntoConstraints = false
//        stackView.isLayoutMarginsRelativeArrangement = true
//        stackView.alignment = .fill
//        stackView.distribution = .fillEqually
//        stackView.axis = .horizontal
//        stackView.spacing = 0
//        stackView.layoutMargins = UIEdgeInsets(top: 15, left: 15, bottom: 15, right: 15)
//        return stackView
//    }()
    
    lazy var labelAccount: UILabel = {
       let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Already have a account?"
        label.textAlignment = .left
        label.textColor = .lightGray
        label.lineBreakMode = .byWordWrapping
        label.numberOfLines = .zero
        //label.font = label.font.withSize(50)
        //label.font = UIFont(name: "HelveticaNeue-UltraLight", size: 30)
        return label
    }()
    
    lazy var buttonSignIn: UIButton = {
       let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Sign In", for: .normal)
        button.setTitleColor(.cyan, for: .normal)
        button.backgroundColor = .clear
        button.layer.cornerRadius = 15
        return button
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.view.backgroundColor = .black
        self.setUp()
    }
    
    func setUp() {
        self.view.addSubview(labelCreateAccount)
        self.view.addSubview(labelFileds)
        self.view.addSubview(stackViewTextField)
        self.view.addSubview(buttonSignUp)
        self.view.addSubview(labelAccount)
        self.view.addSubview(buttonSignIn)

        NSLayoutConstraint.activate([labelCreateAccount.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 20), labelCreateAccount.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: 20), labelCreateAccount.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 40), labelCreateAccount.heightAnchor.constraint(greaterThanOrEqualToConstant: 44)])
        
        NSLayoutConstraint.activate([labelFileds.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 20),labelFileds.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: 20), labelFileds.topAnchor.constraint(equalTo: self.labelCreateAccount.bottomAnchor, constant: 5)])
        
        NSLayoutConstraint.activate([stackViewTextField.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 20), stackViewTextField.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20), stackViewTextField.topAnchor.constraint(equalTo: self.labelFileds.bottomAnchor, constant: 30), stackViewTextField.heightAnchor.constraint(greaterThanOrEqualToConstant: 300)])
        
        NSLayoutConstraint.activate([buttonSignUp.topAnchor.constraint(equalTo: self.stackViewTextField.bottomAnchor, constant: 20), buttonSignUp.centerXAnchor.constraint(equalTo: self.view.centerXAnchor), buttonSignUp.heightAnchor.constraint(equalToConstant: 30), buttonSignUp.widthAnchor.constraint(equalToConstant: 130)])
        
//        NSLayoutConstraint.activate([stackViewSignIn.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 10), stackViewSignIn.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -10), stackViewSignIn.topAnchor.constraint(equalTo: self.buttonSignUp.bottomAnchor, constant: 30)])
        
        NSLayoutConstraint.activate([labelAccount.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 30), labelAccount.bottomAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.bottomAnchor, constant: -15),labelAccount.heightAnchor.constraint(greaterThanOrEqualToConstant: 44)])
        
        NSLayoutConstraint.activate([buttonSignIn.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20),buttonSignIn.bottomAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.bottomAnchor, constant: -15)])
   }

}
