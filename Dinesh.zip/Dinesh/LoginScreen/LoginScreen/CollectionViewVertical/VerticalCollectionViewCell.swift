//
//  VerticalCollectionViewCell.swift
//  LoginScreen
//
//  Created by nschool on 17/11/20.
//

import UIKit

class VerticalCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageVertical:UIImageView!
}
