//
//  CollectionViewController.swift
//  LoginScreen
//
//  Created by nschool on 17/11/20.
//

import UIKit

class CollectionViewController: UIViewController {

    @IBOutlet weak var HorizontalcollectionView: UICollectionView!
    @IBOutlet weak var verticalCollectionView: UICollectionView!
    
    var imageItems = ["audi","bmw","csk","rcb","dc","fblogo"]
    var imageItemsVertical = ["audi","bmw","csk","rcb","dc","fblogo","audi","bmw","csk","rcb","dc","fblogo","audi","bmw","csk","rcb","dc","fblogo","audi","bmw","csk","rcb","dc","fblogo"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
         setUp()
        // Do any additional setup after loading the view.
    }
    
    func setUp() {
        HorizontalcollectionView.setContentOffset(HorizontalcollectionView.contentOffset, animated: false)
        verticalCollectionView.setContentOffset(verticalCollectionView.contentOffset, animated: false)
        let cellSize = CGSize(width: 100, height: 100)
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.itemSize = cellSize
        layout.minimumLineSpacing = 5
        layout.sectionInset = UIEdgeInsets(top: 1, left: 1, bottom: 1, right: 1)
        HorizontalcollectionView.setCollectionViewLayout(layout, animated: true)
        verticalCollectionView.setCollectionViewLayout(layout, animated: true)
    }
}

extension CollectionViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if collectionView == self.HorizontalcollectionView {
            return imageItems.count
        } else {
            return imageItemsVertical.count
        }
        
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == self.HorizontalcollectionView {
            let cell = HorizontalcollectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath as IndexPath) as! CollectionViewCell
            cell.imageName.image = UIImage(named: imageItems[indexPath.row])
            return cell
        } else {
            let cell = verticalCollectionView.dequeueReusableCell(withReuseIdentifier: "VerticalCollectionViewCell", for: indexPath as IndexPath) as! CollectionViewCell
            cell.imageName.image = UIImage(named: imageItemsVertical[indexPath.row])
            return cell
            
        }
    }
}
