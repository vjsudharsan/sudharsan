//
//  CollectionViewCell.swift
//  LoginScreen
//
//  Created by nschool on 17/11/20.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageName: UIImageView!
    
}
