//
//  LoginViewController.swift
//  LoginScreen
//
//  Created by nschool on 12/11/20.
//

import UIKit

class LoginViewController: UIViewController {
    lazy var logoImage: UIImageView = {
       let image = UIImageView()
        image.image = UIImage(named: "logo")
        image.translatesAutoresizingMaskIntoConstraints = false
        return image
    }()
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "LOGIN"
        label.numberOfLines = .zero
        label.lineBreakMode = .byWordWrapping
        label.textAlignment = .left
        label.textColor = .white
        label.backgroundColor = .black
        return label
    }()
    lazy var titleSubLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Please sign in to continue"
        label.numberOfLines = .zero
        label.lineBreakMode = .byWordWrapping
        label.textAlignment = .left
        label.textColor = .gray
        label.backgroundColor = .black
        return label
    }()
    lazy var textFieldStackView: UIStackView = {
       let stackview = UIStackView(arrangedSubviews: [mailTextFeild, passwordTextFeild])
        stackview.translatesAutoresizingMaskIntoConstraints = false
        stackview.alignment = .fill
        stackview.distribution = .fillEqually
        stackview.spacing = 15
        stackview.axis = .vertical
        stackview.isLayoutMarginsRelativeArrangement = true
        stackview.layoutMargins = UIEdgeInsets(top: 15, left: 15, bottom: 15, right: 15)
        return stackview
    }()
    lazy var mailTextFeild: UITextField = {
        let textField = UITextField()
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.keyboardType = .emailAddress
        textField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 15, height: textField.frame.height))
        textField.leftViewMode = .always
        textField.textColor = .white
        textField.backgroundColor = .lightGray
        textField.textAlignment = .left
        textField.placeholder = "Email"
        textField.layer.cornerRadius = 15
        return textField
    }()
    lazy var passwordTextFeild: UITextField = {
        let textField = UITextField()
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.isSecureTextEntry = true
        textField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 15, height: textField.frame.height))
        textField.leftViewMode = .always
        textField.textColor = .white
        textField.backgroundColor = .lightGray
        textField.textAlignment = .left
        textField.placeholder = "Password"
        textField.layer.cornerRadius = 15
        return textField
    }()
    lazy var loginButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("LOGIN", for: .normal)
        button.setTitleColor(.black, for: .normal)
        button.backgroundColor = .cyan
        button.layer.cornerRadius = 20
        return button
    }()
    lazy var forgotPasswordButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Forgot Password?", for: .normal)
        button.setTitleColor(.cyan, for: .normal)
        button.backgroundColor = .clear
        button.layer.cornerRadius = 20
        return button
    }()
    lazy var sigupLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Don't have an account?"
        label.numberOfLines = .zero
        label.lineBreakMode = .byWordWrapping
        label.textAlignment = .left
        label.textColor = .gray
        label.backgroundColor = .black
        return label
    }()
    lazy var signupButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("SIGNUP", for: .normal)
        button.setTitleColor(.cyan, for: .normal)
        button.backgroundColor = .clear
        return button
    }()

    

    override func viewDidLoad() {
        super.viewDidLoad()
        loginButton.addTarget(self, action: #selector(loginButtonAction(_sender:)), for: .touchUpInside)
        forgotPasswordButton.addTarget(self, action: #selector(forgotPasswordButtonAction(_sender:)), for: .touchUpInside)
        signupButton.addTarget(self, action: #selector(signupButtonAction(_sender:)), for: .touchUpInside)
        view.backgroundColor = .black
        self.setUp()

        // Do any additional setup after loading the view.
    }
    @objc func loginButtonAction(_sender: UIButton) {
        self.animation(sender: loginButton)
    }
    @objc func forgotPasswordButtonAction(_sender: UIButton) {
        print("ok")
    }
    @objc func signupButtonAction(_sender: UIButton) {
        print("done")
       
       let controller = RegisterViewController()
        self.navigationController?.pushViewController(controller, animated: true)
      
    }
    
    func setUp() {
        self.view.addSubview(logoImage)
        self.view.addSubview(titleLabel)
        self.view.addSubview(titleSubLabel)
        self.view.addSubview(textFieldStackView)
        self.view.addSubview(loginButton)
        self.view.addSubview(forgotPasswordButton)
        self.view.addSubview(sigupLabel)
        self.view.addSubview(signupButton)
        
        NSLayoutConstraint.activate([logoImage.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 50), logoImage.centerXAnchor.constraint(equalTo: self.view.centerXAnchor), logoImage.heightAnchor.constraint(equalToConstant: 150), logoImage.widthAnchor.constraint(equalToConstant: 150)])
        
        NSLayoutConstraint.activate([titleLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15), titleLabel.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15), titleLabel.topAnchor.constraint(equalTo: logoImage.bottomAnchor, constant: 15), titleLabel.heightAnchor.constraint(greaterThanOrEqualToConstant: 45)])
        
        NSLayoutConstraint.activate([titleSubLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15), titleSubLabel.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15), titleSubLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 1), titleSubLabel.heightAnchor.constraint(greaterThanOrEqualToConstant: 45)])
        
        NSLayoutConstraint.activate([textFieldStackView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15), textFieldStackView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15), textFieldStackView.topAnchor.constraint(equalTo: titleSubLabel.bottomAnchor, constant: 15), textFieldStackView.heightAnchor.constraint(greaterThanOrEqualToConstant: 140)])
        
        NSLayoutConstraint.activate([loginButton.topAnchor.constraint(equalTo: textFieldStackView.bottomAnchor, constant: 15), loginButton.centerXAnchor.constraint(equalTo: self.view.centerXAnchor), loginButton.heightAnchor.constraint(equalToConstant: 40), loginButton.widthAnchor.constraint(equalToConstant: 160)])
        NSLayoutConstraint.activate([forgotPasswordButton.topAnchor.constraint(equalTo: loginButton.bottomAnchor, constant: 2), forgotPasswordButton.centerXAnchor.constraint(equalTo: self.view.centerXAnchor), forgotPasswordButton.heightAnchor.constraint(equalToConstant: 40), forgotPasswordButton.widthAnchor.constraint(equalToConstant: 160)])
        
        NSLayoutConstraint.activate([sigupLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 70), sigupLabel.bottomAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.bottomAnchor, constant: -15), sigupLabel.heightAnchor.constraint(greaterThanOrEqualToConstant: 45)])
        
        NSLayoutConstraint.activate([signupButton.leadingAnchor.constraint(equalTo: sigupLabel.trailingAnchor, constant: 1),  signupButton.bottomAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.bottomAnchor, constant: -15), signupButton.heightAnchor.constraint(equalToConstant: 40), signupButton.widthAnchor.constraint(equalToConstant: 80)])
    }
    
    func animation(sender: UIButton) {
            sender.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
            UIView.animate(withDuration: 2.0,
                           delay: 0,
                           usingSpringWithDamping: CGFloat(0.20),
                           initialSpringVelocity: CGFloat(6.0),
                           options: UIView.AnimationOptions.allowUserInteraction,
                           animations: {
                            sender.transform = CGAffineTransform.identity
                           },
                           completion: { Void in()  }
            )
        }
}
