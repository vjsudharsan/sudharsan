//
//  BaseViewController.swift
//  LoginProject
//
//  Created by nschool on 24/10/20.
//

import UIKit

class BaseViewController: UIViewController {
    var activityIndicator = UIActivityIndicatorView()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    func showAlertsWithTitle(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alert, animated: true)
    }
    func showAlertsWithAction(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { action in
              switch action.style{
              case .default:
                    print("default")
              case .cancel:
                    print("cancel")
              case .destructive:
                    print("destructive")
              default:
                break
              }}))
        alert.addAction(UIAlertAction(title: "No", style: .destructive, handler: { action in
              switch action.style{
              case .default:
                    print("default")
              case .cancel:
                    print("cancel")
              case .destructive:
                    print("destructive")
              default:
                break
              }}))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { action in
              switch action.style{
              case .default:
                    print("default")
              case .cancel:
                    print("cancel")
              case .destructive:
                    print("destructive")
              default:
                break
              }}))
        self.present(alert, animated: true, completion: nil)
    }
    func activityIndicatorBegin() {
        activityIndicator.center = self.view.center
        activityIndicator.hidesWhenStopped = true
        activityIndicator.style = .medium
        activityIndicator.translatesAutoresizingMaskIntoConstraints = true
        view.addSubview(activityIndicator)
        // Auto layout
        let horizontalConstraint = NSLayoutConstraint(item: activityIndicator,
                                                      attribute: .centerX,
                                                      relatedBy: .equal,
                                                      toItem: self.view,
                                                      attribute: .centerX,
                                                      multiplier: 1,
                                                      constant: 0)
        let verticalConstraint = NSLayoutConstraint(item: activityIndicator,
                                                    attribute: .centerY,
                                                    relatedBy: .equal,
                                                    toItem: self.view,
                                                    attribute: .centerY,
                                                    multiplier: 1,
                                                    constant: 0)
        NSLayoutConstraint.activate([horizontalConstraint, verticalConstraint])
        activityIndicator.startAnimating()
        
        
    }

    func activityIndicatorEnd() {
        self.activityIndicator.stopAnimating()
        self.activityIndicator.isHidden = true
    }
}
