//
//  UserListViewController.swift
//  LoginProject
//
//  Created by nschool on 23/10/20.
//

import UIKit

class UserListViewController: UIViewController {

    var userListViewModel = UserListViewModel()
    
    @IBOutlet weak var userListTableView: UITableView!
    @IBOutlet weak var activityIndicatorView: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = userListViewModel.pageTitle
        self.navigationItem.setHidesBackButton(true, animated: true)
        userListTableView.tableFooterView = UIView()
        self.activityIndicatorView.isHidden = true
        self.initViewModel()
    }
    
    func initViewModel() {
        userListViewModel.updateLoadingStatus = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                if self.userListViewModel.isLoading {
                    // Start Animating
                    self.activityIndicatorView.isHidden = false
                    self.activityIndicatorView.startAnimating()
                } else {
                    // Stop Animating
                    self.activityIndicatorView.isHidden = true
                    self.activityIndicatorView.stopAnimating()
                }
            }
        }
        userListViewModel.showAlertClosure = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                if let errorMessage = self.userListViewModel.alertMessage {
                    print(errorMessage.localizedDescription)
                }
            }
        }
        userListViewModel.reloadClosure = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                // TableView ReloadData
                self.userListTableView.reloadData()
            }
        }
        self.userListViewModel.getUserList()
    }
}

extension UserListViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return userListViewModel.numberOfSections
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userListViewModel.numberOfRowsInSection
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.userListTableView.dequeueReusableCell(withIdentifier: Constants.TableViewIdentifier.kUserListTableViewCell) as! UserListTableViewCell
        if let dataObject = userListViewModel.getcellForRowAt(indexpath: indexPath), let firstName = dataObject.first_name, let lastName = dataObject.last_name, let userImage = dataObject.avatar, let email = dataObject.email {
            cell.nameLabel.text = firstName+Constants.Common.kEmtySpace+lastName
            cell.emailLabel.text = email
            cell.activityIndicatorView.isHidden = false
            cell.activityIndicatorView.startAnimating()
            CommonFunction().NschoolPlaceholderImage(image: UIImage(named: "userThumnail"), imageView: cell.avatarImageView, imgUrl: userImage) {(image) in
                cell.avatarImageView.image = image
                cell.activityIndicatorView.stopAnimating()
                cell.activityIndicatorView.isHidden = true
            }
        }
        cell.accessoryType = .disclosureIndicator
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let userDetails = self.userListViewModel.getSelectObject(indexpath: indexPath)
        if let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "UserDetailsViewController") as? UserDetailsViewController {
            vc.userDetailsViewModel.dataList = userDetails
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}


