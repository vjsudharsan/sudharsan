//
//  LoginModel.swift
//  ProjectTest
//
//  Created by nschool on 23/10/20.
//

//import Foundation

import Foundation
struct LoginModel: Decodable {
    var token: String?
}
