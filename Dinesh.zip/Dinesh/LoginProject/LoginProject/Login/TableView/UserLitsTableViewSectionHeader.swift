//
//  UserLitsTableViewSectionHeader.swift
//  LoginProject
//
//  Created by nschool on 31/10/20.
//

import UIKit

class UserLitsTableViewSectionHeader: UITableViewHeaderFooterView {

    lazy var labelHeadeTitleName: UILabel = {
        let label = UILabel()
        label.textAlignment = .left
        label.textColor = .gray
        label.numberOfLines = .zero
        label.lineBreakMode = .byWordWrapping
        label.backgroundColor = .clear
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    override init(reuseIdentifier: String?) {
        super.init(reuseIdentifier: reuseIdentifier)
        self.setupView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupView() {
        self.contentView.addSubview(labelHeadeTitleName)
        NSLayoutConstraint.activate([labelHeadeTitleName.leadingAnchor.constraint(equalTo: self.contentView.leadingAnchor, constant: 15), labelHeadeTitleName.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor, constant: -15), labelHeadeTitleName.topAnchor.constraint(equalTo: self.contentView.topAnchor, constant: 15), labelHeadeTitleName.bottomAnchor.constraint(equalTo: self.contentView.bottomAnchor, constant: -15)])
    }
    
}
