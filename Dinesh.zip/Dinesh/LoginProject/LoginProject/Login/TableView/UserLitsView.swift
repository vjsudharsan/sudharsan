//
//  UserLitsView.swift
//  LoginProject
//
//  Created by nschool on 31/10/20.
//

import UIKit

class UserLitsView: UIViewController {

    let tableViewCellIdentifier = "UserLitsTableViewCell"
    let tableViewSectionHeaderIdentifier = "UserLitsTableViewSectionHeader"
    
    lazy var userListTableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .plain)
        tableView.isScrollEnabled = true
        tableView.backgroundColor = .clear
        tableView.translatesAutoresizingMaskIntoConstraints = false
        return tableView
    }()
    
    let playerItems = ["Player0", "Player1", "Player2", "Player3"]
    let sectionHeaderItems = ["BatsMan", "All Rounder", "Wicket Keeper", "Bowler"]
    
    override func loadView() {
        super.loadView()
        self.setupView()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = .systemBackground
        self.title = "Player List"
        self.setupTableView()
    }
    func setupTableView() {
        userListTableView.estimatedRowHeight = 44
        userListTableView.delegate = self
        userListTableView.dataSource = self
        userListTableView.register(UserLitsTableViewCell.self, forCellReuseIdentifier: tableViewCellIdentifier)
        userListTableView.separatorStyle = .singleLine
        userListTableView.tableFooterView = UIView()
        userListTableView.register(UserLitsTableViewSectionHeader.self, forHeaderFooterViewReuseIdentifier: tableViewSectionHeaderIdentifier)
    }
    func setupView() {
        self.view.addSubview(userListTableView)
        NSLayoutConstraint.activate([userListTableView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor), userListTableView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor), userListTableView.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor), userListTableView.bottomAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.bottomAnchor)])
    }
}

extension UserLitsView: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return sectionHeaderItems.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return playerItems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = userListTableView.dequeueReusableCell(withIdentifier: tableViewCellIdentifier, for: indexPath) as? UserLitsTableViewCell else {
            return UITableViewCell()
        }
        //player0
        cell.labelPlayerName.text = playerItems[indexPath.row]
        cell.profileImage.image = UIImage(named: playerItems[indexPath.row].lowercased())
        cell.accessoryType = .disclosureIndicator
        return cell
    }
    // Default section with title string
//    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
//        return "BATSMAN"
//    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        guard let headerView = userListTableView.dequeueReusableHeaderFooterView(withIdentifier: tableViewSectionHeaderIdentifier) as? UserLitsTableViewSectionHeader else {
            return UIView()
        }
        headerView.labelHeadeTitleName.text = sectionHeaderItems[section].uppercased()
        return headerView
    }
}

extension UserLitsView: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return UITableView.automaticDimension
    }
}
