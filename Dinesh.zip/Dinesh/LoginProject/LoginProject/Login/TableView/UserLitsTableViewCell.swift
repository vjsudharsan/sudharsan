//
//  UserLitsTableViewCell.swift
//  LoginProject
//
//  Created by nschool on 31/10/20.
//

import UIKit

class UserLitsTableViewCell: UITableViewCell {

    lazy var profileImage: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
    
    lazy var labelPlayerName: UILabel = {
        let label = UILabel()
        label.textAlignment = .left
        label.textColor = .gray
        label.numberOfLines = .zero
        label.lineBreakMode = .byWordWrapping
        label.backgroundColor = .clear
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
   
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .default, reuseIdentifier: reuseIdentifier)
        self.setupView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupView() {
        self.contentView.addSubview(profileImage)
        self.contentView.addSubview(labelPlayerName)
        
        NSLayoutConstraint.activate([profileImage.leadingAnchor.constraint(equalTo: self.contentView.leadingAnchor, constant: 15), profileImage.topAnchor.constraint(equalTo: self.contentView.topAnchor, constant: 15), profileImage.widthAnchor.constraint(equalToConstant: 60), profileImage.heightAnchor.constraint(equalToConstant: 60), profileImage.centerYAnchor.constraint(equalTo: self.contentView.centerYAnchor)])
        
        NSLayoutConstraint.activate([labelPlayerName.leadingAnchor.constraint(equalTo: profileImage.trailingAnchor, constant: 15), labelPlayerName.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor, constant: -15), labelPlayerName.topAnchor.constraint(equalTo: self.contentView.topAnchor, constant: 15), labelPlayerName.bottomAnchor.constraint(equalTo: self.contentView.bottomAnchor, constant: -15)])
    }
}
