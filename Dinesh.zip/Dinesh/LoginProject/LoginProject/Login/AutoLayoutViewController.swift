//
//  AutoLayoutViewController.swift
//  LoginProject
//
//  Created by nschool on 24/10/20.
//

import UIKit

class AutoLayoutViewController: UIViewController {


    lazy var labelTitle: UILabel = {
        let label = UILabel()
        label.text = "Make a symbolic breakpoint at UIViewAlertForUnsatisfiableConstraints to catch this in the debugger.The methods in the UIConstraintBasedLayoutDebugging category on UIView listed in view may also be helpful."
        label.numberOfLines = .zero
        label.textAlignment = .left
        label.textColor = .black
        label.backgroundColor = .lightGray
        label.lineBreakMode = .byWordWrapping
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.systemFont(ofSize: 18)
        return label
    }()
    
    lazy var labelSubTitle: UILabel = {
        let label = UILabel()
        label.text = "Sub title"
        label.numberOfLines = .zero
        label.textAlignment = .left
        label.textColor = .black
        label.backgroundColor = .gray
        label.lineBreakMode = .byWordWrapping
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.systemFont(ofSize: 15)
        return label
    }()
    
    lazy var buttonSubmit: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("Submit", for: .normal)
        button.backgroundColor = .clear
        button.setTitleColor(.black, for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.layer.cornerRadius = 10.0
        button.layer.borderWidth = 1.0
        button.layer.borderColor = UIColor.blue.cgColor
        return button
    }()
    
    lazy var titleTextField:UITextField = {
        let textField = UITextField()
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.placeholder = "Title *"
        textField.keyboardType = UIKeyboardType.default
        textField.returnKeyType = UIReturnKeyType.done
        textField.autocorrectionType = UITextAutocorrectionType.no
        textField.font = UIFont.systemFont(ofSize: 13)
        textField.borderStyle = UITextField.BorderStyle.roundedRect
        textField.clearButtonMode = UITextField.ViewMode.whileEditing;
        textField.contentVerticalAlignment = UIControl.ContentVerticalAlignment.center
        textField.backgroundColor = .gray
        return textField
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .white
        // Do any additional setup after loading the view.
        self.setUpView()
    }
    func setUpView() {
        self.view.addSubview(labelTitle)
        self.view.addSubview(labelSubTitle)
        self.view.addSubview(titleTextField)
        self.view.addSubview(buttonSubmit)
        
        let leadingConstraint = labelTitle.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15)
        let topConstraint = labelTitle.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 15)
        let trailingConstraint = labelTitle.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15)
        let heightConstraint = labelTitle.heightAnchor.constraint(greaterThanOrEqualToConstant: 40)
        NSLayoutConstraint.activate([leadingConstraint, topConstraint, trailingConstraint, heightConstraint])
        
        let subTitleLeadingConstraint = labelSubTitle.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15)
        let subTitleTrailingConstraint = labelSubTitle.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15)
        let subTitleTopConstraint = labelSubTitle.topAnchor.constraint(equalTo: labelTitle.bottomAnchor, constant: 15)
        let subTitleHeightConstraint = labelSubTitle.heightAnchor.constraint(greaterThanOrEqualToConstant: 40)
        NSLayoutConstraint.activate([subTitleLeadingConstraint, subTitleTrailingConstraint, subTitleTopConstraint, subTitleHeightConstraint])
        
        let textFieldLeadingConstraint = titleTextField.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15)
        let textFieldTrailingConstraint = titleTextField.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15)
        let textFieldTopConstraint = titleTextField.topAnchor.constraint(equalTo: labelSubTitle.bottomAnchor, constant: 15)
        let textFieldHeightConstraint = titleTextField.heightAnchor.constraint(greaterThanOrEqualToConstant: 40)
        NSLayoutConstraint.activate([textFieldLeadingConstraint, textFieldTrailingConstraint, textFieldTopConstraint, textFieldHeightConstraint])
        
        let buttonLeadingConstraint = buttonSubmit.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15)
        let buttonTrailingConstraint = buttonSubmit.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15)
        let buttonTopConstraint = buttonSubmit.topAnchor.constraint(equalTo: titleTextField.bottomAnchor, constant: 15)
        let buttonHeightConstraint = buttonSubmit.heightAnchor.constraint(greaterThanOrEqualToConstant: 44)
        NSLayoutConstraint.activate([buttonLeadingConstraint, buttonTrailingConstraint, buttonTopConstraint, buttonHeightConstraint])
      
    }
    
}
