//
//  UserListViewModel.swift
//  ProjectTask
//
//  Created by nschool on 23/10/20.
//

import Foundation
class UserDetailsViewModel {
    
    var dataList: DataList?
    
    var id: Int {
        return dataList?.id ?? 0
    }
    var firstName: String {
        return dataList?.first_name ?? Constants.Common.kEmptyString
    }
    var lastName: String {
        return dataList?.last_name ?? Constants.Common.kEmptyString
    }
    var emailId: String {
        return dataList?.email ?? Constants.Common.kEmptyString
    }
}
