//
//  UserDetailsViewController.swift
//  LoginProject
//
//  Created by nschool on 23/10/20.
//

import UIKit

class UserDetailsViewController: UIViewController {
    
    var userDetailsViewModel = UserDetailsViewModel()
    
    @IBOutlet weak var labelId: UILabel!
    @IBOutlet weak var labelEmail: UILabel!
    @IBOutlet weak var labelFirstName: UILabel!
    @IBOutlet weak var labelLastName: UILabel!
    @IBOutlet weak var imageAvatar: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        labelId.text = String(userDetailsViewModel.id)
        labelFirstName.text = userDetailsViewModel.firstName
        labelLastName.text = userDetailsViewModel.lastName
        labelEmail.text = userDetailsViewModel.emailId
    }
    
    @IBAction func logoutButtonAction(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
}
