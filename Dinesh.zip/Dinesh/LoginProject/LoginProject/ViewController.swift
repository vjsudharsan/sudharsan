//
//  ViewController.swift
//  LoginProject
//
//  Created by nschool on 23/10/20.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

