//
//  Constants.swift
//  RHeal
//
//  Created by Periyasamy R on 29/03/20.
//  Copyright © 2020 Periyasamy. All rights reserved.
//

import Foundation

struct Constants {
    struct API {
        static let getuserList = "https://reqres.in/api/users?page=1"
        
        static let login = "login"
        static let register = "register"
        static let baseURL = "https://reqres.in/api/"
        //https://reqres.in/
    }
    struct Common {
        static let REQUEST_TIMEOUT = 60.0
        static let KEY_GET = "GET"
        static let KEY_POST = "POST"
        static let KEY_PUT = "PUT"
        static let KEY_DELETE = "DELETE"
        static let kEmptyString = ""
        static let CONTENTTYPE_URL_ENCODE = "application/x-www-form-urlencoded"
        static let CONTENTTYPE_JSON = "application/json"
        static let kLoginTitle = "Login"
        static let kRegisterTitle = "Register"
        static let kUserListTitle = "User List"
        static let kUserDetailTitle = "User Details"
        static let kEmtySpace = " "
    }
    
    struct TableViewIdentifier {
        static let kUserListTableViewCell = "UserListTableViewCell"
    }
}
