//
//  RegisterModel.swift
//  ProjectTask
//
//  Created by nschool on 21/10/20.
//

import Foundation
struct RegisterModel: Decodable {
    var token: String?
    var id: Int?
}
