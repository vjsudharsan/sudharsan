//
//  RegisterViewController.swift
//  LoginProject
//
//  Created by nschool on 23/10/20.
//

import UIKit

class RegisterViewController: BaseViewController {

    var registerViewModel = RegisterViewModel()
    
    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var phoneNumberTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = registerViewModel.pageTitle
        initViewModel()
        // Do any additional setup after loading the view.
    }
    
    func initViewModel() {
        
        registerViewModel.updateLoadingStatus = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                if self.registerViewModel.isLoading {
                    // Start Animating
                } else {
                    // Stop Animating
                }
            }
        }
        registerViewModel.showAlertClosure = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                if let errorMessage = self.registerViewModel.alertMessage {
                    print(errorMessage.localizedDescription)
                }
            }
        }
        registerViewModel.reloadClosure = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                if let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "UserListViewController") as? UserListViewController {
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            }
        }
    }

    @IBAction func submitRegisterButtonAction(_ sender: UIButton) {
        
        if let userName = userNameTextField.text , let email = emailTextField.text ,let password = passwordTextField.text, let phoneNumber = phoneNumberTextField.text {
            
            if userName == "" && email == "" && password == "" && phoneNumber == "" {
                print("All Fields Are Mandatory!!!")
            } else if userName == "" {
                print("Please Enter User Name!!!")
            } else if email == "" {
                print("Please Enter Email!!!")
            } else if password == "" {
                print("Please Enter Password!!!")
            } else if phoneNumber == "" {
                print("Please Enter Phone Number!!!")
            } else if !CommonFunction().validateFirstName(name: userName) {
                print("Please Enter Valid User Name!!!")
            } else if !CommonFunction().validateEmailId(emailID: email) {
                print("Please Enter Valid Email!!!")
            } else if !CommonFunction().validatePassword(password: password) {
                print("Please Enter Valid Password!!!")
            } else if !CommonFunction().validatePhoneNumber(phoneNumber: phoneNumber) {
                print("Please Enter Valid Phone Number!!!")
            } else {
                self.registerViewModel.registerPostAPICall(email: email, password: password)
            }
        }
        
    }
}

    extension RegisterViewController: UITextFieldDelegate {
        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            if textField == userNameTextField {
                emailTextField.becomeFirstResponder()
            } else if textField == emailTextField {
                passwordTextField.becomeFirstResponder()
            } else if textField == passwordTextField {
                phoneNumberTextField.becomeFirstResponder()
            } else if textField == phoneNumberTextField {
                phoneNumberTextField.resignFirstResponder()
            }
            return true
        }
    }

