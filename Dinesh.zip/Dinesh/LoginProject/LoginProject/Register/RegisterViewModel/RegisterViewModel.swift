//
//  RegisterViewModel.swift
//  ProjectTask
//
//  Created by nschool on 21/10/20.
//

import Foundation
class RegisterViewModel {
    
    
    let apiService: APIServiceCallProtocol
    var showAlertClosure: (() -> ())?
    var updateLoadingStatus: (() -> ())?
    var reloadClosure: (() -> ())?
    

    
    var registerModel: RegisterModel? {
        didSet {
            self.reloadClosure?()
        }
        
    }
    var alertMessage: ServiceError? {
        didSet {
            self.showAlertClosure?()
        }
    }
    var isLoading: Bool = false {
        didSet {
            self.updateLoadingStatus?()
        }
    }
        
    init(apiService: APIServiceCallProtocol = Network()) {
        self.apiService = apiService
    }
    
    var pageTitle: String {
        return Constants.Common.kRegisterTitle
    }
   
  
    func registerPostAPICall(email: String, password: String) {
        self.isLoading = true
        apiService.registerPostMethodAPICall(email: email, password: password) { [weak self] (success, response, error) in
            guard let self = self else { return }
            self.isLoading = false
            if success == ResponseCode.success {
                guard let response = response else {
                    self.alertMessage = error
                    return
                }
                self.registerModel = response as? RegisterModel
                
            } else {
                self.alertMessage = error
            }
        }
    }
}
