//
//  CreateViewController.swift
//  CoreDataBasics
//
//  Created by nschool on 09/12/20.
//

import UIKit
import CoreData

class CreateViewController: UIViewController {
   // let appdelegate = UIApplication.shared.delegate as? AppDelegate

    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    func createData() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        let userEntity = NSEntityDescription.entity(forEntityName: "User", in: managedContext)!
        
        let user = NSManagedObject(entity: userEntity, insertInto: managedContext)
        user.setValue(userNameTextField.text, forKeyPath: "userName")
        user.setValue(emailTextField.text, forKey: "email")
        
        do {
            try managedContext.save()
            
            print(userNameTextField.text as Any)
            print(emailTextField.text as Any)
            
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }
    
    @IBAction func createButtonAction(_ sender: Any) {
        createData()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
