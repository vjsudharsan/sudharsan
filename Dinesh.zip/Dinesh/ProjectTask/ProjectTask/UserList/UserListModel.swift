//
//  UserListModel.swift
//  ProjectTask
//
//  Created by nschool on 04/12/20.
//

import Foundation
