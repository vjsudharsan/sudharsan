//
//  ProductViewModel.swift
//  ProjectTask
//
//  Created by nschool on 04/12/20.
//

import Foundation
class ProductViewModel {
    var reloadClosure: (() -> ())?
    
    var productModel: ProductListModel? {
        didSet{
            self.reloadClosure?()
        }
    }
    func getMethodCall() {
        var request = URLRequest(url: URL(string: "http://demo.smartstorez.com/TESTAPI/GetProductsList")!)
        request.httpMethod = "GET"

        URLSession.shared.dataTask(with: request, completionHandler: { data, response, error -> Void in
            do {
                let jsonDecoder = JSONDecoder()
                let responseModel = try jsonDecoder.decode(ProductListModel.self, from: data!)
                print(responseModel)
                self.productModel = responseModel
            } catch {
                print("JSON Serialization error")
            }
        }).resume()
    }
    
    var noOfSection: Int {
        return 1
    }
    var noOfRows: Int {
        return productModel?.data?.count ?? 0
    }
    
    func cellForRowAt(indexpath: IndexPath) -> ProductList? {
        if let getObject = productModel?.data?[indexpath.row] {
            return getObject
        }
        return nil
    }
}
