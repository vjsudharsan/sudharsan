//
//  ProductViewController.swift
//  ProjectTask
//
//  Created by nschool on 04/12/20.
//

import UIKit

class ProductViewController: UIViewController {
    var tableViewCellIdentifier = "ProductListTableViewCell"
    
    var productViewModel = ProductViewModel()

    @IBOutlet weak var productTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initViewModel()
    }
    
    
    func initViewModel() {
        productViewModel.reloadClosure = { [weak self] in
            guard let self = self else {return}
            DispatchQueue.main.async {
                self.productTableView.reloadData()
            }
        }
        self.productViewModel.getMethodCall()
    }
    
    func PlaceholderImage(image:UIImage?, imageView:UIImageView?,imgUrl:String,compate:@escaping (UIImage?) -> Void){
        
        if image != nil && imageView != nil {
            imageView!.image = image!
        }
        
        var urlcatch = imgUrl.replacingOccurrences(of: "/", with: "#")
        let documentpath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        urlcatch = documentpath + "/" + "\(urlcatch)"
        
        let image = UIImage(contentsOfFile:urlcatch)
        if image != nil && imageView != nil
        {
            imageView!.image = image!
            compate(image)
            
        }else{
            
            if let url = URL(string: imgUrl){
                
                DispatchQueue.global(qos: .background).async {
                    () -> Void in
                    let imgdata = NSData(contentsOf: url)
                    DispatchQueue.main.async {
                        () -> Void in
                        imgdata?.write(toFile: urlcatch, atomically: true)
                        let image = UIImage(contentsOfFile:urlcatch)
                        compate(image)
                        if image != nil  {
                            if imageView != nil  {
                                imageView!.image = image!
                            }
                        }
                    }
                }
            }
        }
    }
//    func PlaceholderImage(image:UIImage?, imageView:UIImageView?,imgUrl:String,compate:@escaping (UIImage?) -> Void){
//        if image != nil && imageView != nil {
//            imageView!.image = image!
//        }
//        var urlcatch = imgUrl.replacingOccurrences(of: "/", with: "#")
//        let documentpath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
//        urlcatch = documentpath + "/" + "\(urlcatch)"
//        let image = UIImage(contentsOfFile:urlcatch)
//        if image != nil && imageView != nil
//        {
//            imageView!.image = image!
//            compate(image)
//        }else{
//            if let url = URL(string: imgUrl){
//                DispatchQueue.global(qos: .background).async {
//                    () -> Void in
//                    let imgdata = NSData(contentsOf: url)
//                    DispatchQueue.main.async {
//                        () -> Void in
//                        imgdata?.write(toFile: urlcatch, atomically: true)
//                        let image = UIImage(contentsOfFile:urlcatch)
//                        compate(image)
//                        if image != nil  {
//                            if imageView != nil  {
//                                imageView!.image = image!
//                            }
//                        }
//                    }
//                }
//            }
//        }
//    }
}

extension ProductViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return productViewModel.noOfSection
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productViewModel.noOfRows
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = productTableView.dequeueReusableCell(withIdentifier: tableViewCellIdentifier) as! ProductListTableViewCell
        if let object = productViewModel.cellForRowAt(indexpath: indexPath), let productImage = object.image_url {
            PlaceholderImage(image: UIImage(named: "apple"), imageView: cell.productImage, imgUrl: productImage) { (image) in
                cell.productImage.image = image
            cell.productIdLabel.text = object.Product_Id
            cell.productTitleLabel.text = object.product_title
            cell.catagoryLabel.text = object.category
            cell.salesPriceLabel.text = object.sales_price
            cell.discountPriceLabel.text = object.discount_price
        }
            cell.accessoryType = .disclosureIndicator
            cell.selectionStyle = .none
    }
    return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("success")
        let productdetails = self.productViewModel.cellForRowAt(indexpath: indexPath)
        if let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "UpdateProductViewController") as? UpdateProductViewController {
            vc.updateProductViewModel.product = productdetails
        self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}
