//
//  ProductListModel.swift
//  ProjectTask
//
//  Created by nschool on 04/12/20.
//

import Foundation
struct ProductListModel: Decodable {
    var message: String?
    var status: Int?
    var data: [ProductList]?
}
struct ProductList: Decodable {
    var Product_Id: String?
    var product_title: String?
    var category: String?
    var image_url: String?
    var sales_price: String?
    var discount_price: String?
}
