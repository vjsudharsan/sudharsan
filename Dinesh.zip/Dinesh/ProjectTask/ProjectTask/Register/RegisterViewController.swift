//
//  RegisterViewController.swift
//  ProjectTask
//
//  Created by nschool on 04/12/20.
//

import UIKit

class RegisterViewController: UIViewController {
    
    var registerViewModel = RegisterViewModel()
    
    @IBOutlet weak var textFieldFirstName: UITextField!
    @IBOutlet weak var textFieldLastName: UITextField!
    @IBOutlet weak var textFieldMobile: UITextField!
    @IBOutlet weak var textFieldEmail: UITextField!
    @IBOutlet weak var textFieldPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initViewModel()
    }
    
    func initViewModel() {
        registerViewModel.reloadClosure = { [weak self]  in
            guard let self = self else {return}
            DispatchQueue.main.async {
                self.navigateToViewController()
            }
        }
    }
    
    func navigateToViewController() {
        print("success")
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "ProductViewController") as? ProductViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    @IBAction func registerButtonAction(_ sender: Any) {
        if let firstName = textFieldFirstName.text, let lastName = textFieldLastName.text, let email = textFieldEmail.text, let password = textFieldPassword.text, let mobile = textFieldMobile.text {
            if firstName == "" && lastName == "" && email == "" && password == "" && mobile == "" {
                print("All Fields Are Mandatory")
            } else if firstName == "" {
                print("Please Enter FirstName")
            } else if lastName == "" {
                print("Please Enter LastName")
            } else if email == "" {
                print("Please enter Email id")
            } else if password == "" {
                print("Please Enter Password")
            } else if mobile == "" {
                print("Please Enter Mobile Number")
            }else {
                self.registerViewModel.apiPostCall(firstname: firstName, lastname: lastName, mobile: mobile, email: email, password: password)
            }
        }
    }
}

extension RegisterViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == textFieldFirstName {
            textFieldFirstName.resignFirstResponder()
            textFieldLastName.becomeFirstResponder()
        } else if textField == textFieldLastName {
            textFieldLastName.resignFirstResponder()
            textFieldMobile.becomeFirstResponder()
        } else if textField == textFieldMobile {
            textFieldMobile.resignFirstResponder()
            textFieldEmail.becomeFirstResponder()
        } else if textField == textFieldEmail {
            textFieldEmail.resignFirstResponder()
            textFieldPassword.becomeFirstResponder()
        } else {
            textFieldPassword.resignFirstResponder()
        }
        return true
    }
}
