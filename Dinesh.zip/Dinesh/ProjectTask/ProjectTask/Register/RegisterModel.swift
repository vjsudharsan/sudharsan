//
//  RegisterModel.swift
//  ProjectTask
//
//  Created by nschool on 04/12/20.
//

import Foundation

struct  RegisterModel: Decodable {
    var message: String?
    var status: Int?
    var data: RegisterData?
}
struct RegisterData: Decodable {
    var UserId: Int?
    var Username: String?
}

