//
//  LoginViewModel.swift
//  ProjectTask
//
//  Created by nschool on 04/12/20.
//

import Foundation
class LoginViewModel {
    
    var reloadClosure: (() -> ())?
    var loginModel: LoginModel? {
        didSet{
            self.reloadClosure?()
        }
    }
    func apiPostCall(email: String, password: String) {
           let params = ["email": email, "password": password] as Dictionary<String, Any>
           var request = URLRequest(url: URL(string: "http://demo.smartstorez.com/TESTAPI/UserLogin")!)
           request.httpMethod = "POST"
           request.httpBody = try? JSONSerialization.data(withJSONObject: params, options: [])
           request.addValue("application/json", forHTTPHeaderField: "Content-Type")
           let session = URLSession.shared
           let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
               print(response!)
               do {
                   let json = try JSONSerialization.jsonObject(with: data!) as! Dictionary<String, AnyObject>
                   print(json)
                let jsonDecoder = JSONDecoder()
                let responseModel = try jsonDecoder.decode(LoginModel.self, from: data!)
                print(responseModel)
                self.loginModel = responseModel
                   DispatchQueue.main.async {
                     // your code here
                   }
               } catch {
                   print("error")
               }
           })
           task.resume()
       }
    func isValidEmail(email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
    
    
    }

