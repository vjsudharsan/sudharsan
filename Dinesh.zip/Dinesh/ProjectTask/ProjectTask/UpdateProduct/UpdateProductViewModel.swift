//
//  UpdateProductViewModel.swift
//  ProjectTask
//
//  Created by nschool on 04/12/20.
//

import Foundation
class UpdateProductViewModel {
    var reloadClosure: (() -> ())?
    var updateModel: UpdateModel? {
        didSet{
            self.reloadClosure?()
        }
    }
    
    
    var product: ProductList?
    let emptyString = ""
    
    var id: String {
        return product?.Product_Id ?? emptyString
    }
    var title: String {
        return product?.product_title ?? emptyString
    }
    var product_category: String {
        return product?.category ?? emptyString
    }
    var salesprice: String {
        return product?.sales_price ?? emptyString
    }
    var discountprice: String {
        return product?.discount_price ?? emptyString
    }
    
    func apiPostCall(id: String, title: String, category: String, sales: String, discount: String) {
           let params = [id: id, title: title, category: category, sales: sales, discount: discount] as Dictionary<String, Any>
           var request = URLRequest(url: URL(string: "http://demo.smartstorez.com/TESTAPI/UpdateProduct")!)
           request.httpMethod = "POST"
           request.httpBody = try? JSONSerialization.data(withJSONObject: params, options: [])
           request.addValue("application/json", forHTTPHeaderField: "Content-Type")
           let session = URLSession.shared
           let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
               print(response!)
               do {
                   let json = try JSONSerialization.jsonObject(with: data!) as! Dictionary<String, AnyObject>
                   print(json)

                   DispatchQueue.main.async {
                     // your code here
                   }
               } catch {
                   print("error")
               }
           })
           task.resume()
       }
}
