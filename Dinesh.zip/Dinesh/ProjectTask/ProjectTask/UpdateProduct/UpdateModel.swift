//
//  UpdateModel.swift
//  ProjectTask
//
//  Created by nschool on 04/12/20.
//

import Foundation
struct UpdateModel: Decodable {
    var message: String?
    var status: String?
    var data: String?
}
