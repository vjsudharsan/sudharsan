//
//  ViewController.swift
//  Particle
//
//  Created by nschool on 17/11/20.
//

import UIKit
import SpriteKit

class ViewController: UIViewController {
    private let skView = SKView()
    lazy var buttonOk: UIButton = {
       let button = UIButton()
        button.backgroundColor = .red
        button.setTitle("OK", for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        initSKScene()
        setButton()
    }
    
    private func setupUI() {
        self.view.backgroundColor = .black
        view.addSubview(skView)
        skView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([skView.topAnchor.constraint(equalTo: view.topAnchor), skView.leadingAnchor.constraint(equalTo: view.leadingAnchor), skView.trailingAnchor.constraint(equalTo: view.trailingAnchor), skView.bottomAnchor.constraint(equalTo: view.bottomAnchor)])
    }
    
    private func initSKScene() {
        let particleScene = ParticleScene(size: CGSize(width: 500, height: 500))
        particleScene.scaleMode = .aspectFill
        particleScene.backgroundColor = .clear
        
        skView.presentScene(particleScene)
    }

    func setButton() {
        skView.addSubview(buttonOk)
        
        NSLayoutConstraint.activate([buttonOk.leadingAnchor.constraint(equalTo: skView.leadingAnchor, constant: 15), buttonOk.trailingAnchor.constraint(equalTo: skView.trailingAnchor, constant: -15), buttonOk.bottomAnchor.constraint(equalTo: skView.bottomAnchor, constant: -15)])
    }

}

