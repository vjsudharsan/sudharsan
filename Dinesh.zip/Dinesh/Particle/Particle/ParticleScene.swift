//
//  ParticleScene.swift
//  Particle
//
//  Created by nschool on 17/11/20.
//

import Foundation
import SpriteKit

class ParticleScene: SKScene {
    
    override func didMove(to view: SKView) {
        super.didMove(to: view)
        setupParticleEmitter()
    }
    
    private func setupParticleEmitter() {
        let particleEmitter = SKEmitterNode(fileNamed: "RainParticle")
        particleEmitter?.position = CGPoint(x: size.width / 2, y: size.height - 50 )
        addChild(particleEmitter!)
    }
}
