//
//  ViewController.swift
//  ProgrammaticalTableView
//
//  Created by nschool on 02/11/20.
//

import UIKit

class ViewController: UIViewController {
    
    
    let tableCellIdentifier = "UserListTableViewCell"
    let tableHeaderIdentifier = "TableViewHeaderSection"
    
    var userViewModel = UserViewModel()
    
    lazy var userTable: UITableView = {
        let table = UITableView(frame: .zero, style: .plain)
        table.translatesAutoresizingMaskIntoConstraints = false
        table.isScrollEnabled = true
        table.backgroundColor = .green
        return table
    }()

    override func loadView() {
        super.loadView()
        self.setUpView()
        self.initViewModel()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "User List"
        self.setUpTable()
    }
    func initViewModel() {
        userViewModel.reloadClosure = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                // TableView ReloadData
                self.userTable.reloadData()
            }
        }
        self.userViewModel.apiGetMethodCall()
    }
    
    func setUpTable() {
        userTable.estimatedRowHeight = 100
        userTable.dataSource = self
        userTable.delegate = self
        userTable.register(UserTableViewCell.self, forCellReuseIdentifier: tableCellIdentifier)
        userTable.register(TableViewHeaderSection.self, forHeaderFooterViewReuseIdentifier: tableHeaderIdentifier)
        userTable.separatorStyle = .singleLine
        userTable.tableFooterView = UIView()
    }
    func setUpView() {
        self.view.addSubview(userTable)
        NSLayoutConstraint.activate([userTable.leadingAnchor.constraint(equalTo: self.view.leadingAnchor), userTable.trailingAnchor.constraint(equalTo: self.view.trailingAnchor), userTable.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor), userTable.bottomAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.bottomAnchor)])
    }
    
    func NschoolPlaceholderImage(image: UIImage?, imageView: UIImageView?, imgUrl: String, compate:@escaping (UIImage?) -> Void){
        if image != nil && imageView != nil {
            imageView!.image = image!
        }
        var urlcatch = imgUrl.replacingOccurrences(of: "/", with: "#")
        let documentpath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        urlcatch = documentpath + "/" + "\(urlcatch)"
        let image = UIImage(contentsOfFile:urlcatch)
        if image != nil && imageView != nil {
            imageView!.image = image!
            compate(image)
        } else {
            if let url = URL(string: imgUrl){
                DispatchQueue.global(qos: .background).async {
                    () -> Void in
                    let imgdata = NSData(contentsOf: url)
                    DispatchQueue.main.async {
                        () -> Void in
                        imgdata?.write(toFile: urlcatch, atomically: true)
                        let image = UIImage(contentsOfFile:urlcatch)
                        compate(image)
                        if image != nil  {
                            if imageView != nil  {
                                imageView!.image = image!
                            }
                        }
                    }
                }
            }
        }
    }
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return userViewModel.numberOfSections
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userViewModel.numberOfRowsInSection(section: section)
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = userTable.dequeueReusableCell(withIdentifier: tableCellIdentifier, for: indexPath) as? UserTableViewCell else {
            return UITableViewCell()
        }
        if let userAvatar = userViewModel.cellForRowAt(indexPath: indexPath)?.avatar {
            NschoolPlaceholderImage(image: UIImage(named: "userThumnail"), imageView: cell.userImage, imgUrl: userAvatar) {(image) in
                cell.userImage.image = image
            }
        }
        if indexPath.section == 0 {
            cell.userlabel.text = userViewModel.cellForRowAt(indexPath: indexPath)?.first_name
            cell.accessoryType = .disclosureIndicator
        } else  {
            cell.userlabel.text = userViewModel.cellForRowAt(indexPath: indexPath)?.last_name
            cell.accessoryType = .disclosureIndicator
        }
        return cell
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        guard let header = userTable.dequeueReusableHeaderFooterView(withIdentifier: tableHeaderIdentifier ) as? TableViewHeaderSection else {
            return UIView()
        }
        header.headerLabel.text = userViewModel.getSectionHeaderText(section: section)
        return header
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return UITableView.automaticDimension
    }
}

