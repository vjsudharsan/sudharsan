//
//  CountryModel.swift
//  ProgrammaticalTableView
//
//  Created by nschool on 04/11/20.
//

//https://api.first.org/data/v1/countries
//
//import Foundation




