//
//  CommonFunction.swift
//  ProgrammaticalTableView
//
//  Created by nschool on 06/11/20.
//

import Foundation


struct Common {
    struct TableViewIdentifier {
        static let tableCellIdentifier = "UserListTableViewCell"
        static let tableHeaderIdentifier = "TableViewHeaderSection"
    }
}

