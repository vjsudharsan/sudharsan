//
//  UserViewModel.swift
//  ProgrammaticalTableView
//
//  Created by nschool on 06/11/20.
//

import Foundation

class UserViewModel {
    var reloadClosure: (() -> ())?
    
    var userModel: UserModel? {
        didSet {
            self.reloadClosure?()
        }
    }
    let sectionList = ["1", "2", "3", "4", "5", "6"]
    
    func apiGetMethodCall() {
        var request = URLRequest(url: URL(string: "https://reqres.in/api/users?page=1")!)
        request.httpMethod = "GET"
        URLSession.shared.dataTask(with: request, completionHandler: { data, response, error -> Void in
            do {
                let jsonDecoder = JSONDecoder()
                let responseModel = try jsonDecoder.decode(UserModel.self, from: data!)
                print(responseModel)
                self.userModel = responseModel
            } catch {
                print("JSON Serialization error")
            }
        }).resume()
    }
    var numberOfSections: Int {
        return sectionList.count
    }
    func numberOfRowsInSection(section: Int) -> Int {
        return userModel?.data?.count ?? 0
    }
    func cellForRowAt(indexPath: IndexPath) -> UserList? {
        if let object = userModel?.data?[indexPath.row] {
            return object
        }
        return nil
    }
    func getSectionHeaderText(section: Int) -> String {
        return sectionList[section]
    }
}
