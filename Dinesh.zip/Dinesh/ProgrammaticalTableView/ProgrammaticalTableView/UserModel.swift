//
//  UserModel.swift
//  ProgrammaticalTableView
//
//  Created by nschool on 04/11/20.
//

import Foundation

struct UserModel: Decodable {
    var page: Int?
    var per_page: Int?
    var total: Int?
    var total_pages: Int?
    var data: [UserList]?
    var ad: Ad?
}

struct UserList: Decodable {
    var id: Int?
    var email: String?
    var first_name: String?
    var last_name: String?
    var avatar: String?
}
struct Ad: Decodable {
    var company: String?
    var url: String?
    var text: String?
}
