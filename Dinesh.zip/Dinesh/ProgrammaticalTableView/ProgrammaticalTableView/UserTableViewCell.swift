//
//  UserTableViewCell.swift
//  ProgrammaticalTableView
//
//  Created by nschool on 02/11/20.
//

import UIKit

class UserTableViewCell: UITableViewCell {
    
    lazy var userImage: UIImageView = {
        let image = UIImageView()
        image.translatesAutoresizingMaskIntoConstraints = false
        return image
    }()
    lazy var userlabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .left
        label.textColor = .black
        label.backgroundColor = .lightGray
        label.numberOfLines = .zero
        label.lineBreakMode = .byWordWrapping
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .default, reuseIdentifier: reuseIdentifier)
        self.setUp()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setUp() {
        self.contentView.addSubview(userImage)
        self.contentView.addSubview(userlabel)
        
        NSLayoutConstraint.activate([userImage.leadingAnchor.constraint(equalTo: self.contentView.leadingAnchor, constant: 15), userImage.topAnchor.constraint(equalTo: self.contentView.topAnchor, constant: 10), userImage.centerYAnchor.constraint(equalTo: self.contentView.centerYAnchor), userImage.heightAnchor.constraint(equalToConstant: 60), userImage.widthAnchor.constraint(equalToConstant: 60)])
        
        NSLayoutConstraint.activate([userlabel.leadingAnchor.constraint(equalTo: userImage.trailingAnchor, constant: 15), userlabel.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor, constant: -15), userlabel.topAnchor.constraint(equalTo: self.contentView.topAnchor, constant: 15), userlabel.bottomAnchor.constraint(equalTo: self.contentView.bottomAnchor, constant: -15)])
    }
}
