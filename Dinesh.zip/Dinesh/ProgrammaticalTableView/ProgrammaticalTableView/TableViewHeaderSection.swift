//
//  TableViewHeaderSection.swift
//  ProgrammaticalTableView
//
//  Created by nschool on 02/11/20.
//

import UIKit

class TableViewHeaderSection: UITableViewHeaderFooterView {
    
    lazy var headerLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .center
        label.textColor = .red
        label.backgroundColor = .cyan
        label.numberOfLines = .zero
        label.lineBreakMode = .byWordWrapping
        return label
    }()
    
    override init(reuseIdentifier: String?) {
        super.init(reuseIdentifier: reuseIdentifier)
        self.setupHeader()
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func setupHeader() {
        self.contentView.addSubview(headerLabel)
        
        NSLayoutConstraint.activate([headerLabel.leadingAnchor.constraint(equalTo: self.contentView.leadingAnchor, constant: 15), headerLabel.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor, constant: -15), headerLabel.topAnchor.constraint(equalTo: self.contentView.topAnchor, constant: 15), headerLabel.bottomAnchor.constraint(equalTo: self.contentView.bottomAnchor, constant: -15)])
    }
}
