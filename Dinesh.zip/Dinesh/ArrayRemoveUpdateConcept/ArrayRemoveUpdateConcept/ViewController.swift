//
//  ViewController.swift
//  ArrayRemoveUpdateConcept
//
//  Created by nschool on 18/12/20.
//

import UIKit

class ViewController: UIViewController {
    var country: [CountryList]?
    var object = CountryList()
//    var countryList = [object]
 
    override func viewDidLoad() {
        super.viewDidLoad()
//        var array = ["IND", "AUS", "ENG", "SA"]
//        array.append("WI")
//        print(array)
//        array.removeFirst()
//        array.removeLast()
//        print(array)
//        array.remove(at: 1)
//        print(array)
//        array.removeAll()
//        print(array)
//
        
//        var object = CountryList(first: "IND", second: "AUS", third: "ENG", four: "SA", select: 1)
//       var countryList = [object]
      //  countryList.append(CountryList(first: "WI", second: "SL", third: "AFG", four: "BANG", select: 2))
       // print(countryList)
//        if countryList[0].select == 1 {
//            print("ok")
//            countryList.removeFirst()
//        print(countryList)
        
//        var array = [1,2,3,4]
//
//        for i in 0..<3 {
//            if array[i] == 1 {
//                array.removeFirst()
//            }
//            print("done")
//        }
//        print(array)
        
      //  print(countryList)
    }
    
    @IBAction func buttonActionAppend(sender: UIButton) {
  
        

        country.append(CountryList (first: "IND", second: "AUS", third: "ENG", four: "SA", select: 1))
        print(country)
        }
        
    @IBAction func buttonActionRemove(sender: UIButton) {
        for i in 0..<2 {
            if country {
            print("ok")
        //countryList.removeFirst()
           // countryList[i].first = "INDIA"
        } else {
            print("Error")
        }
        }
        
    }
}

