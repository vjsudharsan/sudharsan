//
//  CountryListModel.swift
//  ArrayRemoveUpdateConcept
//
//  Created by nschool on 18/12/20.
//

import Foundation

struct CountryList {
    var first: String?
    var second: String?
    var third: String?
    var four: String?
    var select: Int?
}
