//
//  ViewController.swift
//  FlipKartProject
//
//  Created by nschool on 11/11/20.
//

import UIKit

class ViewController: UIViewController {
    lazy var imageview: UIImageView = {
        let imageName = UIImageView()
        imageName.translatesAutoresizingMaskIntoConstraints = false
        imageName.image = UIImage(named: "flipkart")
        return imageName
        
    }()
    lazy var fbimageview: UIImageView = {
        let fbimageName = UIImageView()
        fbimageName.translatesAutoresizingMaskIntoConstraints = false
        fbimageName.image = UIImage(named: "fb")
        return fbimageName
        
    }()
    lazy var textFieldFristName: UITextField = {
        let firstName = UITextField ()
        firstName.translatesAutoresizingMaskIntoConstraints = false
        firstName.textAlignment = .left
        firstName.backgroundColor = .systemRed
        firstName.placeholder = "enter the Email id  "
        return firstName
    }()
    
    lazy var textPassword:UITextField = {
        let password = UITextField ()
        password.translatesAutoresizingMaskIntoConstraints = false
        password.textAlignment = .left
        password.backgroundColor = .purple
        password.placeholder = "Enter the password"
        return password
    }()
    lazy var buttonLogin:UIButton = {
        let Login = UIButton()
        Login.translatesAutoresizingMaskIntoConstraints = false
        Login.backgroundColor = .systemPink
        Login.setTitle("Login", for: .normal)
        Login.layer.cornerRadius = 7.5
        return Login
        
    }()
    lazy var buttonForGotPassword:UIButton = {
        let button = UIButton(frame: CGRect(x: 100, y: 100, width: 100, height: 50))
        let forgotpassword = UIButton()
        forgotpassword.translatesAutoresizingMaskIntoConstraints = false
        forgotpassword.backgroundColor = .systemPink
        forgotpassword.setTitle("forGot?", for: .normal)
        return forgotpassword
        
    }()
    
    lazy var labellasstName:UILabel = {
        let labellastName = UILabel()
        labellastName.textAlignment = .center
        labellastName.translatesAutoresizingMaskIntoConstraints = false
        labellastName.numberOfLines = .zero
        labellastName.lineBreakMode = .byCharWrapping
        labellastName.backgroundColor = .systemGreen
        labellastName.textColor = .systemBlue
        labellastName.text = "New to Flipkart?"
        labellastName.textAlignment = NSTextAlignment.center
        return labellastName
    }()
    lazy var buttonsignup:UIButton = {
        let buttonsignup = UIButton()
        buttonsignup.translatesAutoresizingMaskIntoConstraints = false
        buttonsignup.backgroundColor = .systemYellow
        buttonsignup.setTitle("sign up", for: .normal)
        return buttonsignup
    }()
    
    lazy var labelsecondName:UILabel = {
        let labelsecondName = UILabel()
        labelsecondName.textAlignment = .center
        labelsecondName.translatesAutoresizingMaskIntoConstraints = false
        labelsecondName.numberOfLines = Int(0.2)
        labelsecondName.lineBreakMode = .byCharWrapping
        labelsecondName.backgroundColor = .systemGreen
        labelsecondName.textColor = .systemBlue
        labelsecondName.text = "Do you login with your social account?"
        labelsecondName.textAlignment = NSTextAlignment.center
        return labelsecondName
    }()
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
        backgroundImage.image = UIImage(named: "gm")
        self.view.insertSubview(backgroundImage, at: 0)
        buttonsignup.addTarget(self, action: Selector(("Action:")), for: UIControl.Event.touchUpInside)
        self.setup()
        // Do any additional setup after loading the view.
    }
    
    func setup() {
        self.view.addSubview(imageview)
        self.view.addSubview(textFieldFristName)
        self.view.addSubview(textPassword)
        self.view.addSubview(buttonLogin)
        self.view.addSubview(buttonForGotPassword)
        self.view.addSubview(labellasstName)
        self.view.addSubview(buttonsignup)
        self.view.addSubview(labelsecondName)
        
        
        NSLayoutConstraint.activate([imageview.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 50), imageview.heightAnchor.constraint(equalToConstant: 60), imageview.widthAnchor.constraint(equalToConstant: 60),imageview.centerXAnchor.constraint(equalTo: self.view.centerXAnchor)])
        
        
        NSLayoutConstraint.activate([textFieldFristName.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 30), textFieldFristName.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -30),textFieldFristName.topAnchor.constraint(equalTo: self.imageview.bottomAnchor, constant: 100),textFieldFristName.heightAnchor.constraint(equalToConstant: 48)])
        
        NSLayoutConstraint.activate([textPassword.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 30),textPassword.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -30),textPassword.topAnchor.constraint(equalTo: self.textFieldFristName.bottomAnchor, constant: 30),textPassword.heightAnchor.constraint(equalToConstant: 48)])
        
        NSLayoutConstraint.activate([buttonLogin.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 50), buttonLogin.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -50),buttonLogin.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),buttonLogin.topAnchor.constraint(greaterThanOrEqualTo: self.buttonForGotPassword.bottomAnchor,constant: 50),buttonLogin.heightAnchor.constraint(equalToConstant: 48)])
        
        
        
        NSLayoutConstraint.activate([buttonForGotPassword.leadingAnchor.constraint(equalTo: self.view.leadingAnchor ,constant: 250), buttonForGotPassword.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -10), buttonForGotPassword.centerXAnchor.constraint(greaterThanOrEqualTo: self.view.centerXAnchor), buttonForGotPassword.topAnchor.constraint(equalTo: self.textPassword.bottomAnchor, constant: 10)])
        
        
        NSLayoutConstraint.activate([labellasstName.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 100), labellasstName.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -100), labellasstName.topAnchor.constraint(equalTo: self.buttonLogin.bottomAnchor, constant: 10), labellasstName.heightAnchor.constraint(equalToConstant: 30) ])
        //
        
        
        NSLayoutConstraint.activate([buttonForGotPassword.leadingAnchor.constraint(equalTo: self.view.leadingAnchor ,constant: 250), buttonForGotPassword.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -10), buttonForGotPassword.centerXAnchor.constraint(greaterThanOrEqualTo: self.view.centerXAnchor), buttonForGotPassword.topAnchor.constraint(equalTo: self.textPassword.bottomAnchor, constant: 10)])
        
        //
        
        NSLayoutConstraint.activate([buttonsignup.leadingAnchor.constraint(equalTo: self.view.leadingAnchor ,constant: 250), buttonsignup.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -10), buttonForGotPassword.centerXAnchor.constraint(greaterThanOrEqualTo: self.view.centerXAnchor), buttonsignup.topAnchor.constraint(equalTo: self.labellasstName.bottomAnchor, constant: 10)])
        
        
        //
        NSLayoutConstraint.activate([labelsecondName.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 20), labelsecondName.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20), labelsecondName.topAnchor.constraint(equalTo: self.buttonsignup.bottomAnchor, constant: 100), labellasstName.heightAnchor.constraint(equalToConstant: 100)])
//        
//        NSLayoutConstraint.activate([fbimageview.topAnchor.constraint(equalTo: self.labelsecondName.bottomAnchor, constant: 10), fbimageview.heightAnchor.constraint(equalToConstant: -10), fbimageview.widthAnchor.constraint(equalToConstant: 10),fbimageview.centerYAnchor.constraint(equalTo: self.fbimageview.centerYAnchor)])
//        
//        //
//        
        
    }
    
}
