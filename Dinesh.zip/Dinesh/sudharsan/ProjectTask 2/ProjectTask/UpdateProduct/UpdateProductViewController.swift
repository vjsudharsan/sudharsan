//
//  UpdateProductViewController.swift
//  ProjectTask
//
//  Created by nschool on 04/12/20.
//

import UIKit

class UpdateProductViewController: UIViewController {
    
    var updateProductViewModel = UpdateProductViewModel()
    
    @IBOutlet weak var stackViewUpdateProduct: UIStackView!
    
    @IBOutlet weak var productIdTextField: UITextField!
    @IBOutlet weak var productTitleTextField: UITextField!
    @IBOutlet weak var categoryTextField: UITextField!
    @IBOutlet weak var salesPriceTextField: UITextField!
    @IBOutlet weak var discountPriceTextField: UITextField!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        productIdTextField.text = updateProductViewModel.id
        productTitleTextField.text = updateProductViewModel.title
        categoryTextField.text = updateProductViewModel.product_category
        salesPriceTextField.text = updateProductViewModel.salesprice
        discountPriceTextField.text = updateProductViewModel.discountprice
    }
    
    func initViewModel() {
        updateProductViewModel.reloadClosure = { [weak self] in
            guard let self = self else {return}
            DispatchQueue.main.async {
                self.navigateToViewController()
            }
        }
    }
    
    func navigateToViewController() {
        print("success")
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "ProductViewController") as? ProductViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    @IBAction func updateButtonAction(_ sender: Any) {
      // if let id = productIdTextField.text,let title = productTitleTextField, let category = categoryTextField.text, let sales = salesPriceTextField, let discount = discountPriceTextField.text {
            
        //self.updateProductViewModel.apiPostCall(id: <#T##String#>, title: <#T##String#>, category: <#T##String#>, sales: <#T##String#>, discount: <#T##String#>)
    }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


