//
//  LoginViewController.swift
//  ProjectTask
//
//  Created by nschool on 04/12/20.
//

import UIKit

class LoginViewController: UIViewController {
    var loginViewModel = LoginViewModel()
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initViewModel()

        
    }
    func initViewModel() {
        loginViewModel.reloadClosure = { [weak self] in
            guard let self = self else {return}
            DispatchQueue.main.async {
                self.navigateToViewController()
            }
        }
    }
    func showAlert(title: String, message: String) {
        print("navigate")
            let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    
    func navigateToViewController() {
        print("success")
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "ProductViewController") as? ProductViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    

    @IBAction func loginButtonAction(_ sender: Any) {
        if let email = emailTextField.text, let password = passwordTextField.text {
            if email == "" && password == "" {
                showAlert(title: "Information", message: "All Fields Are Manditory")
            } else if email == "" {
                showAlert(title: "Information", message: "Enter Email")
            } else if password == "" {
                showAlert(title: "Information", message: "Enter Password")
            } else if !loginViewModel.isValidEmail(email: email) {
                showAlert(title: "Information", message: "Invalid Email")
            } else {
                print("success")
                self.loginViewModel.apiPostCall(email: email, password: password)
            }
        }
    }
    
    @IBAction func registerButtonAction(_ sender: Any) {
    }
}

extension LoginViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == emailTextField {
            emailTextField.resignFirstResponder()
            passwordTextField.becomeFirstResponder()
        } else if textField == passwordTextField {
            passwordTextField.resignFirstResponder()
        }
        return true
    }
}
