//
//  BabiesCollectionViewCell.swift
//  babyCollectionView
//
//  Created by nschool on 24/11/20.
//

import UIKit

class BabiesCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var bbyImageView: UIImageView!
}
