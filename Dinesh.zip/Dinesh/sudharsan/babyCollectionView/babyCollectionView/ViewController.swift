//
//  ViewController.swift
//  babyCollectionView
//
//  Created by nschool on 24/11/20.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var babyCollectionView: UICollectionView!
        var imageItems = ["bby1","bby2","bby3","bby4","bby5","bby6","bby7","bby1","bby2","bby3","bby4","bby5","bby6","bby7","bby1","bby2","bby3","bby4","bby5","bby6","bby7"]
       
        var babiesCollectionViewCell = "BabiesCollectionViewCell"

        override func viewDidLoad() {
               super.viewDidLoad()
               self.setup()
            
            // Do any additional setup after loading the view.
           }
    func setup() {
        babyCollectionView.setContentOffset(babyCollectionView.contentOffset, animated: false)
        let cellSize = CGSize(width:babyCollectionView.frame.size.width/4, height:180)
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.itemSize = cellSize
        layout.sectionInset = UIEdgeInsets(top: 1, left: 1, bottom: 1, right: 1)
        layout.minimumLineSpacing = 9.0
        babyCollectionView.setCollectionViewLayout(layout, animated: true)
    }

    }
    extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
        func numberOfSections(in collectionView: UICollectionView) -> Int {
            return 1
        }
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return imageItems.count
        }
        
        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            let cell = self.babyCollectionView.dequeueReusableCell(withReuseIdentifier: babiesCollectionViewCell, for: indexPath as IndexPath) as! BabiesCollectionViewCell
            cell.bbyImageView.image = UIImage(named: imageItems[indexPath.item])
            return cell
        }
        
        
    }
