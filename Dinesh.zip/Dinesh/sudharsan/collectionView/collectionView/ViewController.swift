//
//  ViewController.swift
//  collectionView
//
//  Created by nschool on 24/11/20.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var bikeCollectionView: UICollectionView!
    var imageItems = ["bike1","bike2","bike3","bike4","bike5","bike1","bike2","bike3","bike4","bike5","bike1","bike2","bike3","bike4","bike5","bike1","bike2","bike3","bike4","bike5","bike1","bike2","bike3","bike4","bike5","bike1","bike2","bike3","bike4","bike5","bike1","bike2","bike3","bike4","bike5","bike1","bike2","bike3","bike4","bike5"]
    var labelItems = ["BMW","FZ","KTM","RE","PULSAR","BMW","FZ","KTM","RE","PULSAR","BMW","FZ","KTM","RE","PULSAR","BMW","FZ","KTM","RE","PULSAR","BMW","FZ","KTM","RE","PULSAR","BMW","FZ","KTM","RE","PULSAR","BMW","FZ","KTM","RE","PULSAR","BMW","FZ","KTM","RE","PULSAR"]
    var bikeCollectionViewCell = "BikeCollectionViewCell"

    override func viewDidLoad() {
           super.viewDidLoad()
           self.setup()
        
        // Do any additional setup after loading the view.
       }
func setup() {
    bikeCollectionView.setContentOffset(bikeCollectionView.contentOffset, animated: false)
    let cellSize = CGSize(width:bikeCollectionView.frame.size.width/5, height:180)
    let layout = UICollectionViewFlowLayout()
    layout.scrollDirection = .vertical
    layout.itemSize = cellSize
    layout.sectionInset = UIEdgeInsets(top: 1, left: 1, bottom: 1, right: 1)
    layout.minimumLineSpacing = 9.0
    bikeCollectionView.setCollectionViewLayout(layout, animated: true)
}

}
extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageItems.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell =  self.bikeCollectionView.dequeueReusableCell(withReuseIdentifier: bikeCollectionViewCell, for: indexPath as IndexPath) as! BikeCollectionViewCell
        cell.imageViewBike.image = UIImage(named: imageItems[indexPath.item])
        cell.labelBikeName.text = self.labelItems[indexPath.row]
        return cell
    }
    
    
}
