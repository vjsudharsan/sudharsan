//
//  BikeCollectionViewCell.swift
//  collectionView
//
//  Created by nschool on 24/11/20.
//

import UIKit


class BikeCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageViewBike: UIImageView!
    @IBOutlet weak var labelBikeName: UILabel!
    
}
