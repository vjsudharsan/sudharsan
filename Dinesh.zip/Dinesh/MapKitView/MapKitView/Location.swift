//
//  Location.swift
//  MapKitView
//
//  Created by nschool on 08/12/20.
//

import Foundation
import MapKit

struct Location {
    var name: String?
    var lattitude: CLLocationDegrees
    var longtitude: CLLocationDegrees
}
