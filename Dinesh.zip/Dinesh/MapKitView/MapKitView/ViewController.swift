//
//  ViewController.swift
//  MapKitView
//
//  Created by nschool on 08/12/20.
// https://www.iosapptemplates.com/blog/swift-programming/mapkit-tutorial
//https://developers.google.com/maps/documentation/ios-sdk/start#use-cocoapods

import UIKit
import MapKit

class ViewController: UIViewController {
    
    @IBOutlet weak var mapView: MKMapView!
    let locationManager = CLLocationManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        //
        self.locationManager.requestAlwaysAuthorization()

        // For use in foreground
        self.locationManager.requestWhenInUseAuthorization()

        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
        }
        
        
    }
    
    func checkLocationServices() {
      if CLLocationManager.locationServicesEnabled() {
        checkLocationAuthorization()
      } else {
        // Show alert letting the user know they have to turn this on.
      }
    }
    func checkLocationAuthorization() {
      switch CLLocationManager.authorizationStatus() {
      case .authorizedWhenInUse:
        mapView.showsUserLocation = true
       case .denied: // Show alert telling users how to turn on permissions
       break
      case .notDetermined:
        locationManager.requestWhenInUseAuthorization()
        mapView.showsUserLocation = true
      case .restricted: // Show an alert letting them know what’s up
       break
      case .authorizedAlways:
       break
      }
    }
    func fetchStadiumsOnMap(place: [Location]) {
      for places in place {
        let annotations = MKPointAnnotation()
        annotations.title = places.name
        annotations.coordinate = CLLocationCoordinate2D(latitude:
          places.lattitude, longitude: places.longtitude)
        mapView.addAnnotation(annotations)
      }
    }
    
}

extension ViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let locValue: CLLocationCoordinate2D = manager.location?.coordinate else { return }
        print("locations = \(locValue.latitude) \(locValue.longitude)")
        self.checkLocationServices()
        let places = [Location(name: "Edayarpalayam", lattitude: locValue.latitude, longtitude: locValue.longitude)]
        self.fetchStadiumsOnMap(place: places)
    }

}
