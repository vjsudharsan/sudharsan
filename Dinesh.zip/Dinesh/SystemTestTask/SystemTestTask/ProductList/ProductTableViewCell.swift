//
//  ProductTableViewCell.swift
//  SystemTestTask
//
//  Created by nschool on 09/12/20.
//

import UIKit

class ProductTableViewCell: UITableViewCell {
    @IBOutlet weak var imageViewProduct: UIView!
    @IBOutlet weak var labelProductId: UILabel!
    @IBOutlet weak var labelProductTitle: UILabel!
    @IBOutlet weak var labelCategory: UILabel!
    @IBOutlet weak var labelSalesPrice: UILabel!
    @IBOutlet weak var labelDiscountPrice: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
