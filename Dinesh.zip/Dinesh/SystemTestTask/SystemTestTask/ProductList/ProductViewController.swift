//
//  ProductViewController.swift
//  SystemTestTask
//
//  Created by nschool on 09/12/20.
//

import UIKit

class ProductViewController: UIViewController {
var reuseIdentifier = "ProductTableViewCell"
    @IBOutlet weak var tableViewProduct: UITableView!
    var productViewModel = ProductViewModel()
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.initViewModel()
    }
    
    func initViewModel() {
        productViewModel.reloadClosure = { [weak self] in
            guard let self = self else {return}
            DispatchQueue.main.async {
                self.tableViewProduct.reloadData()
            }
        }
        self.productViewModel.getApiProduct()
    }


}
extension ProductViewController : UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productViewModel.numberOfRowsInSection
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableViewProduct.dequeueReusableCell(withIdentifier: reuseIdentifier) as! ProductTableViewCell
        if let objectProduct = productViewModel.getObject(indexpath: indexPath), let productId = objectProduct.Product_Id, let salesPrice = objectProduct.sales_price {
            cell.labelProductId.text = productId
            cell.labelSalesPrice.text = salesPrice
            
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
   
}
