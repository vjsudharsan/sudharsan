//
//  ProductModel.swift
//  SystemTestTask
//
//  Created by nschool on 09/12/20.
//

import Foundation
struct ProductModel: Decodable {
    var message: String?
    var status: String?
    var data: [ProductList]?
}
struct ProductList: Decodable {
    var Product_Id: String?
    var product_title: String?
    var category: String?
    var image_url: String?
    var sales_price: String?
    var discount_price: String?
}
