//
//  LoginViewController.swift
//  SystemTestTask
//
//  Created by nschool on 09/12/20.
//

import UIKit

class LoginViewController: UIViewController {
    @IBOutlet weak var textFieldEmail: UITextField!
    @IBOutlet weak var textFieldPassword: UITextField!
    var loginViewModel = LoginViewModel()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initViewModel()
        // Do any additional setup after loading the view.
    }
    
    func initViewModel() {
        loginViewModel.reloadClosure = { [weak self] in
            guard let self = self else {return}
            DispatchQueue.main.async {
                
            }
            
        }
    }
    
    
    @IBAction func buttonActionLogin(_ sender: UIButton) {
       if let email = textFieldEmail.text, let password = textFieldPassword.text {
            self.loginViewModel.postAction(email: email , password: password)
        }
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
