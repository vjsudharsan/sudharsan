//
//  LoginModel.swift
//  SystemTestTask
//
//  Created by nschool on 09/12/20.
//

import Foundation
struct LoginModel: Decodable {
    var message: String?
    var status: Int?
    var data: Datalist?
}

struct  Datalist: Decodable {
    var UserId: String?
    var firstname: String?
    var lastname: String?
    var mobile: String?
    var email: String?
}
