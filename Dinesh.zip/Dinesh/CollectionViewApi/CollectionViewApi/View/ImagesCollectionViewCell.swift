//
//  imagesCollectionViewCell.swift
//  CollectionViewApi
//
//  Created by nschool on 20/11/20.
//

import UIKit

class imagesCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var sampleImage: UIImageView!
    
}
