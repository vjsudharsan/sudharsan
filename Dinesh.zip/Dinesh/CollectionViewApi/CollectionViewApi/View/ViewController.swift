//
//  ViewController.swift
//  CollectionViewApi
//
//  Created by nschool on 20/11/20.
//

import UIKit

class ViewController: UIViewController {
    var reuseIdentifier = "ImagesCollectionViewCell"
    var collectionViewModel = CollectionViewModel()
    var collectionModel: CollectionModel?
    
    @IBOutlet weak var imageColletionView: UICollectionView!

    override func viewDidLoad() {
        super.viewDidLoad()
        setUpCollectionView()
        initViewModel()
        // Do any additional setup after loading the view.
    }
    func initViewModel() {
        collectionViewModel.reloadClosure = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                // TableView ReloadData
                self.imageColletionView.reloadData()
            }
        }
        self.collectionViewModel.apiGetMethodCall()
    }
    
    func setUpCollectionView() {
        imageColletionView.setContentOffset(imageColletionView.contentOffset, animated: false)
        let cellSize = CGSize(width: 100, height: 100)
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.itemSize = cellSize
        layout.sectionInset = UIEdgeInsets(top: 1, left: 1, bottom: 1, right: 1)
        layout.minimumLineSpacing = 10.0
        imageColletionView.setCollectionViewLayout(layout, animated: true)
    }
    
    func NschoolPlaceholderImage(image: UIImage?, imageView: UIImageView?, imgUrl: String, compate:@escaping (UIImage?) -> Void){
        if image != nil && imageView != nil {
            imageView!.image = image!
        }
        var urlcatch = imgUrl.replacingOccurrences(of: "/", with: "#")
        let documentpath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        urlcatch = documentpath + "/" + "\(urlcatch)"
        let image = UIImage(contentsOfFile:urlcatch)
        if image != nil && imageView != nil {
            imageView!.image = image!
            compate(image)
        } else {
            if let url = URL(string: imgUrl){
                DispatchQueue.global(qos: .background).async {
                    () -> Void in
                    let imgdata = NSData(contentsOf: url)
                    DispatchQueue.main.async {
                        () -> Void in
                        imgdata?.write(toFile: urlcatch, atomically: true)
                        let image = UIImage(contentsOfFile:urlcatch)
                        compate(image)
                        if image != nil  {
                            if imageView != nil  {
                                imageView!.image = image!
                            }
                        }
                    }
                }
            }
        }
    }
}

extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return collectionViewModel.numberOfSection
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return collectionViewModel.numberOfItemsInSection
        //return 5
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = imageColletionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath as IndexPath) as! imagesCollectionViewCell
        if let dataObject = collectionViewModel.getCellForItem(indexpath: indexPath), let urlImage = dataObject.download_url {
            NschoolPlaceholderImage(image: UIImage(named: "apple"), imageView: cell.sampleImage, imgUrl: urlImage ) { (image) in
                cell.sampleImage.image = image
            }
        }
        //cell.sampleImage.image = UIImage(named: "1")
        return cell
    }
}

