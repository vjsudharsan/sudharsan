//
//  CollectionViewModel.swift
//  CollectionViewApi
//
//  Created by nschool on 20/11/20.
//

import Foundation
class CollectionViewModel {
    
    var reloadClosure: (() -> ())?
    
    var collectionModel: CollectionModel? {
        didSet {
            self.reloadClosure?()
        }
    }
    
    func apiGetMethodCall() {
        var request = URLRequest(url: URL(string: "https://reqres.in/api/users?page=1")!)
        request.httpMethod = "GET"
        URLSession.shared.dataTask(with: request, completionHandler: { data, response, error -> Void in
            do {
                let jsonDecoder = JSONDecoder()
                let responseModel = try jsonDecoder.decode(CollectionModel.self, from: data!)
                print(responseModel)
                self.collectionModel = responseModel
            } catch {
                print("JSON Serialization error")
            }
        }).resume()
    }

    
    
    var numberOfSection: Int {
        return 1
    }
    var numberOfItemsInSection: Int {
        return collectionModel?.imageList?.count ?? 0
    }
    func getCellForItem(indexpath: IndexPath) -> ImagesList? {
        if let object = self.collectionModel?.imageList?[indexpath.row] {
            return object
        }
        return nil
    }
}
