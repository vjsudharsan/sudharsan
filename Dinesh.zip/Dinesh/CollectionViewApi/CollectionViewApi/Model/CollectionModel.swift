//
//  CollectionModel.swift
//  CollectionViewApi
//
//  Created by nschool on 20/11/20.
//

import Foundation
//https://picsum.photos/v2/list

struct CollectionModel: Decodable {
    var imageList: [ImagesList]?
}

struct ImagesList: Decodable {
    var id: String?
    var author: String?
    var width: Int?
    var height: Int?
    var url: String?
    var download_url: String?
}
