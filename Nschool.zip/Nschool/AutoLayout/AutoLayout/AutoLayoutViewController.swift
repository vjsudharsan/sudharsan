//
//  AutoLayoutViewController.swift
//  LoginProject
//
//  Created by nschool on 24/10/20.
//

import UIKit

class AutoLayoutViewController: UIViewController {

    lazy var labelName: UILabel = {
        let label = UILabel()
        label.text = "Make a symbolic breakpoint at UIViewAlertForUnsatisfiableConstraints to catch this in the debugger.The methods in the UIConstraintBasedLayoutDebugging category on UIView listed in view may also be helpful"
        label.numberOfLines = .zero
        label.textAlignment = .left
        label.textColor = .black
        label.backgroundColor = .purple
        label.translatesAutoresizingMaskIntoConstraints = true
        label.font = UIFont.systemFont(ofSize: 15)
        return label
    }()
    
//    override func loadView() {
//        self.setUpView()
//    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
//        let leadingConstraint = activityIndicator.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 10)
//        let trailingConstraint = activityIndicator.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: 10)
//        let heightConstraint = activityIndicator.heightAnchor.constraint(equalToConstant: 50)
//        let widthConstraint = activityIndicator.widthAnchor.constraint(equalToConstant: 50)
//        let centerXConstraint = activityIndicator.centerXAnchor.constraint(equalTo: self.view.centerXAnchor, constant: 0)
//        let centerYConstraint = activityIndicator.centerYAnchor.constraint(equalTo: self.view.centerYAnchor, constant: 0)
//        let topConstraint = activityIndicator.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 15)
//        let bottomContraint = activityIndicator.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: 0)
        self.setUpView()
    }
    func setUpView() {
        self.view.addSubview(labelName)
        let leadingConstraint = labelName.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15)
        let topConstraint = labelName.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 15)
        let trailingConstraint = labelName.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15)
        let heightConstraint = labelName.heightAnchor.constraint(greaterThanOrEqualToConstant: 40)
        NSLayoutConstraint.activate([leadingConstraint, topConstraint, trailingConstraint, heightConstraint])
    }
    
}
