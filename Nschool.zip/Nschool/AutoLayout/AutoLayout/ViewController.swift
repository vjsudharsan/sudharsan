//
//  ViewController.swift
//  AutoLayout
//
//  Created by nschool on 24/10/20.
//

import UIKit

class ViewController: UIViewController {

    lazy var labelName: UILabel = {
        let label = UILabel()
        label.text = "Make a symbolic breakpoint at UIViewAlertForUnsatisfiableConstraints to catch this in the debugger.The methods in the UIConstraintBasedLayoutDebugging category on UIView listed in view may also be helpful"
        label.numberOfLines = .zero
        label.textAlignment = .left
        label.textColor = .black
        label.translatesAutoresizingMaskIntoConstraints = true
        label.font = UIFont.systemFont(ofSize: 15)
        return label
    }()
//    override func loadView() {
//        self.setUpView()
//    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.setUpView()
    }
    func setUpView() {
        self.view.addSubview(labelName)
        labelName.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15).isActive = true
        labelName.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 15).isActive = true
        labelName.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15).isActive = true
        labelName.heightAnchor.constraint(greaterThanOrEqualToConstant: 40).isActive = true
       //NSLayoutConstraint.activate([leadingConstraint, topConstraint, trailingConstraint, heightConstraint])
    }


}

