//
//  ViewController.swift
//  labelwithconstraint
//
//  Created by nschool on 28/10/20.
//

import UIKit



