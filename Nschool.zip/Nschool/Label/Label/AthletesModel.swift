//
//  AthletesModel.swift


import Foundation

struct AthletesModel: Decodable {
    var lastname: String?
    var firstname: String?
    var yob: String?
    var team: String?
}
