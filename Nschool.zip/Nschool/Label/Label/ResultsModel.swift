//
//  ResultsModel.swift


import Foundation
struct ResultsModel: Decodable {
    var results: [ResultList]?
}

struct ResultList: Decodable {
    var title: String?
    var body: String?
    var issues: [IssuesList]?
    var signatureThreshold: Int?
    var signatureCount: Int?
    var signaturesNeeded: Int?
}

struct IssuesList: Decodable {
    var id: String?
    var name: String?
}
