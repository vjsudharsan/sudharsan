//
//  RegViewController.swift
//  Label
//
//  Created by nschool on 01/10/20.
//

import UIKit

class RegViewController: UIViewController {
    @IBOutlet var nameTextfield: UITextField!
    var nametxt:String?
    var age:Int?
    @IBOutlet weak var segmentControl: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    func getName() -> String{
       return ""
    }

    @IBAction func segmentControlAction(_ sender: Any) {
        
        switch self.segmentControl?.selectedSegmentIndex {
        case 0:
            break
        case 1:
            break
        case 2:
            break
        default:
            break
        }
        
    }

}
