//
//  ViewController.swift
//  Label
//
//  Created by nschool on 01/10/20.
//

import UIKit

class ViewController: UIViewController {

    /// UILabel
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subLabel: UILabel!
    /// UITextField
    @IBOutlet weak var textFieldUserName: UITextField!
    @IBOutlet weak var textFieldPassword: UITextField!
    /// UIButton
    @IBOutlet weak var buttonSubmit: UIButton!
    ///UIImageView
    @IBOutlet weak var iTunesImageView: UIImageView!
    
    
    
    var value: Int?
    var text: String?
    var boolValue: Bool?
    
    var countryList = ["India", "USA"]
    var countryListObject = [["key": "value", "key1": "value"], ["key": "value", "key1": "value"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.title = "Login"
        value = 5
        boolValue = true
        text = "N-School"
        print(self.getValue())
        let newText = self.getText()
        
        titleLabel.text = newText
        titleLabel.backgroundColor = .yellow
        titleLabel.numberOfLines = 0
        titleLabel.textColor = UIColor.red
        titleLabel.textAlignment = .center
        
        subLabel.text = "IOS"
        subLabel.backgroundColor = .blue
        subLabel.textColor = .black
        subLabel.textAlignment = .center
        
        iTunesImageView.image = UIImage.init(named: "itunes")
        
        
        if self.setValue(value: self.getValue(), text: self.getText()) {
            print("Success")
        } else {
            print("Failed")
        }

        
    }
    func getValue() -> Int {
        if let value = value {
            return value
        }
        return 0
    }
    func getText() -> String {
        if let text = text {
            return text
        }
        return ""
    }
    func setValue(value: Int, text: String) -> Bool {
        if text.count == 0 {
            return false
        } else {
            return true
        }
    }
    
    @IBAction func buttonSubmitAction(senter: UIButton) {
        if let userName = textFieldUserName.text, let password = textFieldPassword.text {
            print("Username: \(userName)")
            print("Password: \(password)")
            // Navigate to next screen
            
        }
//        let controller = RegViewController()
//        self.navigationController?.pushViewController(controller, animated: true)
        
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "RegViewController") as? RegViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }


}

extension ViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        print("Begin Editing: \(textField.tag)")
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        print("End Editing: \(textField.tag)")
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let maxLength = 4
        let currentString: NSString = textField.text! as NSString
        let newString: NSString =
            currentString.replacingCharacters(in: range, with: string) as NSString
        return newString.length <= maxLength
    }
}
