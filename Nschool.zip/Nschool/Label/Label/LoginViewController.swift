//
//  LoginViewController.swift
//  Label
//
//  Created by nschool on 01/10/20.
//

import UIKit

class LoginViewController: UIViewController {

    ///UITableView
    @IBOutlet weak var tableViewList: UITableView!
    var countryList = ["India", "USA"]
    var animals = ["Horse", "Cow"]
    var athletesModel = [AthletesModel]()
    var resultsModel: ResultsModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        athletesModel = Bundle.main.decode([AthletesModel].self, from: "Athletes.json")
        resultsModel = Bundle.main.decode(ResultsModel.self, from: "results.json")
        tableViewList.tableFooterView = UIView()
    }

}

extension LoginViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return resultsModel?.results?.count ?? 0
        
       
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return resultsModel?.results?[section].issues?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = self.tableViewList.dequeueReusableCell(withIdentifier: "CountryListTableViewCell") as! CountryListTableViewCell
//        if let name = resultsModel?.results?[indexPath.section].issues?[indexPath.row].name {
//            cell.titleLabel.text = name
//        }
//        cell.selectionStyle = .none
//        cell.accessoryType = .disclosureIndicator
//        return cell
        
        var cell = tableView.dequeueReusableCell(withIdentifier: "CountryListTableViewCell")
        cell = UITableViewCell(style: .value2,
                               reuseIdentifier: "CountryListTableViewCell")
        cell?.textLabel?.text = "nschool"
        cell?.detailTextLabel?.text = "coimbatore"
        cell?.imageView?.image = UIImage(named: "itunes")
        cell?.accessoryType = .disclosureIndicator
        cell?.selectionStyle = .none
        return cell ?? UITableViewCell()
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if let title = resultsModel?.results?[section].title {
            return title
        }
        return ""
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(countryList[indexPath.row])
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
