//
//  APIService.swift
//  Network
//
//  Created by Periyasamy R on 16/10/20.
//  Copyright © 2020 Periyasamy R. All rights reserved.
//

import Foundation
class APIService: NSObject, APIServiceProtocol{
    public func loadMockData<Model: Decodable>(fileName: String, modelType: Model.Type, completion: APIParsedResponse) {
        if let path = Bundle.main.path(forResource: fileName, ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                let model = try data.decodeToModel(modelType: modelType)
                completion(ResponseCode.success, model, nil)
            } catch let JSONDecodeError {
                print(JSONDecodeError)
                completion(ResponseCode.serviceError, nil, nil)
            }
        }
    }
    func connectNetwork<Model: Decodable>(modelType: Model.Type, withBaseURl baseURL: String, withParameters parameters: String, withHttpMethod httpMethod: String, withContentType contentType: String, completion: @escaping APIParsedResponse) {
        
        var requestURL: URL?
        var session = URLSession.shared
        var urlRequest: URLRequest?
        
        let urlConfiguration = URLSessionConfiguration.default
        urlConfiguration.timeoutIntervalForRequest = TimeInterval(Constants.Common.REQUEST_TIMEOUT)
        urlConfiguration.timeoutIntervalForResource = TimeInterval(Constants.Common.REQUEST_TIMEOUT)
        session = URLSession(configuration: urlConfiguration, delegate: nil, delegateQueue: nil)
        
        // Check the http method and pass the url and Parameters
        if httpMethod == Constants.Common.KEY_GET {
            let urlString = baseURL + parameters
            let encodedURLString = urlString.encodeURL()
            requestURL = URL(string: encodedURLString)
            urlRequest = URLRequest(url: requestURL!)
        } else if httpMethod == Constants.Common.KEY_POST {
            
            requestURL = URL(string: baseURL)
            urlRequest = URLRequest(url: requestURL!)
            if contentType == Constants.Common.CONTENTTYPE_URL_ENCODE {
                urlRequest?.httpBody = parameters.data(using: .utf8)
            } else if contentType == Constants.Common.CONTENTTYPE_JSON {
                do {
                    let dictObject = CommonFunction().convertToDictionary(parameters: parameters)
                    urlRequest?.httpBody = try JSONSerialization.data(withJSONObject: dictObject ?? "Empty Object", options: .prettyPrinted)
                } catch let error {
                    print(error.localizedDescription)
                }
            }
        } else if httpMethod ==  Constants.Common.KEY_PUT {
            requestURL = URL(string: baseURL)
            urlRequest = URLRequest(url: requestURL!)
            if contentType == Constants.Common.CONTENTTYPE_URL_ENCODE {
                urlRequest?.httpBody = parameters.data(using: .utf8)
            } else if contentType == Constants.Common.CONTENTTYPE_JSON {
                do {
                    let dictObject = CommonFunction().convertToDictionary(parameters: parameters)
                    urlRequest?.httpBody = try JSONSerialization.data(withJSONObject: dictObject ?? "Empty Object", options: .prettyPrinted)
                } catch let error {
                    print(error.localizedDescription)
                }
            }
        } else if httpMethod == Constants.Common.KEY_DELETE {
            let urlString = baseURL + parameters
            let encodedURLString = urlString.encodeURL()
            requestURL = URL(string: encodedURLString)
            urlRequest = URLRequest(url: requestURL!)
        }
        urlRequest?.setValue(contentType, forHTTPHeaderField: "Content-Type")
        urlRequest?.httpMethod = httpMethod
        session.dataTask(with: urlRequest!, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
            let realResponse = response as? HTTPURLResponse
            print(realResponse?.statusCode as Any)
            guard let data = data, error == nil else {
                completion(ResponseCode.serviceError, nil, nil)
                return
            }
            if let statusCode = realResponse?.statusCode, statusCode == 200 {
                do {
                    let model = try data.decodeToModel(modelType: modelType)
                    completion(ResponseCode.success, model, nil)
                    
                } catch let JSONDecodeError {
                    print(JSONDecodeError.localizedDescription)
                    completion(ResponseCode.serviceError, nil, nil)
                    return
                }
            } else {
                completion(ResponseCode.serviceError, nil, nil)
            }
            
        }).resume()
    }
}

extension String {
    func encodeURL() -> String {
        return self.addingPercentEncoding(withAllowedCharacters: NSCharacterSet.urlQueryAllowed)!
    }
}
