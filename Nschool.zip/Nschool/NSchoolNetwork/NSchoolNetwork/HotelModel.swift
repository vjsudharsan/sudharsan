//
//  HotelModel.swift
//  HotelList
//
//  Created by nschool on 05/11/20.
//https://api.citygridmedia.com/content/places/v2/search/where?what=hotels&where=boston,ma&page=1&rpp=5&sort=alpha&publisher=test&format=json



import Foundation
//struct  HotelModel: Decodable {
//    var results: ResultModel?
//
//}
//struct  ResultModel: Decodable {
//    var uri: String?
//    var first_hit: Int?
//    var last_hit: Int?
//    var total_hits: Int?
//    var page: Int?
//    var rpp: Int?
//    var regions: [RegionList]?
//    var geo_ids: [Int]?
//    var tag_ids: [Int]?
//    var locations: [LocationList]?
//    var call_id: String?
//}
//
//struct RegionList: Decodable {
//    var type: String?
//    var name: String?
//    var latitude: Int?
//    var longitude: Int?
//    var default_radius: Int?
//}
//
//struct LocationList: Decodable {
//    var id: Int?
//    var featured: String?
//    var name: String?
//    var address: AddressList?
//
//}
//
//struct AddressList: Decodable {
//
//}
struct HotelModel : Codable {
    let results : Results?

    enum CodingKeys: String, CodingKey {

        case results = "results"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        results = try values.decodeIfPresent(Results.self, forKey: .results)
    }

}
struct Results : Codable {
    let uri : String?
    let first_hit : Int?
    let last_hit : Int?
    let total_hits : Int?
    let page : Int?
    let rpp : Int?
    let regions : [Regions]?
    let geo_ids : [Int]?
    let tag_ids : [Int]?
    let locations : [Locations]?
    let call_id : String?

    enum CodingKeys: String, CodingKey {

        case uri = "uri"
        case first_hit = "first_hit"
        case last_hit = "last_hit"
        case total_hits = "total_hits"
        case page = "page"
        case rpp = "rpp"
        case regions = "regions"
        case geo_ids = "geo_ids"
        case tag_ids = "tag_ids"
        case locations = "locations"
        case call_id = "call_id"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        uri = try values.decodeIfPresent(String.self, forKey: .uri)
        first_hit = try values.decodeIfPresent(Int.self, forKey: .first_hit)
        last_hit = try values.decodeIfPresent(Int.self, forKey: .last_hit)
        total_hits = try values.decodeIfPresent(Int.self, forKey: .total_hits)
        page = try values.decodeIfPresent(Int.self, forKey: .page)
        rpp = try values.decodeIfPresent(Int.self, forKey: .rpp)
        regions = try values.decodeIfPresent([Regions].self, forKey: .regions)
        geo_ids = try values.decodeIfPresent([Int].self, forKey: .geo_ids)
        tag_ids = try values.decodeIfPresent([Int].self, forKey: .tag_ids)
        locations = try values.decodeIfPresent([Locations].self, forKey: .locations)
        call_id = try values.decodeIfPresent(String.self, forKey: .call_id)
    }

}
struct Locations : Codable {
    let id : Int?
    let featured : Bool?
    let name : String?
    let address : Address?
    let neighborhood : String?
    let latitude : Double?
    let longitude : Double?
    let phone_number : String?
    let rating : Double?
    let profile : String?
    let has_video : Bool?
    let has_offers : Bool?
    let user_review_count : Int?
    let sample_categories : String?
    let impression_id : String?
    let tags : [Tags]?
    let public_id : String?
    let business_operation_status : Int?
    let scorecard : String?
    let votes : Int?
    let awards : [String]?
    let has_menu : Bool?
    let politanName : String?

    enum CodingKeys: String, CodingKey {

        case id = "id"
        case featured = "featured"
        case name = "name"
        case address = "address"
        case neighborhood = "neighborhood"
        case latitude = "latitude"
        case longitude = "longitude"
        case phone_number = "phone_number"
        case rating = "rating"
        case profile = "profile"
        case has_video = "has_video"
        case has_offers = "has_offers"
        case user_review_count = "user_review_count"
        case sample_categories = "sample_categories"
        case impression_id = "impression_id"
        case tags = "tags"
        case public_id = "public_id"
        case business_operation_status = "business_operation_status"
        case scorecard = "scorecard"
        case votes = "votes"
        case awards = "awards"
        case has_menu = "has_menu"
        case politanName = "politanName"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        featured = try values.decodeIfPresent(Bool.self, forKey: .featured)
        name = try values.decodeIfPresent(String.self, forKey: .name)
        address = try values.decodeIfPresent(Address.self, forKey: .address)
        neighborhood = try values.decodeIfPresent(String.self, forKey: .neighborhood)
        latitude = try values.decodeIfPresent(Double.self, forKey: .latitude)
        longitude = try values.decodeIfPresent(Double.self, forKey: .longitude)
        phone_number = try values.decodeIfPresent(String.self, forKey: .phone_number)
        rating = try values.decodeIfPresent(Double.self, forKey: .rating)
        profile = try values.decodeIfPresent(String.self, forKey: .profile)
        has_video = try values.decodeIfPresent(Bool.self, forKey: .has_video)
        has_offers = try values.decodeIfPresent(Bool.self, forKey: .has_offers)
        user_review_count = try values.decodeIfPresent(Int.self, forKey: .user_review_count)
        sample_categories = try values.decodeIfPresent(String.self, forKey: .sample_categories)
        impression_id = try values.decodeIfPresent(String.self, forKey: .impression_id)
        tags = try values.decodeIfPresent([Tags].self, forKey: .tags)
        public_id = try values.decodeIfPresent(String.self, forKey: .public_id)
        business_operation_status = try values.decodeIfPresent(Int.self, forKey: .business_operation_status)
        scorecard = try values.decodeIfPresent(String.self, forKey: .scorecard)
        votes = try values.decodeIfPresent(Int.self, forKey: .votes)
        awards = try values.decodeIfPresent([String].self, forKey: .awards)
        has_menu = try values.decodeIfPresent(Bool.self, forKey: .has_menu)
        politanName = try values.decodeIfPresent(String.self, forKey: .politanName)
    }

}
struct Tags : Codable {
    let id : Int?
    let name : String?
    let primary : Bool?

    enum CodingKeys: String, CodingKey {

        case id = "id"
        case name = "name"
        case primary = "primary"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        name = try values.decodeIfPresent(String.self, forKey: .name)
        primary = try values.decodeIfPresent(Bool.self, forKey: .primary)
    }

}
struct Address : Codable {
    let street : String?
    let city : String?
    let state : String?
    let postal_code : String?

    enum CodingKeys: String, CodingKey {

        case street = "street"
        case city = "city"
        case state = "state"
        case postal_code = "postal_code"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        street = try values.decodeIfPresent(String.self, forKey: .street)
        city = try values.decodeIfPresent(String.self, forKey: .city)
        state = try values.decodeIfPresent(String.self, forKey: .state)
        postal_code = try values.decodeIfPresent(String.self, forKey: .postal_code)
    }

}
struct Regions : Codable {
    let type : String?
    let name : String?
    let latitude : Double?
    let longitude : Double?
    let default_radius : Double?

    enum CodingKeys: String, CodingKey {

        case type = "type"
        case name = "name"
        case latitude = "latitude"
        case longitude = "longitude"
        case default_radius = "default_radius"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        type = try values.decodeIfPresent(String.self, forKey: .type)
        name = try values.decodeIfPresent(String.self, forKey: .name)
        latitude = try values.decodeIfPresent(Double.self, forKey: .latitude)
        longitude = try values.decodeIfPresent(Double.self, forKey: .longitude)
        default_radius = try values.decodeIfPresent(Double.self, forKey: .default_radius)
    }

}
