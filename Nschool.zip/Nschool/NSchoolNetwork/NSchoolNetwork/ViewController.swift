//
//  ViewController.swift
//  NSchoolNetwork
//
//  Created by nschool on 17/10/20.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

