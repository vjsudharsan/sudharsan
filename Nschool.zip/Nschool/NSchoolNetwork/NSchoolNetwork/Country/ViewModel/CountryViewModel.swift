//
//  CountryViewModel.swift
//  Network
//
//  Created by Periyasamy R on 16/10/20.
//  Copyright © 2020 Periyasamy R. All rights reserved.
//

import Foundation
class CountryViewModel {
    
    let apiService: APIServiceCallProtocol
    var showAlertClosure: (() -> ())?
    var updateLoadingStatus: (() -> ())?
    var reloadClosure: (() -> ())?
    var countryModel: CountryModel? {
        didSet {
            self.reloadClosure?()
        }
    }
    var loginTokenModel: LoginTokenModel? {
        didSet {
            self.reloadClosure?()
        }
    }
    
    var registerTokenModel: RegisterTokenModel? {
        didSet {
            self.reloadClosure?()
        }
    }
    
    var employeesModel: EmployeesModel? {
        didSet {
            self.reloadClosure?()
        }
    }
    var alertMessage: ServiceError? {
        didSet {
            self.showAlertClosure?()
        }
    }
    var isLoading: Bool = false {
        didSet {
            self.updateLoadingStatus?()
        }
    }
    init(apiService: APIServiceCallProtocol = Network()) {
        self.apiService = apiService
    }
    
    var pageTitle: String {
        return Constants.Common.kCountryTitle
    }
    
    func getCountryList() {
        self.isLoading = true
        apiService.getCountryList() { [weak self] (success, response, error) in
            guard let self = self else { return }
            self.isLoading = false
            if success == ResponseCode.success {
                guard let response = response else {
                    self.alertMessage = error
                    return
                }
                self.countryModel = response as? CountryModel
                
            } else {
                self.alertMessage = error
            }
        }
    }
    func getEmployeeList() {
        self.isLoading = true
        apiService.getEmployeeListWithService() { [weak self] (success, response, error) in
            guard let self = self else { return }
            self.isLoading = false
            if success == ResponseCode.success {
                guard let response = response else {
                    self.alertMessage = error
                    return
                }
                self.employeesModel = response as? EmployeesModel
                
            } else {
                self.alertMessage = error
            }
        }
    }
    func loginPostAPICall() {
        self.isLoading = true
        apiService.loginPostMethodAPICall() { [weak self] (success, response, error) in
            guard let self = self else { return }
            self.isLoading = false
            if success == ResponseCode.success {
                guard let response = response else {
                    self.alertMessage = error
                    return
                }
                self.loginTokenModel = response as? LoginTokenModel
                
            } else {
                self.alertMessage = error
            }
        }
    }
    func registerPostAPICall() {
        self.isLoading = true
        apiService.registerPostMethodAPICall() { [weak self] (success, response, error) in
            guard let self = self else { return }
            self.isLoading = false
            if success == ResponseCode.success {
                guard let response = response else {
                    self.alertMessage = error
                    return
                }
                self.registerTokenModel = response as? RegisterTokenModel
                
            } else {
                self.alertMessage = error
            }
        }
    }
    
    /// TableView Data
    var numberOfSection: Int {
        return 1
    }
    var numberOfRowsInSection: Int {
        return self.employeesModel?.data?.count ?? 0
    }
    func getCellForRowAt(indexPath: IndexPath) -> String {
        if let employee_name = self.employeesModel?.data?[indexPath.row].employee_name {
            return employee_name
        }
        return Constants.Common.kEmptyString
    }
}
