//
//  TokenModel.swift
//  NSchoolNetwork
//
//  Created by nschool on 21/10/20.
//

import Foundation

struct LoginTokenModel: Decodable {
    var token: String?
}

struct RegisterTokenModel: Decodable {
    var token: String?
    var id: Int?
}


struct NewJsonModel: Decodable {
    var kind: String?
    var etag: String?
    var nextPageToken: String?
    var regionCode: String?
    var pageInfo: pageDetails?
    var items: [itemList]?
}
struct pageDetails: Decodable  {
    var totalResults: Int?
    var resultsPerPage: Int?
}

struct itemList: Decodable {
    var kind: String?
    var etag: String?
    var id: idItems?
    
}
struct idItems: Decodable {
    var kind: String?
    var videoId: String?
}
g
