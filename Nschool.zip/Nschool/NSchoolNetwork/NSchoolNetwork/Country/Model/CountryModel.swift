//
//  CountryModel.swift
//  Network
//
//  Created by Periyasamy R on 16/10/20.
//  Copyright © 2020 Periyasamy R. All rights reserved.
//

import Foundation

struct CountryModel: Decodable {
    var CountryLists: [CountryLists]?
}

struct CountryLists: Decodable {
    var name: String?
    var capital: String?
    var region: String?
    var subregion: String?
    var code2: String?
    var code3: String?
    var states: [StatesLists]?
}

struct StatesLists: Decodable {
    var name: String?
    var code: String?
}
