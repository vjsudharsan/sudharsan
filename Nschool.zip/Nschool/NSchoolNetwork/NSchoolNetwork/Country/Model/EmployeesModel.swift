//
//  EmployeesModel.swift
//  Network
//
//  Created by Periyasamy R on 16/10/20.
//  Copyright © 2020 Periyasamy R. All rights reserved.
//

import Foundation

struct EmployeesModel: Decodable {
    var status: String?
    var data: [EmployeesLists]?
}

struct EmployeesLists: Decodable {
    var id: String?
    var employee_name: String?
    var employee_salary: String?
    var employee_age: String?
    var profile_image: String?
    
}
