//
//  CountryView.swift
//  Network
//
//  Created by Periyasamy R on 16/10/20.
//  Copyright © 2020 Periyasamy R. All rights reserved.
//

import UIKit

class CountryView: UIViewController {

    var countryViewModel = CountryViewModel()
    @IBOutlet weak var tableViewCountryList: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.title = countryViewModel.pageTitle
        self.initViewModel()
        tableViewCountryList.tableFooterView = UIView()
    }
    
    func initViewModel() {
        
        countryViewModel.updateLoadingStatus = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                if self.countryViewModel.isLoading {
                    // Start Animating
                } else {
                    // Stop Animating
                }
            }
        }
        countryViewModel.showAlertClosure = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                if let errorMessage = self.countryViewModel.alertMessage {
                    print(errorMessage.localizedDescription)
                }
            }
        }
        countryViewModel.reloadClosure = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                // TableView ReloadData
                self.tableViewCountryList.reloadData()
            }
        }
        //self.countryViewModel.getCountryList()
        
        //self.countryViewModel.getEmployeeList()
        
        //self.countryViewModel.loginPostAPICall()
        
        self.countryViewModel.registerPostAPICall()
    }
}

extension CountryView: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return countryViewModel.numberOfSection
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return countryViewModel.numberOfRowsInSection
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableViewCountryList.dequeueReusableCell(withIdentifier: Constants.TableViewCellIdentifier.kCountryTableViewCell) as! CountryTableViewCell
        cell.nameLabel.text = self.countryViewModel.getCellForRowAt(indexPath: indexPath)
        cell.accessoryType = .disclosureIndicator
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
