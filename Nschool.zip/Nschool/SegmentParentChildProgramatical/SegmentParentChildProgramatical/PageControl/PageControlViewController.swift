//
//  PageControlViewController.swift
//  SegmentParentChildProgramatical
//
//  Created by nschool on 24/12/20.
//

import UIKit

class PageControlViewController: UIViewController, UIScrollViewDelegate {
 let scrollView = UIScrollView()
    var imageItems = ["1","2","3","4"]
    var frame: CGRect = CGRect(x: 0, y: -250, width: 0, height: 0)
    var pageControl : UIPageControl = UIPageControl(frame: CGRect(x: -90, y: 700, width: 200, height: 50))

    override func viewDidLoad(){
        super.viewDidLoad()
     
        //self.view.backgroundColor = .red
        
        scrollView.frame = CGRect(x: self.view.frame.origin.x, y: self.view.frame.origin.y+100, width: self.view.frame.size.width, height: self.view.frame.height)
        scrollView.delegate = self
        scrollView.isPagingEnabled = true
        scrollView.bounces = false
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.showsVerticalScrollIndicator = false
        self.view.addSubview(scrollView)
        self.configurePageControl()

        for index in 0..<4 {
            
            frame.origin.x = self.scrollView.frame.size.width * CGFloat(index)
            frame.size = self.scrollView.frame.size
            
            let image = UIImageView(frame: frame)
            image.contentMode = .scaleAspectFit
            image.image = UIImage(named: imageItems[index])
            self.scrollView.addSubview(image)
        }
        self.scrollView.contentSize = CGSize(width:self.scrollView.frame.size.width * 4,height: self.scrollView.frame.size.height)
        pageControl.addTarget(self, action: #selector(self.changePage(sender:)), for: UIControl.Event.valueChanged)
        // Do any additional setup after loading the view.
    }
    
    func configurePageControl() {
        // The total number of pages that are available is based on how many available colors we have.
        self.pageControl.numberOfPages = imageItems.count
        self.pageControl.currentPage = 0
        self.pageControl.tintColor = UIColor.red
        self.pageControl.pageIndicatorTintColor = UIColor.black
        self.pageControl.currentPageIndicatorTintColor = UIColor.green
        self.view.addSubview(pageControl)
        
    }
    @objc func changePage(sender: AnyObject) -> () {
        let x = CGFloat(pageControl.currentPage) * scrollView.frame.size.width
        scrollView.setContentOffset(CGPoint(x:x, y:0), animated: true)
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
        let pageNumber = round(scrollView.contentOffset.x / scrollView.frame.size.width)
        pageControl.currentPage = Int(pageNumber)
    }

}
