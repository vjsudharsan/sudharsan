//
//  CollectionViewController.swift
//  SegmentControlDifferentScreen
//
//  Created by nschool on 22/12/20.
//

import UIKit

class CollectionViewController: UIViewController, UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    let imageView = UIImageView(frame: CGRect(x: 130, y: 200, width: 150, height: 150))
    
    
    let imagePicker = UIImagePickerController()
    override func viewDidLoad() {
        super.viewDidLoad()
        imageView.image = UIImage(named: "apple")
        self.view.addSubview(imageView)
        let tap = UITapGestureRecognizer(target: self, action: #selector(doubleTapped))
        tap.numberOfTapsRequired = 2
        view.addGestureRecognizer(tap)
    }
       
    @objc func doubleTapped() {
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
                    imagePicker.delegate = self
                    imagePicker.sourceType = .photoLibrary
                    imagePicker.allowsEditing = false
                    present(imagePicker, animated: true, completion: nil)
                }
        // do something here
    } // Do any additional setup after loading the view.
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        
        if let picture = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            imageView.image = picture
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}
