//
//  PageViewController.swift
//  SegmentParentChildProgramatical
//
//  Created by nschool on 24/12/20.
//

import UIKit
class PageViewController: UIViewController {
    
    var pageController: UIPageViewController!
    var controllers = [UIViewController]()

    override func viewDidLoad() {
        super.viewDidLoad()
        pageController = UIPageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
        pageController.dataSource = self
        pageController.delegate = self
        
        addChild(pageController)
        view.addSubview(pageController.view)
        
        NSLayoutConstraint.activate([pageController.view.leadingAnchor.constraint(equalTo: self.view.leadingAnchor), pageController.view.topAnchor.constraint(equalTo: self.view.topAnchor), pageController.view.trailingAnchor.constraint(equalTo: self.view.trailingAnchor), pageController.view.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)])
        
    let firstViewController = FirstViewController()
    firstViewController.view.backgroundColor = randomColor()
    controllers.append(firstViewController)
    
    let secondViewController = SecondViewController()
    secondViewController.view.backgroundColor = randomColor()
    controllers.append(secondViewController)
    
    let thirdViewController = ThirdViewController()
    thirdViewController.view.backgroundColor = randomColor()
    controllers.append(thirdViewController)

    pageController.setViewControllers([controllers[0]], direction: .forward, animated: false)
    }
    
}
func randomCGFloat() -> CGFloat {
    return CGFloat(arc4random()) / CGFloat(UInt32.max)
}

func randomColor() -> UIColor {
    return UIColor(red: randomCGFloat(), green: randomCGFloat(), blue: randomCGFloat(), alpha: 1)
}

extension PageViewController: UIPageViewControllerDataSource, UIPageViewControllerDelegate {
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        if let index = controllers.firstIndex(of: viewController){
            if index > 0 {
                return controllers[index - 1]
            } else {
                return nil
            }
        }
        return nil
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        if let index = controllers.firstIndex(of: viewController) {
            if index < controllers.count - 1 {
                return controllers[index + 1]
            }else {
                return nil
            }
        }
        return nil
    }
    
    
}
