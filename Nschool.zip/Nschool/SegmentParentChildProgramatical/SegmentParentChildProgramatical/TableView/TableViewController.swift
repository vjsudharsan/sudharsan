//
//  TableViewController.swift
//  SegmentParentChildProgramatical
//
//  Created by nschool on 23/12/20.
//

import UIKit

class TableViewController: UIViewController {

    lazy var tableView: UITableView = {
        let tableView = UITableView()
        //tableView.backgroundColor = .gray
        tableView.translatesAutoresizingMaskIntoConstraints = false
        return tableView
    }()
   var arrayItem = ["ABC","ZXC","VBBN","YHL","KGS","FHS"]
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.view.backgroundColor = .blue
        self.setUpTable()
        self.tableViewSetUp()
        // Do any additional setup after loading the view.
    }
    
    func setUpTable(){
        self.view.addSubview(tableView)
        NSLayoutConstraint.activate([tableView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor), tableView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor), tableView.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor), tableView.bottomAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.bottomAnchor)])
        
    }
    
    func tableViewSetUp() {
        tableView.estimatedRowHeight = 44
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(DetailsTableViewCell.self, forCellReuseIdentifier: "DetailsTableViewCell")
        tableView.separatorStyle = .singleLine
        tableView.isScrollEnabled = true
        tableView.tableFooterView = UIView()
        
    }

}

extension TableViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayItem.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "DetailsTableViewCell") as! DetailsTableViewCell
        cell.labelName.text = arrayItem[indexPath.row]
        cell.accessoryType = .disclosureIndicator
        return cell
    }

}
