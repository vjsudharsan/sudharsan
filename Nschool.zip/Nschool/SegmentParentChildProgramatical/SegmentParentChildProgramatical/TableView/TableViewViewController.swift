//
//  TableViewViewController.swift
//  SegmentControlDifferentScreen
//
//  Created by nschool on 22/12/20.
//

import UIKit

class TableViewViewController: UIViewController {
    lazy var tableView: UITableView = {
        let tableView = UITableView()
        //tableView.isScrollEnabled = true
        tableView.backgroundColor = .gray
        tableView.translatesAutoresizingMaskIntoConstraints = false
        return tableView
    }()
   var arrayItem = ["ABC","ZXC","VBBN","YHL","KGS","FHS"]
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .blue
        self.setUpTable()
        self.tableViewSetUp()
        // Do any additional setup after loading the view.
    }
    
    func setUpTable(){
        self.view.addSubview(tableView)
        NSLayoutConstraint.activate([tableView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor), tableView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor), tableView.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor), tableView.bottomAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.bottomAnchor)])
        
    }
    
    func tableViewSetUp() {
        tableView.estimatedRowHeight = 44
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(DataTableViewCell.self, forCellReuseIdentifier: "DataTableViewCell")
        tableView.separatorStyle = .singleLine
        tableView.tableFooterView = UIView()
        
    }

}

extension TableViewViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 6
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayItem.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "DataTableViewCell") as! DataTableViewCell
        cell.labelName.text = arrayItem[indexPath.row]
        return cell
    }


}
