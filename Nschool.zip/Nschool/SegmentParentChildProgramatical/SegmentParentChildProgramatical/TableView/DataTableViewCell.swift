//
//  DataTableViewCell.swift
//  SegmentControlDifferentScreen
//
//  Created by nschool on 22/12/20.
//

import UIKit

class DataTableViewCell: UITableViewCell {
    lazy var labelName: UILabel = {
        let nameLabel = UILabel()
        nameLabel.textAlignment = .left
        nameLabel.numberOfLines = .zero
        nameLabel.lineBreakMode = .byWordWrapping
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        return nameLabel
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .default, reuseIdentifier: reuseIdentifier)
        self.setUp()
    }
    
    func setUp() {
        self.contentView.addSubview(labelName)
        NSLayoutConstraint.activate([labelName.leadingAnchor.constraint(equalTo: self.contentView.leadingAnchor, constant: 15),labelName.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor, constant: -15), labelName.topAnchor.constraint(equalTo: self.contentView.topAnchor, constant: 15), labelName.bottomAnchor.constraint(equalTo: self.contentView.bottomAnchor, constant: -15)])
    
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    


}
