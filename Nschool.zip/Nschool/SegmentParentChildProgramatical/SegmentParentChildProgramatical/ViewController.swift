//
//  ViewController.swift
//  SegmentParentChildProgramatical
//
//  Created by nschool on 23/12/20.
//
import UIKit

class ViewController: UIViewController {
    lazy var segmentControl: UISegmentedControl = {
    let segmentControl = UISegmentedControl(items: ["Table","PageControl","Gesture","PageViewController"])
        segmentControl.translatesAutoresizingMaskIntoConstraints = false
        return segmentControl
    }()
    
    lazy var emptyView: UIView = {
       let emptyView = UIView()
        emptyView.translatesAutoresizingMaskIntoConstraints = false
        return emptyView
    }()
    

    let collectionView = CollectionViewController()
    let mapView = PageControlViewController()
    let tableView = TableViewController()
    let pageView = PageViewController()
    
   // var segment = [UIViewController]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.setUp()
        
    }
      func setUp() {
        self.view.addSubview(segmentControl)
        self.view.addSubview(emptyView)
        segmentControl.addTarget(self, action: #selector(segmentAction(_:)), for: .valueChanged)
        //segmentControl.frame = CGRect(x: 35, y: 100, width: 350, height: 50)
        addChild(tableView)
        addChild(mapView)
        addChild(collectionView)
        addChild(pageView)
        
        self.emptyView.addSubview(tableView.view)
        self.emptyView.addSubview(mapView.view)
        self.emptyView.addSubview(collectionView.view)
        self.emptyView.addSubview(pageView.view)
        
        tableView.didMove(toParent: tableView.self)
        mapView.didMove(toParent: mapView.self)
        collectionView.didMove(toParent: collectionView.self)
        pageView.didMove(toParent: pageView.self)
        
        tableView.view.isHidden = false
        mapView.view.isHidden = true
        collectionView.view.isHidden = true
        pageView.view.isHidden = true
        
        NSLayoutConstraint.activate([segmentControl.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15),segmentControl.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15), segmentControl.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 15)])
        
        NSLayoutConstraint.activate([emptyView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 0), emptyView.trailingAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.trailingAnchor, constant: -15), emptyView.topAnchor.constraint(equalTo: self.segmentControl.bottomAnchor, constant: 15), emptyView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -15)])
    }

    @objc func segmentAction(_ sender: UISegmentedControl) {
        tableView.view.isHidden = true
        mapView.view.isHidden = true
        collectionView.view.isHidden = true
        pageView.view.isHidden = true
        if segmentControl.selectedSegmentIndex == 0 {
            tableView.view.isHidden = false
        } else if segmentControl.selectedSegmentIndex == 1 {
            mapView.view.isHidden = false
        } else if segmentControl.selectedSegmentIndex == 2 {
            collectionView.view.isHidden = false
        } else if segmentControl.selectedSegmentIndex == 3 {
            pageView.view.isHidden = false
        }
    }
}

