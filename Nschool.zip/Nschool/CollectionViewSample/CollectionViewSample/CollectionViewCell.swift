//
//  CollectionViewCell.swift
//  CollectionViewSample
//
//  Created by nschool on 24/12/20.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var labelName: UILabel!
    
}
