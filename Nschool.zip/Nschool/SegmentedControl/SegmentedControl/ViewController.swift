//
//  ViewController.swift
//  SegmentedControl
//
//  Created by nschool on 15/10/20.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func segmentedControlAction(_ sender: UISegmentedControl) {
        switch self.segmentedControl?.selectedSegmentIndex {
        case 0:
            print("First")
        case 1:
            print("Second")
        default:
            break
        }
    }
    
}

