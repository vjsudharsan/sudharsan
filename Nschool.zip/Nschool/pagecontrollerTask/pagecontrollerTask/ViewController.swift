//
//  ViewController.swift
//  pagecontrollerTask
//
//  Created by nschool on 23/12/20.
//

import UIKit

class ViewController: UIViewController {
    
    
    var pageController: UIPageViewController!
    var controller = [UIViewController]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        pageController = UIPageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
        pageController.dataSource = self
        pageController.delegate = self
        
        
        addChild(pageController)
        view.addSubview(pageController.view)
        
        NSLayoutConstraint.activate([pageController.view.leadingAnchor.constraint(equalTo: self.view.leadingAnchor),pageController.view.topAnchor.constraint(equalTo: self.view.topAnchor),pageController.view.trailingAnchor.constraint(equalTo:   self.view.trailingAnchor),pageController.view.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)])
        
    }


}

