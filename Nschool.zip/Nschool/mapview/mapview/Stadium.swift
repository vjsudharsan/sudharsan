//
//  Stadium.swift
//  mapview
//
//  Created by nschool on 08/12/20.
//

import Foundation
import MapKit

struct Stadium {
    var name: String
    var lattitude: CLLocationDegrees
    var longtitude: CLLocationDegrees
}

struct countryList {
    var countryName: String?
    var countryLogo: String?
}
