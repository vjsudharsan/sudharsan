//
//  ViewController.swift
//  SampleScreen
//
//  Created by nschool on 26/10/20.
//

import UIKit

class ViewController: UIViewController {

    lazy var logoimage: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(named: "greenmail")
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.backgroundColor = .black
        return imageView
    }()
    
    lazy var labelSignin: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Sign In"
        label.numberOfLines = .zero
        label.textAlignment = .center
        //      label.backgroundColor = .gray
        label.textColor = .white
        label.lineBreakMode = .byWordWrapping
        label.font = UIFont.systemFont(ofSize: 30)
        return label
    }()
    
    lazy var labelSubTitle: UILabel = {
        let subLabel = UILabel()
        subLabel.translatesAutoresizingMaskIntoConstraints = false
        subLabel.text = "Speak, Freind and Enter"
        subLabel.numberOfLines = .zero
        subLabel.textAlignment = .center
        //      subLabel.backgroundColor = .gray
        subLabel.textColor = .black
        subLabel.lineBreakMode = .byWordWrapping
        subLabel.font = UIFont.systemFont(ofSize: 18)
        return subLabel
    }()
    
    lazy var textFieldStackview: UIStackView = {
        let stackview = UIStackView(arrangedSubviews: [emailTextField, passwordTextField])
        stackview.translatesAutoresizingMaskIntoConstraints = false
        stackview.isLayoutMarginsRelativeArrangement = true
        stackview.layoutMargins = UIEdgeInsets(top: 15, left: 15, bottom: 15, right: 15)
        stackview.axis = .vertical
        stackview.alignment = .fill
        stackview.distribution = .fillEqually
        stackview.spacing = 15
        stackview.backgroundColor = .gray
        return stackview
    }()
    
    lazy var emailTextField:UITextField = {
        let textField = UITextField()
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.placeholder = "Email"
        textField.textAlignment = .center
        textField.keyboardType = UIKeyboardType.emailAddress
        textField.returnKeyType = UIReturnKeyType.default
        textField.autocorrectionType = UITextAutocorrectionType.no
        textField.font = UIFont.systemFont(ofSize: 13)
        textField.borderStyle = UITextField.BorderStyle.roundedRect
        textField.clearButtonMode = UITextField.ViewMode.whileEditing;
        textField.contentVerticalAlignment = UIControl.ContentVerticalAlignment.center
        textField.backgroundColor = .white
        return textField
    }()
    
    lazy var passwordTextField:UITextField = {
        let textField = UITextField()
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.placeholder = "Password"
        textField.textAlignment = .center
        textField.keyboardType = UIKeyboardType.default
        textField.returnKeyType = UIReturnKeyType.done
        textField.autocorrectionType = UITextAutocorrectionType.no
        textField.font = UIFont.systemFont(ofSize: 13)
        textField.borderStyle = UITextField.BorderStyle.roundedRect
        textField.clearButtonMode = UITextField.ViewMode.whileEditing;
        textField.contentVerticalAlignment = UIControl.ContentVerticalAlignment.center
        textField.backgroundColor = .white
        textField.isSecureTextEntry = true
        return textField
    }()
    
    lazy var buttonSignIn: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("SIGN IN", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .black
        button.layer.cornerRadius = 5.0
        button.layer.borderWidth = 1.0
        button.layer.borderColor = UIColor.blue.cgColor
        button.addTarget(self, action: #selector(self.buttonAction), for: .touchUpInside)
       // button.addTarget(self, action: #selector(self.buttonAction), for: .touchUpInside)
        return button
    }()
    
    lazy var infoImage: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(named: "Infoboxlogo")
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .cyan
        
        // Do any additional setup after loading the view, typically from a nib.
        
       // buttonSignIn.addTarget(self, action: #selector(self.buttonAction), for: .touchUpInside)
        self.setUpView()
    }
    
    func setUpView() {
        self.view.addSubview(logoimage)
//        self.view.addSubview(labelSignin)
//        self.view.addSubview(labelSubTitle)
//        self.view.addSubview(textFieldStackview)
//        //self.view.addSubview(emailTextField)
//        //self.view.addSubview(passwordTextField)
//        self.view.addSubview(buttonSignIn)
//        self.view.addSubview(infoImage)
        
        
        let centerXConstraint = logoimage.centerXAnchor.constraint(equalTo: self.view.centerXAnchor)
       let topConstraint = logoimage.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 50)
        let heightConstraint = logoimage.heightAnchor.constraint(equalToConstant: 150)
        let widthConstraint = logoimage.widthAnchor.constraint(equalToConstant:150)
        NSLayoutConstraint.activate([topConstraint,centerXConstraint, heightConstraint, widthConstraint])
        
//        let signInLabelleadingConstraint = labelSignin.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15)
//        let signInTrailingConstraint = labelSignin.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15)
//        let signInTopConstraint = labelSignin.topAnchor.constraint(equalTo: logoimage.bottomAnchor, constant: 15)
//        let signInHeightConstraint = labelSignin.heightAnchor.constraint(greaterThanOrEqualToConstant: 40)
//        NSLayoutConstraint.activate([signInLabelleadingConstraint, signInTrailingConstraint, signInTopConstraint, signInHeightConstraint])
//
//        let subTitleLeadingConstraint = labelSubTitle.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15)
//        let subTitleTrailingConstraint = labelSubTitle.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15)
//        let subTitleTopConstraint = labelSubTitle.topAnchor.constraint(equalTo: labelSignin.bottomAnchor, constant: 2)
//        let subTitleHeightConstraint = labelSubTitle.heightAnchor.constraint(greaterThanOrEqualToConstant: 20)
//        NSLayoutConstraint.activate([subTitleLeadingConstraint, subTitleTrailingConstraint, subTitleTopConstraint, subTitleHeightConstraint])
//
//        NSLayoutConstraint.activate([textFieldStackview.leadingAnchor.constraint(equalTo:
//                self.view.leadingAnchor, constant: 15), textFieldStackview.trailingAnchor.constraint(equalTo:
//                  self.view.trailingAnchor, constant: -15), textFieldStackview.topAnchor.constraint(equalTo: labelSubTitle.bottomAnchor, constant: 15), textFieldStackview.heightAnchor.constraint(greaterThanOrEqualToConstant: 44)])
        
//        let emailTextFieldLeadingConstraint = emailTextField.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15)
//        let emailTextFieldTrailingConstraint = emailTextField.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15)
//        let emailTextFieldTopConstraint = emailTextField.topAnchor.constraint(equalTo: labelSubTitle.bottomAnchor, constant: 15)
//        let emailTextFieldHeightConstraint = emailTextField.heightAnchor.constraint(greaterThanOrEqualToConstant: 40)
//        NSLayoutConstraint.activate([emailTextFieldLeadingConstraint, emailTextFieldTrailingConstraint, emailTextFieldTopConstraint, emailTextFieldHeightConstraint])
//
//        let passwordTextFieldLeadingConstraint = passwordTextField.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15)
//        let passwordTextFieldTrailingConstraint = passwordTextField.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15)
//        let passwordTextFieldTopConstraint = passwordTextField.topAnchor.constraint(equalTo: emailTextField.bottomAnchor, constant: 15)
//        let passwordTextFieldHeightConstraint = passwordTextField.heightAnchor.constraint(greaterThanOrEqualToConstant: 40)
//        NSLayoutConstraint.activate([passwordTextFieldLeadingConstraint, passwordTextFieldTrailingConstraint, passwordTextFieldTopConstraint, passwordTextFieldHeightConstraint])
        
//        let buttonLeadingConstraint = buttonSignIn.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15)
//        let buttonTrailingConstraint = buttonSignIn.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15)
//        let buttonTopConstraint = buttonSignIn.topAnchor.constraint(equalTo: passwordTextField.bottomAnchor, constant: 80)
//        let buttonHeightConstraint = buttonSignIn.heightAnchor.constraint(greaterThanOrEqualToConstant: 40)
//        NSLayoutConstraint.activate([buttonLeadingConstraint, buttonTrailingConstraint, buttonTopConstraint, buttonHeightConstraint])
//
//        //let imageLeadingConstraint = image.leadingAnchor.constraint(equalTo: emailTextField.leadingAnchor, constant: 150)
//        let imageTrailingConstraint = infoImage.trailingAnchor.constraint(equalTo: emailTextField.trailingAnchor, constant: -15)
//        let imageTopConstraint = infoImage.topAnchor.constraint(equalTo: emailTextField.topAnchor, constant: 5)
//        let imageHeightConstraint = infoImage.heightAnchor.constraint(equalToConstant: 25)
//        let imageWidthConstraint = infoImage.widthAnchor.constraint(equalToConstant:30)
//        NSLayoutConstraint.activate([imageTrailingConstraint, imageTopConstraint, imageHeightConstraint, imageWidthConstraint])
    }
   @objc func buttonAction (_ sender: UIButton) {
//        self.navigationController?.pushViewController(vc, animated: true)
        print("Done")
    }
}



