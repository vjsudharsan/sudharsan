//
//  ViewController.swift
//  TextFieldApp
//
//  Created by nschool on 28/10/20.
//

import UIKit

class ViewController: UIViewController {
    
    lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.backgroundColor = .gray
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.isUserInteractionEnabled = true
        scrollView.showsVerticalScrollIndicator = false
        scrollView.showsHorizontalScrollIndicator = false
        return scrollView
    }()
    
    lazy var mainStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.alignment = .fill
        stackView.distribution = .fill
        stackView.spacing = 15
        stackView.axis = .vertical
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.isLayoutMarginsRelativeArrangement = true
        stackView.layoutMargins = UIEdgeInsets(top: .zero, left: .zero, bottom: .zero, right: .zero)
        return stackView
    }()
    
    lazy var stackView: UIStackView = {
        let stackView = UIStackView(arrangedSubviews: [labelTitle, labelSubTitle, labelText])
        stackView.alignment = .fill
        stackView.distribution = .fill
        stackView.spacing = 15
        stackView.axis = .vertical
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.isLayoutMarginsRelativeArrangement = true
        stackView.layoutMargins = UIEdgeInsets(top: 15, left: 15, bottom: 15, right: 15)
        return stackView
    }()
    
    lazy var buttonStackView: UIStackView = {
        let stackView = UIStackView(arrangedSubviews: [buttonApply, buttonSubmit, buttonCancel])
        stackView.alignment = .fill
        stackView.distribution = .fillEqually
        stackView.spacing = 15
        stackView.axis = .vertical
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.isLayoutMarginsRelativeArrangement = true
        stackView.layoutMargins = UIEdgeInsets(top: 15, left: 15, bottom: 15, right: 15)
        return stackView
    }()
    
    lazy var buttonSubmit: UIButton = {
        let button = UIButton()
        button.setTitle("Submit", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .blue
        button.layer.cornerRadius = 10
        button.layer.borderWidth = 1.0
        button.layer.borderColor = UIColor.white.cgColor
        button.addTarget(self, action: #selector(applybuttonAction(_:)), for: .touchUpInside)
        return button
    }()
    
    lazy var buttonApply: UIButton = {
        let button = UIButton()
        button.setTitle("Apply", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .purple
        button.layer.cornerRadius = 10
        button.layer.borderWidth = 1.0
        button.layer.borderColor = UIColor.white.cgColor
        return button
    }()
    
    lazy var buttonCancel: UIButton = {
        let button = UIButton()
        button.setTitle("Cancel", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .red
        button.layer.borderWidth = 1.0
        button.layer.cornerRadius = 10
        button.layer.borderColor = UIColor.white.cgColor
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(buttonAction(_:)), for: .touchUpInside)
        return button
    }()
    
    lazy var labelTitle: UILabel = {
        let label = UILabel()
        label.text = "Do any additional setup after loading the view. Do any additional setup after loading the view. Do any additional setup after loading the view. Do any additional setup after loading the view."
        label.textColor = .white
        label.textAlignment = .left
        label.lineBreakMode = .byWordWrapping
        label.font = UIFont.preferredFont(forTextStyle: .body)
        label.backgroundColor = .gray
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = .zero
        label.alpha = 1
        return label
    }()

    lazy var labelSubTitle: UILabel = {
        let label = UILabel()
        label.text = "Do any additional setup after loading the view. translatesAutoresizingMaskIntoConstraints translatesAutoresizingMaskIntoConstraints translatesAutoresizingMaskIntoConstraints"
        label.textColor = .white
        label.textAlignment = .left
        label.lineBreakMode = .byWordWrapping
        label.font = UIFont.preferredFont(forTextStyle: .subheadline)
        label.backgroundColor = .blue
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = .zero
        return label
    }()

    lazy var labelText: UILabel = {
        let label = UILabel()
        label.text = "Do any additional setup after loading the view. Do any additional setup after loading the view. Do any additional setup after loading the view. Do any additional setup after loading the view. Do any additional setup after loading the view.Do any additional setup after loading the view.Do any additional setup after loading the view. Do any additional setup after loading the view. Do any additional setup after loading the view."
        label.textColor = .black
        label.textAlignment = .left
        label.lineBreakMode = .byWordWrapping
        label.font = UIFont.preferredFont(forTextStyle: .subheadline)
        label.backgroundColor = .yellow
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = .zero
        return label
    }()
//
//    lazy var labelText2: UILabel = {
//        let label = UILabel()
//        label.text = "Use this method to select a configuration to create the new scene with."
//        label.textColor = .black
//        label.textAlignment = .center
//        label.lineBreakMode = .byWordWrapping
//        label.font = UIFont.preferredFont(forTextStyle: .subheadline)
//        label.backgroundColor = .orange
//        label.translatesAutoresizingMaskIntoConstraints = false
//        label.numberOfLines = .zero
//        return label
//    }()
//
//    lazy var labelText3: UILabel = {
//        let label = UILabel()
//        label.text = "If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions."
//        label.textColor = .black
//        label.textAlignment = .center
//        label.lineBreakMode = .byWordWrapping
//        label.font = UIFont.preferredFont(forTextStyle: .subheadline)
//        label.backgroundColor = .green
//        label.translatesAutoresizingMaskIntoConstraints = false
//        label.numberOfLines = .zero
//        return label
//    }()
    
//    lazy var backgroundView: UIView = {
//        let view = UIView()
//        view.backgroundColor = .purple
//        view.translatesAutoresizingMaskIntoConstraints = false
//        return view
//    }()
//
//    lazy var topView: UIView = {
//        let view = UIView()
//        view.backgroundColor = .red
//        view.translatesAutoresizingMaskIntoConstraints = false
//        return view
//    }()
    @objc func buttonAction(_ sender: UIButton) {
        buttonApply.isHidden = true
    }
    
    @IBAction func buttonAction1(_ sender: UIButton) {
        
    }
    
    override func loadView() {
        super.loadView()
        self.setupView()
        self.layoutUIView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.title = "StackView"
        self.labelTitle.attributedText = self.getAttributeString()
        buttonApply.isHidden = true
    }
    
    func layoutUIView() {
        self.view.addSubview(scrollView)
        NSLayoutConstraint.activate([scrollView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor), scrollView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor), scrollView.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor), scrollView.bottomAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.bottomAnchor), scrollView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor)])
    }
    
    
    func setupView() {
        
        scrollView.addSubview(mainStackView)
        mainStackView.addArrangedSubview(stackView)
        mainStackView.addArrangedSubview(buttonStackView)
        
        NSLayoutConstraint.activate([mainStackView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor), mainStackView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor), mainStackView.topAnchor.constraint(equalTo: scrollView.topAnchor), mainStackView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor), mainStackView.widthAnchor.constraint(equalTo: scrollView.widthAnchor)])
        
        NSLayoutConstraint.activate( [stackView.heightAnchor.constraint(greaterThanOrEqualToConstant: 44)])
//        
        NSLayoutConstraint.activate( [buttonSubmit.heightAnchor.constraint(greaterThanOrEqualToConstant: 44)])
        
        
        
        
//        //stackView.backgroundColor = .lightGray
//        NSLayoutConstraint.activate([buttonStackView.leadingAnchor.constraint(equalTo:
//                self.view.leadingAnchor), buttonStackView.trailingAnchor.constraint(equalTo:
//                  self.view.trailingAnchor), stackView.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor), stackView.heightAnchor.constraint(greaterThanOrEqualToConstant: 44)])
//
//        self.view.addSubview(buttonStackView)
//
//        NSLayoutConstraint.activate([buttonStackView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor), buttonStackView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor), buttonStackView.topAnchor.constraint(equalTo: stackView.bottomAnchor, constant: 15)])
//        NSLayoutConstraint.activate([buttonSubmit.heightAnchor.constraint(greaterThanOrEqualToConstant: 44)])
//        buttonStackView.backgroundColor = .lightGray
        
//        backgroundView.addSubview(stackView)

//        topView.addSubview(labelTitle)
////
//       topView.addSubview(labelSubTitle)
//
//        topView.addSubview(labelText)
//        self.view.backgroundColor = .lightGray
        //Constraints
//        let leadingConstraint = labelTitle.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15)
//        let trailingConstraint =  labelTitle.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15)
//        let topConstraint = labelTitle.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 15)
//
//        NSLayoutConstraint.activate([leadingConstraint, trailingConstraint, topConstraint])
//
//        let labelSubTitleLeadingConstraint = labelSubTitle.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15)
//        let labelSubTitleTrailingConstraint =  labelSubTitle.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15)
//        let labelSubTitleTopConstraint = labelSubTitle.topAnchor.constraint(equalTo: labelTitle.bottomAnchor, constant: 15)
//
//        NSLayoutConstraint.activate([labelSubTitleLeadingConstraint, labelSubTitleTrailingConstraint, labelSubTitleTopConstraint])
        //let widthConstraint = labelTitle.widthAnchor.constraint(equalToConstant: 150)
        //let heightConstraint = labelTitle.heightAnchor.constraint(equalToConstant: 44)
        
//        NSLayoutConstraint.activate([backgroundView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor), backgroundView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor), backgroundView.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor), backgroundView.bottomAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.bottomAnchor)])
//
//        NSLayoutConstraint.activate([stackView.leadingAnchor.constraint(equalTo: backgroundView.leadingAnchor), stackView.trailingAnchor.constraint(equalTo: backgroundView.trailingAnchor), stackView.topAnchor.constraint(equalTo: backgroundView.topAnchor), stackView.heightAnchor.constraint(greaterThanOrEqualToConstant: 50)])
//
//        let leadingConstraint = labelTitle.leadingAnchor.constraint(equalTo: topView.leadingAnchor, constant: 15)
//        let trailingConstraint =  labelTitle.trailingAnchor.constraint(equalTo: topView.trailingAnchor, constant: -15)
////        let centerYConstraint = labelTitle.centerYAnchor.constraint(equalTo: topView.centerYAnchor)
////        let centerXConstraint = labelTitle.centerXAnchor.constraint(equalTo: topView.centerXAnchor)
//        NSLayoutConstraint.activate([leadingConstraint, trailingConstraint, labelTitle.topAnchor.constraint(equalTo: topView.topAnchor, constant: 15)])
//
//        NSLayoutConstraint.activate([labelSubTitle.leadingAnchor.constraint(equalTo: topView.leadingAnchor, constant: 15), labelSubTitle.trailingAnchor.constraint(equalTo: topView.trailingAnchor, constant: -15), labelSubTitle.topAnchor.constraint(equalTo: labelTitle.bottomAnchor, constant: 15)])
//
//        NSLayoutConstraint.activate([labelText.leadingAnchor.constraint(equalTo: topView.leadingAnchor, constant: 15), labelText.trailingAnchor.constraint(equalTo: topView.trailingAnchor, constant: -15), labelText.topAnchor.constraint(equalTo: labelSubTitle.bottomAnchor, constant: 15), labelText.bottomAnchor.constraint(equalTo: topView.bottomAnchor, constant: -15)])
        
    }
    
    @objc func applybuttonAction(_ sender: UIButton) {
        buttonApply.isHidden = false
    }
    func getAttributeString() -> NSMutableAttributedString {
        let titleText = "NSCHOOL"
        let subTitleText = "Training Center"
        let firstAttributes = [NSAttributedString.Key.font: UIFont.preferredFont(forTextStyle: .title1), NSAttributedString.Key.foregroundColor: UIColor.black]
        let secondAttributes = [NSAttributedString.Key.font: UIFont.preferredFont(forTextStyle: .largeTitle), NSAttributedString.Key.foregroundColor: UIColor.systemBlue]
        
        let attributeString = NSMutableAttributedString()
        
        let title = NSMutableAttributedString(string: titleText, attributes: firstAttributes)
        attributeString.append(title)
        let subTitle = NSMutableAttributedString(string: "\n\(subTitleText)", attributes: secondAttributes)
        attributeString.append(subTitle)
        return attributeString
    }


}


