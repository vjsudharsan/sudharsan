//
//  View+Extension.swift
//  TextFieldApp
//
//  Created by nschool on 31/10/20.
//

import UIKit
extension UIView {
    func layout(using constrains: [NSLayoutConstraint]) {
        translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate(constraints)
    }
}

