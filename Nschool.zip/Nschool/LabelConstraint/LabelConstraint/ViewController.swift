//
//  ViewController.swift
//  LabelConstraint
//
//  Created by nschool on 28/10/20.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    lazy var firstLabel: UILabel = {
        let label = UILabel()
        label.text = "hari krishna hari krishna.."
        label.textAlignment = .center
        label.textColor = .green
        label.font = UIFont.systemFont(ofSize: 30)
        label.numberOfLines = .zero
        label.backgroundColor = .red
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    lazy var secondLabel :UILabel = {
        let label = UILabel()
        label.text = "hello hello hello"
        label.textAlignment = .right
        label.textColor = .black
        label.backgroundColor = .green
        label.numberOfLines = .zero
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
        
    }()
        

    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUpView()
        // Do any additional setup after loading the view.
    }
    func setUpView(){
        self.view.addSubview(firstLabel)
        self.view.addSubview(secondLabel)
        let leadingConstraint = firstLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15)
        let trailingConstraint = firstLabel.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15)
        let topConstraint = firstLabel.topAnchor.constraint(equalToSystemSpacingBelow: self.view.safeAreaLayoutGuide.topAnchor, multiplier: 15)
        NSLayoutConstraint.activate([leadingConstraint, trailingConstraint, topConstraint])
        
        let secleadingConstraint = secondLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15)
        let sectrailingConstraint = secondLabel.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -15)
        let sectopConstraint = secondLabel.topAnchor.constraint(equalTo: firstLabel.bottomAnchor, constant: 15)
        NSLayoutConstraint.activate([secleadingConstraint, sectrailingConstraint, sectopConstraint])
    }


}
