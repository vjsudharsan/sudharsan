//
//  SimpleCollectionViewCell.swift
//  SimpleCollectionView
//
//  Created by nschool on 27/10/20.
//

import UIKit

class SimpleCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var titleLabel: UILabel!
}
