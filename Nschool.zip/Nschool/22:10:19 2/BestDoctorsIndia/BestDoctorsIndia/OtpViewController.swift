//
//  OtpViewController.swift
//  Taximobility
//
//  Created by Gireesh on 30/05/16.
//  Copyright © 2016 Ndot. All rights reserved.
//

import UIKit

class OtpViewController: UIViewController,UITextFieldDelegate
{
    var resentBtn: UIButton!
    var otp4Txt: UITextField! = UITextField()
    var otp3Txt: UITextField! = UITextField()
    var otp2Txt: UITextField! = UITextField()
    var otp1Txt: UITextField! = UITextField()
    var otpInfoLbl: UILabel!
    var emailId:String! = String()
    var layoutDict = [String : AnyObject]()
    var otp4label: UILabel! = UILabel()
    var otp3label: UILabel! = UILabel()
    var otp2label: UILabel! = UILabel()
    var otp1label: UILabel! = UILabel()
    
    //MARK:ViewDidLoad
    override func viewDidLoad()
    {
        //Setting Navigation title and hiding back button
        //OTP Info Lbl
        //Setting textField text attributes
        otp1Txt.translatesAutoresizingMaskIntoConstraints = false
        otp2Txt.translatesAutoresizingMaskIntoConstraints = false
        otp3Txt.translatesAutoresizingMaskIntoConstraints = false
        otp4Txt.translatesAutoresizingMaskIntoConstraints = false
        self.otp1label.translatesAutoresizingMaskIntoConstraints = false
        self.otp1label.backgroundColor = UIColor.lightGray
        self.otp1Txt.addSubview(self.otp1label)
        self.otp2label.translatesAutoresizingMaskIntoConstraints = false
        self.otp2label.backgroundColor = UIColor.lightGray
        self.otp2Txt.addSubview(self.otp2label)
        self.otp3label.translatesAutoresizingMaskIntoConstraints = false
        self.otp3label.backgroundColor = UIColor.lightGray
        self.otp3Txt.addSubview(self.otp3label)
        self.otp4label.translatesAutoresizingMaskIntoConstraints = false
        self.otp4label.backgroundColor = UIColor.lightGray
        self.otp4Txt.addSubview(self.otp4label)
        self.otp1Txt.borderStyle = .none
         self.otp2Txt.borderStyle = .none
         self.otp3Txt.borderStyle = .none
         self.otp4Txt.borderStyle = .none
        self.otp1Txt.textAlignment = .center
        self.otp2Txt.textAlignment = .center
        self.otp3Txt.textAlignment = .center
        self.otp4Txt.textAlignment = .center
        self.otp1Txt.font = UIFont.systemFont(ofSize: 25)
        self.otp4Txt.font = UIFont.systemFont(ofSize: 25)
        self.otp3Txt.font = UIFont.systemFont(ofSize: 25)
        self.otp2Txt.font = UIFont.systemFont(ofSize: 25)
        
        self.view.addSubview(otp1Txt)
        self.view.addSubview(otp2Txt)
        self.view.addSubview(otp3Txt)
        self.view.addSubview(otp4Txt)
        self.layoutDict["otp1Txt"] = self.otp1Txt
        self.layoutDict["otp2Txt"] = self.otp2Txt
        self.layoutDict["otp3Txt"] = self.otp3Txt
        self.layoutDict["otp4Txt"] = self.otp4Txt
        self.layoutDict["otp1label"] = self.otp1label
        self.layoutDict["otp2label"] = self.otp2label
        self.layoutDict["otp3label"] = self.otp3label
        self.layoutDict["otp4label"] = self.otp4label
        self.otp1Txt.delegate = self
        self.otp2Txt.delegate  = self
        self.otp3Txt.delegate  = self
        self.otp4Txt.delegate  = self
        self.otp1Txt.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        self.otp2Txt.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        self.otp3Txt.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        self.otp4Txt.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        
        self.view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-(150)-[otp1Txt(50)]", options: [], metrics: nil, views: self.layoutDict))
         self.view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-(150)-[otp2Txt(50)]", options: [], metrics: nil, views: self.layoutDict))
         self.view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-(150)-[otp3Txt(50)]", options: [], metrics: nil, views: self.layoutDict))
         self.view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-(150)-[otp4Txt(50)]", options: [], metrics: nil, views: self.layoutDict))
         self.view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(10)-[otp1Txt(==otp4Txt)]-(10)-[otp2Txt(==otp4Txt)]-(10)-[otp3Txt(==otp4Txt)]-(10)-[otp4Txt]-(10)-|", options: [], metrics: nil, views: self.layoutDict))
        
        self.otp1Txt.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:[otp1label(1.5)]-(0)-|", options: [], metrics: nil, views: self.layoutDict))
        self.otp1Txt.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(0)-[otp1label]-(0)-|", options: [], metrics: nil, views: self.layoutDict))
        
        self.otp2Txt.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:[otp2label(1.5)]-(0)-|", options: [], metrics: nil, views: self.layoutDict))
        self.otp2Txt.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(0)-[otp2label]-(0)-|", options: [], metrics: nil, views: self.layoutDict))
        
        self.otp3Txt.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:[otp3label(1.5)]-(0)-|", options: [], metrics: nil, views: self.layoutDict))
        self.otp3Txt.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(0)-[otp3label]-(0)-|", options: [], metrics: nil, views: self.layoutDict))
        
        self.otp4Txt.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:[otp4label(1.5)]-(0)-|", options: [], metrics: nil, views: self.layoutDict))
        self.otp4Txt.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(0)-[otp4label]-(0)-|", options: [], metrics: nil, views: self.layoutDict))
        
        self.otp1Txt.keyboardType = .numberPad
        self.otp2Txt.keyboardType = .numberPad
        self.otp3Txt.keyboardType = .numberPad
        self.otp4Txt.keyboardType = .numberPad
        
      
        
       
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField.text!.count > 0 && range.length == 0
        {
            return false
        }
        else
        {
            return true
        }
    }
    @objc func textFieldDidChange(textField: UITextField)
    {
        let text = textField.text
        if (text?.utf16.count)! >= 1
        {
            switch textField
            {
            case otp1Txt:
                otp2Txt.becomeFirstResponder()
            case otp2Txt:
                otp3Txt.becomeFirstResponder()
            case otp3Txt:
                otp4Txt.becomeFirstResponder()
            case otp4Txt:
                otp4Txt.resignFirstResponder()
            default: break
            }
        }else{
            switch textField
            {
            case otp4Txt:
                otp3Txt.becomeFirstResponder()
            case otp3Txt:
                otp2Txt.becomeFirstResponder()
            case otp2Txt:
                otp1Txt.becomeFirstResponder()
            case otp1Txt:
                otp1Txt.resignFirstResponder()
            default: break
            }
        }
        
    }
    @objc func OtpEntered(sender: AnyObject)
    {
        let textField = sender as! UITextField
        if textField.text != ""
        {
            switch textField {
            case otp1Txt:
                otp1Txt.resignFirstResponder()
                otp2Txt.becomeFirstResponder()
                break
            case otp2Txt:
                otp2Txt.resignFirstResponder()
                otp3Txt.becomeFirstResponder()
                break
            case otp3Txt:
                otp3Txt.resignFirstResponder()
                otp4Txt.becomeFirstResponder()
                break
            case otp4Txt:
                otp4Txt.resignFirstResponder()
                break
            default:
                break
            }
        }
        if (otp1Txt.text?.count)! > 0 && (otp2Txt.text?.count)! > 0 && (otp3Txt.text?.count)! > 0 && (otp4Txt.text?.count)! > 0
        {
            self.view.endEditing(true)
            self.verifyOtpWithServer()
        }
    }
    //MARK:OTP Verification
    func verifyOtpWithServer()->Void
    {
        //Verifying the otp entered by the user with server
       /* let otpString = otp1Txt.text! + otp2Txt.text! + otp3Txt.text! + otp4Txt.text!
        let paramDic:NSDictionary = ["otp":otpString,"email":emailId]
         APIDownlaod.downloadDataFromServer("\(BaseURL)\(encodedKey)/?lang=\(Extensions.getSelectedLanguage())&type=otp_verify", bodyData: paramDic, method: "POST", key: "otpVerify") { (resultDic) in
            if resultDic.objectForKey("status") as! Int == 1
            {
                //Success,Moving to next stage
                self.performSegueWithIdentifier("toCardSegue", sender: self)
            }
            else
            {
                Extensions.showAlert("APP TITLE".localized(), Message: resultDic.objectForKey("message") as! String)
            }
        }*/
    }
    //MARK:ResentOtp
   
    //MARK:Prepare For Segue
    
}
