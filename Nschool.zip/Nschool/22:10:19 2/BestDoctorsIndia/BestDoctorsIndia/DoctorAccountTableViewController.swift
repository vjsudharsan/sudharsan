//
//  DoctorAccountTableViewController.swift
//  BestDoctorsIndia
//
//  Created by nschool on 15/10/19.
//  Copyright © 2019 Ndot. All rights reserved.
//

import UIKit

class DoctorAccountTableViewController: UITableViewController,UITextFieldDelegate {

    @IBOutlet var acoountTableview: UITableView!
    var dataDict = [[String : String]]()
    
    @IBOutlet weak var placetxtfld: UITextField!
    @IBOutlet weak var countrytxtfld: UITextField!
    
    @IBOutlet weak var agetxtfld: UITextField!
    
    @IBOutlet weak var experiencetxtfld: UITextField!
    
    @IBOutlet weak var hospitaltxtfld: UITextField!
    
    @IBOutlet weak var categorytxtfld: UITextField!
    
    @IBOutlet weak var departmenttxtfld: UITextField!
    
    @IBOutlet weak var optionalTxtfld: UITextField!
    
    @IBOutlet weak var specialtxtfld: UITextField!
    
    @IBOutlet weak var languagetxtfld: UITextField!
    var hospitalData:NSArray! = NSArray()
    var hospitalBgview:UIView! = UIView()
    var layoutDict = [String : AnyObject]()
    var hospitalTableview:UITableView! = UITableView.init()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        self.acoountTableview.separatorStyle = .none
        self.acoountTableview.separatorColor = UIColor.white
        self.setcustomPlaceholderString(self.placetxtfld, placeholderString: "Enter place", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.setcustomPlaceholderString(self.countrytxtfld, placeholderString: "Enter Country", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.setcustomPlaceholderString(self.agetxtfld, placeholderString: "Enter Age", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.setcustomPlaceholderString(self.experiencetxtfld, placeholderString: "Enter Experience", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.setcustomPlaceholderString(self.hospitaltxtfld, placeholderString: "Enter Hospital ID", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.setcustomPlaceholderString(self.categorytxtfld, placeholderString: "Enter Category", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.setcustomPlaceholderString(self.departmenttxtfld, placeholderString: "Enter Department", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.setcustomPlaceholderString(self.optionalTxtfld, placeholderString: "Enter Educations", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.setcustomPlaceholderString(self.specialtxtfld, placeholderString: "Enter Specialist", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.setcustomPlaceholderString(self.languagetxtfld, placeholderString: "Enter Language", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.placetxtfld.addShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        self.countrytxtfld.addShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        self.agetxtfld.addShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        self.hospitaltxtfld.addShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        self.categorytxtfld.addShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        self.departmenttxtfld.addShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        self.optionalTxtfld.addShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        self.experiencetxtfld.addShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        self.specialtxtfld.addShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        self.languagetxtfld.addShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        self.textfieldPaddingview(self.placetxtfld)
        self.textfieldPaddingview(self.countrytxtfld)
        self.textfieldPaddingview(self.agetxtfld)
        self.textfieldPaddingview(self.experiencetxtfld)
        self.textfieldPaddingview(self.hospitaltxtfld)
        self.textfieldPaddingview(self.departmenttxtfld)
        self.textfieldPaddingview(self.categorytxtfld)
        self.textfieldPaddingview(self.optionalTxtfld)
        self.textfieldPaddingview(self.specialtxtfld)
        self.textfieldPaddingview(self.languagetxtfld)
        
        APIDownload.sendGetMethod("http://192.168.0.130/bestdoctors/Api/Hospitals", key: "Hospitals") { (resultDict) in
            print("check--->",resultDict)
            self.hospitalData = resultDict.value(forKey: "data") as? NSArray
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = false
    }
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 10
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == self.placetxtfld
        {
            self.countrytxtfld.becomeFirstResponder()
        }
        else if textField == self.countrytxtfld
        {
            self.agetxtfld.becomeFirstResponder()
        }
         else if textField == self.agetxtfld
        {
            self.experiencetxtfld.becomeFirstResponder()
        }
         else if textField == self.experiencetxtfld
        {
            self.hospitaltxtfld.becomeFirstResponder()
        }
         else if textField == self.hospitaltxtfld
        {
            self.categorytxtfld.becomeFirstResponder()
        }
        else if textField == self.categorytxtfld
        {
            self.departmenttxtfld.becomeFirstResponder()
        }
         else if textField == self.departmenttxtfld
        {
            self.optionalTxtfld.becomeFirstResponder()
        }
        else if textField == self.optionalTxtfld
        {
            self.specialtxtfld.becomeFirstResponder()
        }
         else if textField == self.specialtxtfld
        {
            self.languagetxtfld.becomeFirstResponder()
        }
         else if textField == self.languagetxtfld
        {
            self.languagetxtfld.resignFirstResponder()
        }
        return true
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("\(indexPath.row)")
    }
    // Override to support conditional editing of the table view.
    /*override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func textfieldPaddingview(_ txtfld:UITextField){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: txtfld.frame.size.height))
        txtfld.leftView = paddingView
        txtfld.leftViewMode = .always
    }
    // func set custom placeholder in textfields
    func setcustomPlaceholderString(_ txtfld:UITextField!, placeholderString:String!, placeholderFont : UIFont, placeholderColor: UIColor){
        txtfld.attributedPlaceholder = NSMutableAttributedString.init(string: placeholderString, attributes: [NSAttributedString.Key.font : placeholderFont,NSAttributedString.Key.foregroundColor :placeholderColor])
    }
    func chooseHospital(){
        self.hospitalBgview.translatesAutoresizingMaskIntoConstraints = false
        self.hospitalBgview.backgroundColor = UIColor.lightGray
        self.view.addSubview(self.hospitalBgview)
        self.layoutDict["hospitalBgview"] = self.hospitalBgview
        self.view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-(0)-[hospitalBgview]-(0)-|", options: [], metrics: nil, views: self.layoutDict))
         self.view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(0)-[hospitalBgview]-(0)-|", options: [], metrics: nil, views: self.layoutDict))
        self.hospitalTableview.translatesAutoresizingMaskIntoConstraints = false
        self.hospitalTableview.delegate = self
        self.hospitalTableview.dataSource = self
        self.hospitalTableview.backgroundColor = UIColor.white
        self.hospitalBgview.addSubview(self.hospitalTableview)
        self.layoutDict["hospitalTableview"] = self.hospitalTableview
        
        self.hospitalBgview.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(10)-[hospitalTableview]-(10)-|", options: [], metrics: nil, views: self.layoutDict))
         self.hospitalBgview.addConstraint(NSLayoutConstraint.init(item: self.hospitalTableview!, attribute: .centerY, relatedBy: .equal, toItem: self.hospitalBgview!, attribute: .centerY, multiplier: 1.0, constant: 0))
        self.hospitalTableview.addConstraint(NSLayoutConstraint.init(item: self.hospitalTableview!, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1.0, constant: 200))
       
    }
}

extension UITextField {
    func addShadowToTextFields(color: UIColor = UIColor.gray, cornerRadius: CGFloat) {
        self.backgroundColor = UIColor.white
        self.layer.masksToBounds = false
        self.layer.shadowColor = color.cgColor
        self.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.layer.shadowOpacity = 1.0
        self.backgroundColor = .white
        self.layer.cornerRadius = cornerRadius
    }
}
