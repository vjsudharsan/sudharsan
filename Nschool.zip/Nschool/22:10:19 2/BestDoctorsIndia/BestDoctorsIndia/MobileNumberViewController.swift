//
//  MobileNumberViewController.swift
//  BestDoctorsIndia
//
//  Created by nschool on 19/10/19.
//  Copyright © 2019 Ndot. All rights reserved.
//

import UIKit

class MobileNumberViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var mobile_numbetxtfld: UITextField!
    
    @IBOutlet weak var continuBtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.mobile_numbetxtfld.delegate = self
        self.textfieldPaddingview(self.mobile_numbetxtfld)
        self.setcustomPlaceholderString(self.mobile_numbetxtfld!, placeholderString: "Mobile Number", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.mobile_numbetxtfld.addShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        self.continuBtn.setTitle("Continue", for: .normal)
        self.continuBtn.layer.cornerRadius = 25.0
        self.continuBtn.addTarget(self, action: #selector(continuAction), for: .touchUpInside)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func textfieldPaddingview(_ txtfld:UITextField){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: txtfld.frame.size.height))
        txtfld.leftView = paddingView
        txtfld.leftViewMode = .always
    }
    // func set custom placeholder in textfields
    func setcustomPlaceholderString(_ txtfld:UITextField!, placeholderString:String!, placeholderFont : UIFont, placeholderColor: UIColor){
        txtfld.attributedPlaceholder = NSMutableAttributedString.init(string: placeholderString, attributes: [NSAttributedString.Key.font : placeholderFont,NSAttributedString.Key.foregroundColor :placeholderColor])
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
    if textField == self.mobile_numbetxtfld{
        let maxLength = 10
        let currentString: NSString = mobile_numbetxtfld.text! as NSString
        let newString: NSString =
        currentString.replacingCharacters(in: range, with: string) as NSString
        return newString.length <= maxLength
    }
    return true
    }
    @objc func continuAction(){
        if mobile_numbetxtfld.text == "" {
            self.showAlertMessage("Information", message: "Enter Mobile Number")
        }
        else{
            let postDict = ["mobile":"9090909091"] as NSDictionary
            print("\(postDict)")
            APIDownload.downloadDataFromServer(baseURL: "http://192.168.0.130/bestdoctors/Api/doctor_forgetmobile", bodyData: postDict, method: "POST", key: "doctor_forgetmobile", completion: {(resultDict) in
                print("patient list:",resultDict)
                if "\(resultDict.value(forKey: "api_status")!)" == "1"{
                    let mobileVC = self.storyboard?.instantiateViewController(withIdentifier: "OtpViewController") as! OtpViewController
                    self.navigationController?.pushViewController(mobileVC, animated: true)
                    
                }
            })
        }
        
    }
    func showAlertMessage(_ title:String,message: String){
        let alertController = UIAlertController.init(title: title, message: message, preferredStyle: .alert)
        let okbtn = UIAlertAction.init(title: "OK", style: .default, handler:nil)
        alertController.addAction(okbtn)
        self.present(alertController, animated: true, completion: nil)
    }}
extension UITextField {
    func mobilenumberaddShadowToTextField(color: UIColor = UIColor.gray, cornerRadius: CGFloat) {
        self.backgroundColor = UIColor.white
        self.layer.masksToBounds = false
        self.layer.shadowColor = color.cgColor
        self.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.layer.shadowOpacity = 1.0
        self.backgroundColor = .white
        self.layer.cornerRadius = cornerRadius
    }
}
