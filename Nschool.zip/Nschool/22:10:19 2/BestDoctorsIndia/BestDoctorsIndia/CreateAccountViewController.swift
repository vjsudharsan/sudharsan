//
//  CreateAccountViewController.swift
//  BestDoctorsIndia
//
//  Created by Developer on 9/25/19.
//  Copyright © 2019 Ndot. All rights reserved.
//

import UIKit

class CreateAccountViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var first_NameTxtfld: UITextField!
    @IBOutlet weak var emailid_Txtfld: UITextField!
    @IBOutlet weak var mobilenumber_textfield: UITextField!
    @IBOutlet weak var last_NameTxtfld: UITextField!
    @IBOutlet weak var password_Txtfld: UITextField!
    @IBOutlet weak var confirmPassword_NameTxtfld: UITextField!
    @IBOutlet weak var Male_button: UIButton!
    @IBOutlet weak var Female_button: UIButton!
    @IBOutlet weak var continueBtn: UIButton!
    @IBOutlet weak var copyrights_lbl: UILabel!
    var signinDataDict:NSDictionary! = NSDictionary()
    var genderString:String! = String()
    
    @IBOutlet weak var navigationBgview: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.first_NameTxtfld.delegate = self
        self.last_NameTxtfld.delegate = self
        self.mobilenumber_textfield.delegate = self
        self.emailid_Txtfld.delegate = self
        self.password_Txtfld.delegate = self
        self.confirmPassword_NameTxtfld.delegate = self
        self.textfieldPaddingview(self.first_NameTxtfld)
        self.textfieldPaddingview(self.last_NameTxtfld)
        self.textfieldPaddingview(self.mobilenumber_textfield)
        self.textfieldPaddingview(self.emailid_Txtfld)
        self.textfieldPaddingview(self.password_Txtfld)
        self.textfieldPaddingview(self.confirmPassword_NameTxtfld)
        self.setcustomPlaceholderString(self.first_NameTxtfld!, placeholderString: "Enter First Name", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.setcustomPlaceholderString(self.last_NameTxtfld!, placeholderString: "Enter Last Name", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.setcustomPlaceholderString(self.mobilenumber_textfield!, placeholderString: "Enter Mobile Number", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.setcustomPlaceholderString(self.emailid_Txtfld, placeholderString: "Enter Email", placeholderFont:UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
         self.setcustomPlaceholderString(self.password_Txtfld, placeholderString: "Enter Password", placeholderFont:UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
         self.setcustomPlaceholderString(self.confirmPassword_NameTxtfld, placeholderString: "Enter Confirm Password", placeholderFont:UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.first_NameTxtfld.ShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
       self.last_NameTxtfld.ShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        self.mobilenumber_textfield.ShadowToTextField(color: UIColor.lightGray, cornerRadius: 20.0)
        self.emailid_Txtfld.ShadowToTextField(color: UIColor.lightGray, cornerRadius: 20.0)
        self.password_Txtfld.ShadowToTextField(color: UIColor.lightGray, cornerRadius: 20.0)
        self.confirmPassword_NameTxtfld.ShadowToTextField(color: UIColor.lightGray, cornerRadius: 20.0)
        self.continueBtn.layer.cornerRadius = 25.0
        self.continueBtn.addTarget(self, action: #selector(continueButtonAction(_:)), for: .touchUpInside)
        self.copyrights_lbl.text = "copy c bestdoctorindia. All rights reserved"
        self.copyrights_lbl.textColor = UIColor.lightGray
        self.copyrights_lbl.textAlignment = .center
        self.copyrights_lbl.font = UIFont.systemFont(ofSize: 14)
        
        self.Male_button.layer.cornerRadius = 10
        self.Male_button.backgroundColor = UIColor.init(red: 45.0/255.0, green: 146.0/255.0, blue: 168.0/255.0, alpha: 1.0)
        self.Male_button.addTarget(self, action: #selector(MaleButtonAction), for: .touchUpInside)
        self.Male_button.layer.borderColor = UIColor.init(red: 45.0/255.0, green: 146.0/255.0, blue: 168.0/255.0, alpha: 1.0).cgColor
        self.Male_button.layer.borderWidth = 2
        
        self.Female_button.layer.cornerRadius = 10
        self.Female_button.backgroundColor = UIColor.white
        self.Female_button.addTarget(self, action: #selector(FemaleButtonAction), for: .touchUpInside)
        self.Female_button.layer.borderColor = UIColor.init(red: 45.0/255.0, green: 146.0/255.0, blue: 168.0/255.0, alpha: 1.0).cgColor
        self.Female_button.layer.borderWidth = 2
       self.applyGradient(with: [UIColor.init(red: 86.0/255.0, green: 228.0/255.0, blue: 168.0/255.0, alpha: 1.0),UIColor.init(red: 45.0/255.0, green: 146.0/255.0, blue: 191.0/255.0, alpha: 1.0)], myview: self.navigationBgview!)
         self.ButtonapplyGradient(with: [UIColor.init(red: 45.0/255.0, green: 146.0/255.0, blue: 191.0/255.0, alpha: 1.0),UIColor.init(red: 86.0/255.0, green: 228.0/255.0, blue: 168.0/255.0, alpha: 1.0)], mybutton: self.continueBtn!)
        let numberToolbar = UIToolbar(frame:CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
        numberToolbar.barStyle = .default
        numberToolbar.items = [
        UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelNumberPad)),
        UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil),
        UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(doneWithNumberPad))]
        numberToolbar.sizeToFit()
        mobilenumber_textfield.inputAccessoryView = numberToolbar
    }
    @objc func MaleButtonAction(_ sender:UIButton){
        Male_button.backgroundColor = UIColor.init(red: 45.0/255.0, green: 146.0/255.0, blue: 168.0/255.0, alpha: 1.0)
        Female_button.backgroundColor = UIColor.white
        self.genderString = "Male"
    }
    @objc func FemaleButtonAction(sender:UIButton!){
        Female_button.backgroundColor = UIColor.init(red: 45.0/255.0, green: 146.0/255.0, blue: 168.0/255.0, alpha: 1.0)
        Male_button.backgroundColor = UIColor.white
        self.genderString = "Female"
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = false
    }
    func textfieldPaddingview(_ txtfld:UITextField){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: txtfld.frame.size.height))
        txtfld.leftView = paddingView
        txtfld.leftViewMode = .always
    }
    // func set custom placeholder in textfields
    func setcustomPlaceholderString(_ txtfld:UITextField!, placeholderString:String!, placeholderFont : UIFont, placeholderColor: UIColor){
        txtfld.attributedPlaceholder = NSMutableAttributedString.init(string: placeholderString, attributes: [NSAttributedString.Key.font : placeholderFont,NSAttributedString.Key.foregroundColor :placeholderColor])
    }
    @IBAction func back_Action(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @objc func continueButtonAction(_ sender:UIButton){
        if self.first_NameTxtfld.text == "" || self.last_NameTxtfld.text == "" || self.mobilenumber_textfield.text == "" || self.emailid_Txtfld.text == "" || self.password_Txtfld.text == "" || self.confirmPassword_NameTxtfld.text == ""
        {
            self.showAlertMessage("Message", message: "All the Fields are mandatory")
        }
        else if !self.isValidEmail(emailIDRgx: self.emailid_Txtfld.text!)
        {
            self.showAlertMessage("Message", message: "Enter valid Email Address")
        }
        else if !isPasswordValid(self.password_Txtfld.text!)
        {
            self.showAlertMessage("Message", message: "Password should be 8 character must one alpha and one special characters")
        }
        else if password_Txtfld.text != confirmPassword_NameTxtfld.text{
            self.showAlertMessage("Message", message: "Password does not match")
        }
        else
        {
            self.signinDataDict = ["firstname":self.first_NameTxtfld.text!,"lastname":self.last_NameTxtfld.text!,"email":self.emailid_Txtfld.text!,"password":self.password_Txtfld.text! ,"mobile":self.mobilenumber_textfield.text!,"gender":self.Male_button.isSelected == false ? "Male" : self.genderString!]
            let createAcVC = self.storyboard?.instantiateViewController(withIdentifier: "CreateYourAccountViewController") as! CreateYourAccountViewController
            createAcVC.receiveSigninDict = self.signinDataDict
            self.navigationController?.pushViewController(createAcVC, animated: true)
        }
    }
    func isValidEmail(emailIDRgx: String) -> Bool{
             let regx = "^[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{3,}$"
             let prd = NSPredicate(format: "SELF MATCHES%@", regx)
             return prd.evaluate(with: emailIDRgx)
    }
    func isPasswordValid(_ password : String) -> Bool{
        let passwordTest = NSPredicate(format: "SELF MATCHES %@", "^(?=.*[a-z])(?=.*[$@$#!%*?&])[A-Za-z\\d$@$#!%*?&]{8,}")
        return passwordTest.evaluate(with: password)
    }
       func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == self.mobilenumber_textfield{
            let maxLength = 10
            let currentString: NSString = mobilenumber_textfield.text! as NSString
            let newString: NSString =
            currentString.replacingCharacters(in: range, with: string) as NSString
            return newString.length <= maxLength
        }
        return true
        }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == self.first_NameTxtfld {
            self.last_NameTxtfld.becomeFirstResponder()
        }
        else if textField == self.last_NameTxtfld{
            self.mobilenumber_textfield.becomeFirstResponder()
        }
        else if textField == self.mobilenumber_textfield{
            self.emailid_Txtfld.becomeFirstResponder()
        }
        else if textField == self.emailid_Txtfld{
            self.password_Txtfld.becomeFirstResponder()
        }
        else if textField == self.password_Txtfld{
            self.confirmPassword_NameTxtfld.becomeFirstResponder()
        }
        else if textField == self.confirmPassword_NameTxtfld{
            self.confirmPassword_NameTxtfld.resignFirstResponder()
        }
        return true
    }
    @objc func cancelNumberPad() {
           //Cancel with number pad
           self.mobilenumber_textfield.resignFirstResponder()
       }
       @objc func doneWithNumberPad() {
           //Done with number pad
           self.mobilenumber_textfield.resignFirstResponder()
           
       }
    func showAlertMessage(_ title:String,message: String){
        let alertController = UIAlertController.init(title: title, message: message, preferredStyle: .alert)
        let okbtn = UIAlertAction.init(title: "OK", style: .default, handler:nil)
        alertController.addAction(okbtn)
        self.present(alertController, animated: true, completion: nil)
    }
    func applyGradient(with colours: [UIColor],myview:UIView) {
           let gradient = CAGradientLayer()
           gradient.frame = myview.bounds
           gradient.colors = colours.map { $0.cgColor }
           gradient.startPoint = CGPoint(x: 0.0, y: 0.5)
           gradient.endPoint = CGPoint(x: 1.0, y: 0.5)
           myview.layer.insertSublayer(gradient, at: 0)
    }
    func ButtonapplyGradient(with colours: [UIColor],mybutton:UIButton) {
        let gradient = CAGradientLayer()
        gradient.frame = mybutton.bounds
        gradient.colors = colours.map { $0.cgColor }
        gradient.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradient.endPoint = CGPoint(x: 1.0, y: 0.5)
        mybutton.layoutIfNeeded()
        mybutton.layer.cornerRadius = 25.0
        mybutton.clipsToBounds = true
        mybutton.layer.insertSublayer(gradient, at: 0)
    }
}
extension UITextField {
    func ShadowToTextField(color: UIColor = UIColor.gray, cornerRadius: CGFloat) {
        self.backgroundColor = UIColor.white
        self.layer.masksToBounds = false
        self.layer.shadowColor = color.cgColor
        self.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.layer.shadowOpacity = 1.0
        self.backgroundColor = .white
        self.layer.cornerRadius = cornerRadius
}
    
}

