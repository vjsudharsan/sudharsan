//
//  VerifyAccountViewController.swift
//  BestDoctorsIndia
//
//  Created by Developer on 9/25/19.
//  Copyright © 2019 Ndot. All rights reserved.
//

import UIKit

class VerifyAccountViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var mobiletxtfld: UITextField!
    
    @IBOutlet weak var passwordtxtfld: UITextField!
    
    @IBOutlet weak var nametxtfld: UITextField!
    
    @IBOutlet weak var gendertxtfld: UITextField!
    
    @IBOutlet weak var citytxtfld: UITextField!
    
    @IBOutlet weak var countrytxtfld: UITextField!
    @IBOutlet weak var emailtxtfld: UITextField!
    
    @IBOutlet weak var createBtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.mobiletxtfld.createShadowToTextFields(color: UIColor.lightGray, cornerRadius: 20)
        self.passwordtxtfld.createShadowToTextFields(color: UIColor.lightGray, cornerRadius: 20)
        self.nametxtfld.createShadowToTextFields(color: UIColor.lightGray, cornerRadius: 20.0)
        self.gendertxtfld.createShadowToTextFields(color: UIColor.lightGray, cornerRadius: 20.0)
        self.citytxtfld.createShadowToTextFields(color: UIColor.lightGray, cornerRadius: 20)
        self.countrytxtfld.createShadowToTextFields(color: UIColor.lightGray, cornerRadius: 20.0)
        self.emailtxtfld.createShadowToTextFields(color: UIColor.lightGray, cornerRadius: 20.0)
        self.createBtn.layer.cornerRadius = 25.0
        // Right padding view in textfields
        self.textfieldsetRightPaddingview(self.mobiletxtfld)
        self.textfieldsetRightPaddingview(self.passwordtxtfld)
        self.textfieldsetRightPaddingview(self.nametxtfld)
        self.textfieldsetRightPaddingview(self.citytxtfld)
        self.textfieldsetRightPaddingview(self.countrytxtfld)
        self.textfieldsetRightPaddingview(self.emailtxtfld)
        self.textfieldsetRightPaddingview(self.gendertxtfld)
        // Left padding view in textfields
        self.textfieldsetLeftPaddingview(self.mobiletxtfld)
        self.textfieldsetLeftPaddingview(self.passwordtxtfld)
        self.textfieldsetLeftPaddingview(self.nametxtfld)
        self.textfieldsetLeftPaddingview(self.citytxtfld)
        self.textfieldsetLeftPaddingview(self.countrytxtfld)
        self.textfieldsetLeftPaddingview(self.emailtxtfld)
        self.textfieldsetLeftPaddingview(self.gendertxtfld)
        
    }
    
    @IBAction func createButton_Action(_ sender: Any) {
        let homeVC = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
        self.navigationController?.pushViewController(homeVC, animated: true)
    }
    
    @IBAction func back_action(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = false
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == self.mobiletxtfld {
            self.passwordtxtfld.becomeFirstResponder()
        }
        else if textField == self.passwordtxtfld{
            self.nametxtfld.becomeFirstResponder()
        }
        else if textField == self.nametxtfld{
            self.gendertxtfld.becomeFirstResponder()
        }
        else if textField == self.gendertxtfld{
            self.citytxtfld.becomeFirstResponder()
        }
        else if textField == self.citytxtfld{
            self.countrytxtfld.becomeFirstResponder()
        }
        else if textField == self.countrytxtfld{
            self.emailtxtfld.becomeFirstResponder()
        }
        else if textField == self.emailtxtfld{
            self.emailtxtfld.resignFirstResponder()
        }
        return true
    }
    func textfieldsetLeftPaddingview(_ txtfld:UITextField){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: txtfld.frame.size.height))
        txtfld.leftView = paddingView
        txtfld.leftViewMode = .always
    }
    func textfieldsetRightPaddingview(_ txtfld:UITextField){
        let RightpaddingView = UIView(frame: CGRect(x: 0, y: 0, width: 40, height: txtfld.frame.size.height))
        let editBtn = UIButton(frame: CGRect(x: 0, y: 0, width: 40, height: txtfld.frame.size.height))
        editBtn.setImage(UIImage(named: "editbtn"), for: .normal)
        RightpaddingView.addSubview(editBtn)
        txtfld.rightView = RightpaddingView
        txtfld.rightViewMode = .always
    }
    // func set custom placeholder in textfields
    func setcustomPlaceholderString(_ txtfld:UITextField!, placeholderString:String!, placeholderFont : UIFont, placeholderColor: UIColor){
        txtfld.attributedPlaceholder = NSMutableAttributedString.init(string: placeholderString, attributes: [NSAttributedString.Key.font : placeholderFont,NSAttributedString.Key.foregroundColor :placeholderColor])
    }
}
extension UITextField {
    func createShadowToTextFields(color: UIColor = UIColor.gray, cornerRadius: CGFloat) {
        self.backgroundColor = UIColor.white
        self.layer.masksToBounds = false
        self.layer.shadowColor = color.cgColor
        self.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.layer.shadowOpacity = 1.0
        self.backgroundColor = .white
        self.layer.cornerRadius = cornerRadius
    }
}
