//
//  HomeViewController.swift
//  BestDoctorsIndia
//
//  Created by Apple on 27/09/19.
//  Copyright © 2019 Ndot. All rights reserved.
//

import UIKit

class HomeViewController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.addSlideMenuButton()
    }
    
    
}
