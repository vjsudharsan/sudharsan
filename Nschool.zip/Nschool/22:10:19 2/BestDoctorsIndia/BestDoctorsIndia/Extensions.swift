//
//  Extensions.swift
//  BestDoctorsIndia
//
//  Created by nschool on 15/10/19.
//  Copyright © 2019 Ndot. All rights reserved.
//

import UIKit

class Extensions: NSObject {
    class func setdeviceToken(tokenID:String)->Void
    {
        UserDefaults.standard.set(tokenID, forKey: "deviceToken")
        UserDefaults.standard.synchronize()
    }
    class func getdeviceToken()->String
    {
        let deviceToken = UserDefaults.standard.object(forKey: "deviceToken")
        if deviceToken == nil
        {
            return ""
        }
        else
        {
            return deviceToken as! String
        }
    }
}
