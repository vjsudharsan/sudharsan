//
//  ChatViewController.swift
//  BestDoctorsIndia
//
//  Created by nschool on 19/10/19.
//  Copyright © 2019 Ndot. All rights reserved.
//

import UIKit

class ChatViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
     
      var layoutDict = [String : AnyObject]()
      var chatTxtview:UITextView! = UITextView()
      var chatDict:NSArray! = NSArray()
    
    @IBOutlet weak var chatListTableview: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.createchatListTableview()
        self.callchatApi()
    }
    
   func createchatListTableview(){

     self.chatTxtview.translatesAutoresizingMaskIntoConstraints = false
    chatTxtview.contentInset = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 0)
     self.view.addSubview(self.chatTxtview)
     self.layoutDict["chatTxtview"] = self.chatTxtview
           self.view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-(10)-[chatTxtview(40)]-(10)-|", options: [], metrics: nil, views: self.layoutDict))
     self.view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(10)-[chatTxtview]-(10)-|", options: [], metrics: nil, views: self.layoutDict))
    self.chatTxtview.layoutIfNeeded()
    self.chatTxtview.layer.borderWidth = 2.0
    self.chatTxtview.layer.borderColor = UIColor.lightGray.cgColor
    self.chatTxtview.layer.cornerRadius = 20
    self.chatListTableview.bringSubviewToFront(self.chatTxtview)
   }
    func callchatApi(){
            let postDict = ["Case_Id":"1"] as NSDictionary
            print("\(postDict)")
            APIDownload.downloadDataFromServer(baseURL: "http://bestdoctorindia.com/Api/viewChat", bodyData: postDict, method: "POST", key: "PatientList", completion: {(resultDict) in
                print("chat list:",resultDict)
                self.chatDict = resultDict.value(forKey: "data") as? NSArray
                DispatchQueue.main.async {
                    self.chatListTableview.reloadData()
                }
    
            })
            
    }
    func numberOfSections(in tableView: UITableView) -> Int {
           return 1
       }
       func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.chatDict.count
    }
       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = tableView.dequeueReusableCell(withIdentifier: "receiverCell") as! ChatReceiverTableViewCell
        
          cell.selectionStyle = .none
           return cell
       }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       return 40
    }
    func checkrectForText(text: String, font: UIFont, maxSize: CGSize) -> CGFloat
    {
        //This is a method to calculate the height
        let label = UILabel(frame:CGRect(x: 0, y: 0, width: maxSize.width, height: maxSize.height))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = font
        label.text = text
        
        label.sizeToFit()
        
        return label.frame.height
    }

    func rectForText(text: String, font: UIFont, maxSize: CGSize) -> CGSize
    {
        //This is a method to calculate the height
        let attrString = NSAttributedString.init(string: text, attributes: [NSAttributedString.Key.font:font])
        let rect = attrString.boundingRect(with: maxSize, options: NSStringDrawingOptions.usesLineFragmentOrigin, context: nil)
        let size = CGSize(width: rect.size.width, height: rect.size.height)
        return size
    }
}
