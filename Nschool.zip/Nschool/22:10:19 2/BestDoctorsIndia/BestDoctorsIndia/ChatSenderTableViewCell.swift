//
//  ChatSenderTableViewCell.swift
//  BestDoctorsIndia
//
//  Created by Gowthaman on 22/10/19.
//  Copyright © 2019 Ndot. All rights reserved.
//

import UIKit

class ChatSenderTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
