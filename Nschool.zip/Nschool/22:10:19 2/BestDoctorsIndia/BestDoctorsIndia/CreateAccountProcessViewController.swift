//
//  CreateAccountProcessViewController.swift
//  BestDoctorsIndia
//
//  Created by Developer on 9/25/19.
//  Copyright © 2019 Ndot. All rights reserved.
//

import UIKit

class CreateAccountProcessViewController: UIViewController,UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet var account_tableview: UITableView!
    @IBOutlet weak var copyrights_lbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.copyrights_lbl.text = "copy c bestdoctorindia. All rights reserved"
        self.copyrights_lbl.textColor = UIColor.lightGray
        self.copyrights_lbl.textAlignment = .center
       
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = false
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "account") as! AccountTableViewCell
        cell.accountInputFields.addShadowToTextField(color: UIColor.lightGray, cornerRadius: 20.0)
        return cell
        
    }
    func textfieldPaddingview(_ txtfld:UITextField){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: txtfld.frame.size.height))
        txtfld.leftView = paddingView
        txtfld.leftViewMode = .always
    }
    // func set custom placeholder in textfields
    func setcustomPlaceholderString(_ txtfld:UITextField!, placeholderString:String!, placeholderFont : UIFont, placeholderColor: UIColor){
        txtfld.attributedPlaceholder = NSMutableAttributedString.init(string: placeholderString, attributes: [NSAttributedString.Key.font : placeholderFont,NSAttributedString.Key.foregroundColor :placeholderColor])
    }
   
    @IBAction func back_action(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    func showAlertMessage(_ title:String,message: String){
        let alertController = UIAlertController.init(title: title, message: message, preferredStyle: .alert)
        let okbtn = UIAlertAction.init(title: "OK", style: .default, handler:nil)
        alertController.addAction(okbtn)
        self.present(alertController, animated: true, completion: nil)
    }
}

