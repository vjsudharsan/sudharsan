//
//  CreateYourAccountViewController.swift
//  BestDoctorsIndia
//
//  Created by nschool on 18/10/19.
//  Copyright © 2019 Ndot. All rights reserved.
//

import UIKit

class CreateYourAccountViewController: UIViewController,UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource,UIGestureRecognizerDelegate {
    
    @IBOutlet weak var navigationview: UIView!
    @IBOutlet weak var Place_Textfield: UITextField!
    @IBOutlet weak var Country_Textfield: UITextField!
    @IBOutlet weak var Age_Textfield: UITextField!
    @IBOutlet weak var Experience_Textfield: UITextField!
    @IBOutlet weak var Name_Textfield: UITextField!
    @IBOutlet weak var DepartmentName_Textfield: UITextField!
    @IBOutlet weak var Categry_Textfield: UITextField!
    @IBOutlet weak var Select_Textfield: UITextField!
    @IBOutlet weak var SelectLanguage_Textfield: UITextField!
    @IBOutlet weak var Done_Button: UIButton!
    
    var hospitalData:NSArray! = NSArray()
    var departmentArray:NSArray! = NSArray()
    var languageArray:NSArray! = NSArray()
    
    
    var hospitalBgView:UIView! = UIView()
    var departmentBgView:UIView! = UIView()
    var languageView:UIView! = UIView()
    var hospitalTableview:UITableView! = UITableView.init(frame: CGRect.zero, style: .grouped)
    var departmentTableview:UITableView! = UITableView.init()
    var languageTableTableview:UITableView! = UITableView.init()
    var layoutDict = [String : AnyObject]()
    var gradientLayer: CAGradientLayer!
    
    @IBOutlet weak var hospitalBtn: UIButton!
    
    @IBOutlet weak var departmentBtn: UIButton!
    
    @IBOutlet weak var languageBTn: UIButton!
    var receiveSigninDict:NSDictionary! = NSDictionary()
    var hospitalIDString:String! = String()
    var departmentIDstring:String! = String()
    var categoryIDstring:String! = String()
    var doctorIDString:String! = String()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.Place_Textfield.delegate = self
        self.Country_Textfield.delegate = self
        self.Age_Textfield.delegate = self
        self.Experience_Textfield.delegate = self
        self.Name_Textfield.delegate = self
        self.DepartmentName_Textfield.delegate = self
        self.Categry_Textfield.delegate = self
        self.Select_Textfield.delegate = self
        self.SelectLanguage_Textfield.delegate = self
        
        self.textfieldPaddingview(self.Place_Textfield)
        self.textfieldPaddingview(self.Country_Textfield)
        self.textfieldPaddingview(self.Age_Textfield)
        self.textfieldPaddingview(self.Experience_Textfield)
        self.textfieldPaddingview(self.Name_Textfield)
        self.textfieldPaddingview(self.DepartmentName_Textfield)
        self.textfieldPaddingview(self.Categry_Textfield)
        self.textfieldPaddingview(self.Select_Textfield)
        self.textfieldPaddingview(self.SelectLanguage_Textfield)
        self.DepartmentName_Textfield.isUserInteractionEnabled = false
        self.SelectLanguage_Textfield.isUserInteractionEnabled = false
        self.DepartmentName_Textfield.isUserInteractionEnabled = false
        self.Categry_Textfield.isUserInteractionEnabled = false
        
        self.languageArray = ["Tamil","English","Kannada","Hindi","Russian","Bengali","Malayalam","Telugu"]
        
        self.setcustomPlaceholderString(self.Place_Textfield!, placeholderString: "Place", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.setcustomPlaceholderString(self.Country_Textfield!, placeholderString: "Country", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.setcustomPlaceholderString(self.Age_Textfield!, placeholderString: "Age", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.setcustomPlaceholderString(self.Experience_Textfield!, placeholderString: "Experience", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.setcustomPlaceholderString(self.Name_Textfield!, placeholderString: "Hospital Name", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.setcustomPlaceholderString(self.DepartmentName_Textfield!, placeholderString: "Department Name", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.setcustomPlaceholderString(self.Categry_Textfield!, placeholderString: "Specialities Categry", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.setcustomPlaceholderString(self.Select_Textfield!, placeholderString: "Select", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.setcustomPlaceholderString(self.SelectLanguage_Textfield!, placeholderString: "Select Language", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        
        self.Place_Textfield.ShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        self.Country_Textfield.ShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        self.Age_Textfield.ShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        self.Experience_Textfield.ShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        self.Name_Textfield.ShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        self.DepartmentName_Textfield.ShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        self.Categry_Textfield.ShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        self.Select_Textfield.ShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        self.SelectLanguage_Textfield.ShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        
        self.Done_Button.layer.cornerRadius = 25.0
        self.createHospitalView()
        self.createdepartmentView()
        self.createlanguageView()
       self.applyGradient(with: [UIColor.init(red: 45.0/255.0, green: 146.0/255.0, blue: 191.0/255.0, alpha: 1.0),UIColor.init(red: 86.0/255.0, green: 228.0/255.0, blue: 168.0/255.0, alpha: 1.0)], mybutton: self.Done_Button!)
        APIDownload.sendGetMethod("http://bestdoctorindia.com/Api/Hospitals", key: "Hospitals") { (resultDict) in
            print("check--->",resultDict)
            self.hospitalData = resultDict.value(forKey: "data") as? NSArray
           
            DispatchQueue.main.async {
               self.hospitalTableview.reloadData()
            }
        }
        self.Done_Button.addTarget(self, action: #selector(doneButtonAction(_:)), for: .touchUpInside)
        self.navigationviewapplyGradient(with: [UIColor.init(red: 86.0/255.0, green: 228.0/255.0, blue: 168.0/255.0, alpha: 1.0),UIColor.init(red: 45.0/255.0, green: 146.0/255.0, blue: 191.0/255.0, alpha: 1.0)], myview: self.navigationview!)
    }
    func textfieldPaddingview(_ txtfld:UITextField){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: txtfld.frame.size.height))
        txtfld.leftView = paddingView
        txtfld.leftViewMode = .always
    }
    // func set custom placeholder in textfields
    func setcustomPlaceholderString(_ txtfld:UITextField!, placeholderString:String!, placeholderFont : UIFont, placeholderColor: UIColor){
        txtfld.attributedPlaceholder = NSMutableAttributedString.init(string: placeholderString, attributes: [NSAttributedString.Key.font : placeholderFont,NSAttributedString.Key.foregroundColor :placeholderColor])
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = false
    }
    @objc func createHospitalView(){
        self.hospitalBgView.translatesAutoresizingMaskIntoConstraints = false
        self.hospitalBgView.isHidden = true
        self.hospitalBgView.backgroundColor = UIColor.black
        self.hospitalBgView.alpha = 0.8
        self.view.addSubview(self.hospitalBgView)
        self.layoutDict["hospitalBgView"] = self.hospitalBgView
        self.view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-(0)-[hospitalBgView]-(0)-|", options: [], metrics: nil, views: self.layoutDict))
        self.view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(0)-[hospitalBgView]-(0)-|", options: [], metrics: nil, views: self.layoutDict))
        self.hospitalTableview.translatesAutoresizingMaskIntoConstraints = false
        self.hospitalTableview.showsVerticalScrollIndicator = false
        self.hospitalTableview.delegate = self
        self.hospitalTableview.dataSource = self
        self.hospitalTableview.backgroundColor = UIColor.white
        self.hospitalTableview.separatorStyle = .none
        self.hospitalBgView.addSubview(self.hospitalTableview)
        self.layoutDict["hospitalTableview"] = self.hospitalTableview
        self.hospitalBgView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(10)-[hospitalTableview]-(10)-|", options: [], metrics: nil, views: self.layoutDict))
        self.hospitalBgView.addConstraint(NSLayoutConstraint.init(item: self.hospitalTableview!, attribute: .centerY, relatedBy: .equal, toItem: self.hospitalBgView!, attribute: .centerY, multiplier: 1.0, constant: 0))
        self.hospitalTableview.addConstraint(NSLayoutConstraint.init(item: self.hospitalTableview!, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1.0, constant: 250))
        self.hospitalTableview.layoutIfNeeded()
        self.hospitalTableview.layer.cornerRadius = 5.0
        self.hospitalTableview.clipsToBounds = true
        // Adding gesture to hide the view ehn user tapped on bg view
        let tapGesture = UITapGestureRecognizer.init(target: self, action: #selector(CreateYourAccountViewController.tapGestureFired))
        tapGesture.delegate = self
        tapGesture.cancelsTouchesInView = false
        hospitalBgView.addGestureRecognizer(tapGesture)
    }
    @objc func createdepartmentView(){
        self.departmentBgView.translatesAutoresizingMaskIntoConstraints = false
        self.departmentBgView.isHidden = true
        self.departmentBgView.backgroundColor = UIColor.black
        self.departmentBgView.alpha = 0.8
        self.view.addSubview(self.departmentBgView)
        self.layoutDict["departmentBgView"] = self.departmentBgView
        self.view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-(0)-[departmentBgView]-(0)-|", options: [], metrics: nil, views: self.layoutDict))
        self.view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(0)-[departmentBgView]-(0)-|", options: [], metrics: nil, views: self.layoutDict))
        self.departmentTableview.translatesAutoresizingMaskIntoConstraints = false
        self.departmentTableview.showsVerticalScrollIndicator = false
        self.departmentTableview.delegate = self
        self.departmentTableview.dataSource = self
        self.departmentTableview.backgroundColor = UIColor.white
        self.departmentTableview.separatorStyle = .none
        self.departmentBgView.addSubview(self.departmentTableview)
        self.layoutDict["departmentTableview"] = self.departmentTableview
        self.departmentBgView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(10)-[departmentTableview]-(10)-|", options: [], metrics: nil, views: self.layoutDict))
        self.departmentBgView.addConstraint(NSLayoutConstraint.init(item: self.departmentTableview!, attribute: .centerY, relatedBy: .equal, toItem: self.departmentBgView!, attribute: .centerY, multiplier: 1.0, constant: 0))
        self.departmentTableview.addConstraint(NSLayoutConstraint.init(item: self.departmentTableview!, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1.0, constant: 250))
        self.departmentTableview.layoutIfNeeded()
        self.departmentTableview.layer.cornerRadius = 5.0
        self.departmentTableview.clipsToBounds = true
        // Adding gesture to hide the view ehn user tapped on bg view
        let tapGesture = UITapGestureRecognizer.init(target: self, action: #selector(CreateYourAccountViewController.departmenttapGestureFired))
        tapGesture.delegate = self
        tapGesture.cancelsTouchesInView = false
        departmentBgView.addGestureRecognizer(tapGesture)
    }
    @objc func createlanguageView(){
        self.languageView.translatesAutoresizingMaskIntoConstraints = false
        self.languageView.isHidden = true
        self.languageView.backgroundColor = UIColor.black
        self.languageView.alpha = 0.8
        self.view.addSubview(self.languageView)
        self.layoutDict["languageView"] = self.languageView
        self.view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-(0)-[languageView]-(0)-|", options: [], metrics: nil, views: self.layoutDict))
        self.view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(0)-[languageView]-(0)-|", options: [], metrics: nil, views: self.layoutDict))
        self.languageTableTableview.translatesAutoresizingMaskIntoConstraints = false
        self.languageTableTableview.showsVerticalScrollIndicator = false
        self.languageTableTableview.delegate = self
        self.languageTableTableview.dataSource = self
        self.languageTableTableview.backgroundColor = UIColor.white
        self.languageView.addSubview(self.languageTableTableview)
        self.layoutDict["languageTableTableview"] = self.languageTableTableview
        self.languageView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(10)-[languageTableTableview]-(10)-|", options: [], metrics: nil, views: self.layoutDict))
        self.languageView.addConstraint(NSLayoutConstraint.init(item: self.languageTableTableview!, attribute: .centerY, relatedBy: .equal, toItem: self.languageView!, attribute: .centerY, multiplier: 1.0, constant: 0))
        self.languageTableTableview.addConstraint(NSLayoutConstraint.init(item: self.languageTableTableview!, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1.0, constant: 250))
        self.languageTableTableview.layoutIfNeeded()
        self.languageTableTableview.layer.cornerRadius = 5.0
        self.languageTableTableview.clipsToBounds = true        // Adding gesture to hide the view ehn user tapped on bg view
        let tapGesture = UITapGestureRecognizer.init(target: self, action: #selector(CreateYourAccountViewController.languagetapGestureFired))
        tapGesture.delegate = self
        tapGesture.cancelsTouchesInView = false
        languageView.addGestureRecognizer(tapGesture)
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == self.hospitalTableview{
            return self.hospitalData.count
        }
        else if tableView == self.departmentTableview{
            return departmentArray.count
        }
        return languageArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell:UITableViewCell! = tableView.dequeueReusableCell(withIdentifier: "hospitalCell")
        if cell == nil
        {
            cell = UITableViewCell.init(style: UITableViewCell.CellStyle.default, reuseIdentifier: "hospitalCell")
        }
        //Removing all the components
        for subView in cell.subviews
        {
            subView.removeFromSuperview()
        }
        var celllayoutDict = [String:AnyObject]()
        let titlelabel:UILabel! = UILabel.init()
        titlelabel.backgroundColor = UIColor.white
        cell.addSubview(titlelabel)
        celllayoutDict["titlelabel"] = titlelabel
        titlelabel.translatesAutoresizingMaskIntoConstraints = false
        cell.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-(10)-[titlelabel]-(10)-|", options: [], metrics: nil, views: celllayoutDict))
        cell.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(10)-[titlelabel]-(10)-|", options: [], metrics: nil, views: celllayoutDict))
        if tableView == self.hospitalTableview {
             titlelabel.text = "\((self.hospitalData.object(at: indexPath.row) as! NSDictionary).value(forKey: "hospital_name")!)"
        }
        else if tableView == self.departmentTableview{
            titlelabel.text = "\((self.departmentArray.object(at: indexPath.row) as! NSDictionary).value(forKey: "Department_Name")!)"
        }
        else
        {
            titlelabel.text = "\(self.languageArray.object(at: indexPath.row))"
        }
        cell.selectionStyle = .none
        cell.backgroundColor = UIColor.white
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("\(indexPath.row)")
        if tableView == self.hospitalTableview {
            self.Name_Textfield.text = "\((self.hospitalData.object(at: indexPath.row) as! NSDictionary).value(forKey: "hospital_name")!)"
            self.Categry_Textfield.text = "\((self.hospitalData.object(at: indexPath.row) as! NSDictionary).value(forKey: "category")!)"
            self.departmentArray = ((self.hospitalData.object(at: indexPath.row) as! NSDictionary).value(forKey: "department")!) as? NSArray
            self.hospitalIDString = "\((self.hospitalData.object(at: indexPath.row) as! NSDictionary).value(forKey: "Hospital_Id")!)"
            self.categoryIDstring = "\((self.hospitalData.object(at: indexPath.row) as! NSDictionary).value(forKey: "Category_Id")!)"
            self.departmentTableview.reloadData()
            self.hospitalBgView.isHidden = true
        }
        else if tableView == self.departmentTableview
        {
            self.DepartmentName_Textfield.text = "\((self.departmentArray.object(at: indexPath.row) as! NSDictionary).value(forKey: "Department_Name")!)"
            self.departmentIDstring =  "\((self.departmentArray.object(at: indexPath.row) as! NSDictionary).value(forKey: "Department_Id")!)"
            self.departmentBgView.isHidden = true
        }
        else
        {
            self.SelectLanguage_Textfield.text = "\(self.languageArray.object(at: indexPath.row))"
            self.languageView.isHidden = true
        }
       
       
    }
    @objc func tapGestureFired()->Void
    {
        hospitalBgView.isHidden = true
        
    }
    @objc func departmenttapGestureFired()->Void
    {
        departmentBgView.isHidden = true
        
    }
    @objc func languagetapGestureFired()->Void
    {
        languageView.isHidden = true
        
    }
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool
    {
        // Method to recognize whether the tap originated from bg view or table view
        if touch.view!.isDescendant(of: hospitalTableview)
        {
            
            return false
        }
        else if touch.view!.isDescendant(of: departmentTableview)
        {
            
            return false
        }
        else if touch.view!.isDescendant(of: languageTableTableview)
        {
            
            return false
        }
        else
        {
            return true
        }
        
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
           if textField == self.Place_Textfield {
               self.Country_Textfield.becomeFirstResponder()
           }
           else if textField == self.Country_Textfield{
               self.Age_Textfield.becomeFirstResponder()
           }
           else if textField == self.Age_Textfield{
               self.Experience_Textfield.becomeFirstResponder()
           }
           else if textField == self.Experience_Textfield{
               self.Experience_Textfield.resignFirstResponder()
           }
           return true
       }
    
    @IBAction func hospitalButtonAction(_ sender: UIButton) {
        self.hospitalBgView.isHidden = false
    }
    
    @IBAction func departmentButttonAction(_ sender: UIButton) {
        self.departmentBgView.isHidden = false
    }
   
    @IBAction func languageButtonAction(_ sender: UIButton) {
        self.languageView.isHidden = false
        self.languageTableTableview.reloadData()
    }
    @objc func doneButtonAction(_ sender:UIButton){
        if self.Age_Textfield.text == "" || self.Place_Textfield.text == "" || self.Country_Textfield.text == "" || self.Experience_Textfield.text == "" || self.DepartmentName_Textfield.text == "" || self.Categry_Textfield.text == "" || self.Select_Textfield.text == "" || self.SelectLanguage_Textfield.text == ""
        {
            self.showAlertMessage("Information", message: "All the Fields are Mandatory")
        }
        else
        {
            self.doctorsignupApiCall()
        }
        
        
    }
    func doctorsignupApiCall(){
        let postDict = ["firstname":"\(self.receiveSigninDict.value(forKey: "firstname")!)",
            "lastname":"\(self.receiveSigninDict.value(forKey: "lastname")!)",
            "email":"\(self.receiveSigninDict.value(forKey: "email")!)",
            "password":"\(self.receiveSigninDict.value(forKey: "password")!)",
            "mobile":"\(self.receiveSigninDict.value(forKey: "mobile")!)",
            "gender":"\(self.receiveSigninDict.value(forKey: "gender")!)",
            "place":self.Place_Textfield.text!,
            "country":self.Country_Textfield.text!,
            "age":self.Age_Textfield.text!,
            "experience":self.Experience_Textfield.text!,
            "Hospital_Id":self.hospitalIDString!,
            "Category_Id":self.categoryIDstring!,
            "Department_Id":self.departmentIDstring!,
            "add_special":self.Select_Textfield.text!,
            "language":self.SelectLanguage_Textfield.text!,
            "device_token":"\(Extensions.getdeviceToken())"] as NSDictionary
        APIDownload.downloadDataFromServer(baseURL: "http://bestdoctorindia.com/Api/Doctor_signup", bodyData: postDict, method: "POST", key: "Doctor Signup", completion: {(resultDict) in
            print("check doctor signup value:",resultDict)
            if "\(resultDict.value(forKey: "message")!)" == "Successfully SignUp"{
                let doctorData = resultDict.value(forKey: "data") as! NSDictionary
                self.doctorIDString = "\(doctorData.value(forKey: "Doctor_Id")!)"
                let patientListVC = self.storyboard?.instantiateViewController(withIdentifier: "patientlist") as! PatientListViewController
                patientListVC.receiveDoctorID = self.doctorIDString
                self.navigationController?.pushViewController(patientListVC, animated: true)
            }
            else
            {
                self.showAlertMessage("Information", message: "\(resultDict.value(forKey: "message")!)")
            }
            
            
        })
    }
    func applyGradient(with colours: [UIColor],mybutton:UIButton) {
        let gradient = CAGradientLayer()
        gradient.frame = mybutton.bounds
        gradient.colors = colours.map { $0.cgColor }
        gradient.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradient.endPoint = CGPoint(x: 1.0, y: 0.5)
        mybutton.layoutIfNeeded()
        mybutton.layer.cornerRadius = 25.0
        mybutton.clipsToBounds = true
        mybutton.layer.insertSublayer(gradient, at: 0)
    }
    func navigationviewapplyGradient(with colours: [UIColor],myview:UIView) {
           let gradient = CAGradientLayer()
           gradient.frame = myview.bounds
           gradient.colors = colours.map { $0.cgColor }
           gradient.startPoint = CGPoint(x: 0.0, y: 0.5)
           gradient.endPoint = CGPoint(x: 1.0, y: 0.5)
           myview.layer.insertSublayer(gradient, at: 0)
    }
    func showAlertMessage(_ title:String,message: String){
        let alertController = UIAlertController.init(title: title, message: message, preferredStyle: .alert)
        let okbtn = UIAlertAction.init(title: "OK", style: .default, handler:nil)
        alertController.addAction(okbtn)
        self.present(alertController, animated: true, completion: nil)
    }
   
    @IBAction func backButton_Action(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
}

