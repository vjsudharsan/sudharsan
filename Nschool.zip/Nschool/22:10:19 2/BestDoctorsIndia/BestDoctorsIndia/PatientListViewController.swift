//
//  PatientListViewController.swift
//  BestDoctorsIndia
//
//  Created by nschool on 19/10/19.
//  Copyright © 2019 Ndot. All rights reserved.
//

import UIKit

class PatientListViewController: BaseViewController,UITableViewDelegate,UITableViewDataSource {
    var receiveDoctorID:String! = String()
    
    @IBOutlet weak var navigationView: UIView!
    var patientListTableview:UITableView! = UITableView.init(frame: CGRect.zero, style: .grouped)
    var layoutDict = [String : AnyObject]()
    var patientlistDataArray:NSArray! = NSArray()
    @IBOutlet weak var menuBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.menuBtn.addTarget(self, action: #selector(BaseViewController.onSlideMenuButtonPressed(_:)), for: .touchUpInside)
        self.createpatientListTableview()
        // Do any additional setup after loading the view.
        self.patientLIstApiCAll()
        
    }
    func createpatientListTableview(){
        self.layoutDict["navigationView"] = self.navigationView
        self.patientListTableview.translatesAutoresizingMaskIntoConstraints = false
        self.patientListTableview.delegate = self
        self.patientListTableview.dataSource = self
        self.patientListTableview.backgroundColor = UIColor.white
        self.patientListTableview.separatorStyle = .none
        self.patientListTableview.showsVerticalScrollIndicator = false
        self.view.addSubview(self.patientListTableview)
        self.layoutDict["patientListTableview"] = self.patientListTableview
        self.view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:[navigationView]-(10)-[patientListTableview]-(10)-|", options: [], metrics: nil, views: self.layoutDict))
        self.view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(0)-[patientListTableview]-(0)-|", options: [], metrics: nil, views: self.layoutDict))
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = false
    }
    func patientLIstApiCAll(){
        let postDict = ["Doctor_Id":"1"] as NSDictionary
        print("\(postDict)")
        APIDownload.downloadDataFromServer(baseURL: "http://bestdoctorindia.com/Api/Doctor_patients", bodyData: postDict, method: "POST", key: "PatientList", completion: {(resultDict) in
            print("patient list:",resultDict)
            if "\(resultDict.value(forKey: "api_status")!)" == "1"{
                 self.patientlistDataArray = resultDict.value(forKey: "data") as? NSArray
                DispatchQueue.main.async {
                    self.patientListTableview.reloadData()
                }
            }
            else
            {
                self.showAlertMessage("Information", message: "\(resultDict.value(forKey: "message")!)")
            }
        })
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     
        return 5
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell:UITableViewCell! = tableView.dequeueReusableCell(withIdentifier: "patientlistCell")
        if cell == nil
        {
            cell = UITableViewCell.init(style: UITableViewCell.CellStyle.default, reuseIdentifier: "patientlistCell")
        }
        //Removing all the components
        for subView in cell.subviews
        {
            subView.removeFromSuperview()
        }
        var celllayoutDict = [String:AnyObject]()
        // main content view
        let contentView:UIView! = UIView.init()
        cell.addSubview(contentView)
        contentView.translatesAutoresizingMaskIntoConstraints = false
        celllayoutDict["contentView"] = contentView
        cell.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-(8)-[contentView]-(8)-|", options: [], metrics: nil, views: celllayoutDict))
        cell.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(8)-[contentView]-(8)-|", options: [], metrics: nil, views: celllayoutDict))
        contentView.layoutIfNeeded()
        contentView.layer.cornerRadius = 8.0
        contentView.layer.borderWidth = 2.0
        contentView.layer.borderColor = UIColor.lightGray.cgColor
        
        
        // doctor image
        let doctorImage:UIImageView! = UIImageView.init()
        doctorImage.translatesAutoresizingMaskIntoConstraints = false
        doctorImage.image = UIImage(named: "profileDoctor")
        doctorImage.contentMode = .scaleToFill
        contentView.addSubview(doctorImage)
        celllayoutDict["doctorImage"] = doctorImage

        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-(0)-[doctorImage]-(0)-|", options: [], metrics: nil, views: celllayoutDict))
        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(10)-[doctorImage(100)]", options: [], metrics: nil, views: celllayoutDict))
        // patient id label
        let patientIDtitlelabel:UILabel! = UILabel.init()
        patientIDtitlelabel.backgroundColor = UIColor.white
        patientIDtitlelabel.text = "Patient iD:1212"
        let patientIDtitlelabelmessageHeight = self.rectForText(text: patientIDtitlelabel.text!, font: UIFont.systemFont(ofSize:12), maxSize:CGSize(width: 256, height: 999))
        contentView.addSubview(patientIDtitlelabel)
        celllayoutDict["patientIDtitlelabel"] = patientIDtitlelabel
        patientIDtitlelabel.translatesAutoresizingMaskIntoConstraints = false
       
        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:[doctorImage]-(10)-[patientIDtitlelabel(120)]", options: [], metrics: ["patientIDtitlelabelmessageHeight":patientIDtitlelabelmessageHeight], views: celllayoutDict))
       
        // patient name label
        let patientnamelabel:UILabel! = UILabel.init()
        patientnamelabel.backgroundColor = UIColor.white
        patientnamelabel.text = "Name:Vijay"
        let messageHeight = self.rectForText(text: patientnamelabel.text!, font: UIFont.systemFont(ofSize:14), maxSize:CGSize(width: 256, height: 999))
        contentView.addSubview(patientnamelabel)
        celllayoutDict["patientnamelabel"] = patientnamelabel
        patientnamelabel.translatesAutoresizingMaskIntoConstraints = false
     
        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:[doctorImage]-(10)-[patientnamelabel(120)]", options: [], metrics: ["width":messageHeight], views: celllayoutDict))
        //gender label
        let genderLabel:UILabel! = UILabel.init()
        genderLabel.backgroundColor = UIColor.white
        genderLabel.text = "Gender:Male"
        let gendermessageHeight = self.rectForText(text: genderLabel.text!, font: UIFont.systemFont(ofSize:12), maxSize:CGSize(width: 256, height: 999))
        contentView.addSubview(genderLabel)
        celllayoutDict["genderLabel"] = genderLabel
        genderLabel.translatesAutoresizingMaskIntoConstraints = false
        
        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:[doctorImage]-(10)-[genderLabel(120)]", options: [], metrics: ["gendermessageHeight":gendermessageHeight], views: celllayoutDict))
        // case id label
        let caseIDlabel:UILabel! = UILabel.init()
        caseIDlabel.backgroundColor = UIColor.white
        caseIDlabel.text = "Case iD:2"
        caseIDlabel.font = UIFont.systemFont(ofSize: 12)
        contentView.addSubview(caseIDlabel)
        celllayoutDict["caseIDlabel"] = caseIDlabel
        caseIDlabel.translatesAutoresizingMaskIntoConstraints = false
      
        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:[doctorImage]-(10)-[caseIDlabel(120)]", options: [], metrics: nil, views: celllayoutDict))
        // issues label
        let issueslabel:UILabel! = UILabel.init()
        issueslabel.backgroundColor = UIColor.white
        issueslabel.text = "issues:Love problem"
        issueslabel.numberOfLines = 0
        var issueslabelHeight = self.rectForText(text: issueslabel.text!, font: UIFont.systemFont(ofSize:12), maxSize:CGSize(width: 256, height: 999))
        issueslabelHeight = issueslabelHeight + 30
        contentView.addSubview(issueslabel)
        celllayoutDict["issueslabel"] = issueslabel
        issueslabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:[doctorImage]-(10)-[issueslabel(120)]", options: [], metrics: nil, views: celllayoutDict))
        // description label
        let descriptionLabel:UILabel! = UILabel.init()
        descriptionLabel.backgroundColor = UIColor.white
        descriptionLabel.numberOfLines = 0
        descriptionLabel.text = "Description: Any girl"
        var descriptionLabelHeight = self.rectForText(text: descriptionLabel.text!, font: UIFont.systemFont(ofSize:12), maxSize:CGSize(width: 256, height: 999))
        descriptionLabelHeight = descriptionLabelHeight + 30
        contentView.addSubview(descriptionLabel)
        celllayoutDict["descriptionLabel"] = descriptionLabel
        descriptionLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-(10)-[patientIDtitlelabel(patientIDtitlelabelmessageHeight)]-(10)-[patientnamelabel(width)]-(10)-[genderLabel(gendermessageHeight)]-(10)-[caseIDlabel(20)]-(10)-[issueslabel(issueslabelHeight)]-(10)-[descriptionLabel(descriptionLabelHeight)]", options: [], metrics: ["patientIDtitlelabelmessageHeight":patientIDtitlelabelmessageHeight,"gendermessageHeight":gendermessageHeight,"width":messageHeight,"descriptionLabelHeight":descriptionLabelHeight,"issueslabelHeight":issueslabelHeight], views: celllayoutDict))
        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:[doctorImage]-(10)-[descriptionLabel(120)]", options: [], metrics: nil, views: celllayoutDict))
        // chat now button
        let chatNow:UIButton! = UIButton.init()
        chatNow.setTitle("Chat Now", for: .normal)
        chatNow.backgroundColor = UIColor.red
        contentView.addSubview(chatNow)
        celllayoutDict["chatNow"] = chatNow
        chatNow.translatesAutoresizingMaskIntoConstraints = false
        contentView.addConstraint(NSLayoutConstraint.init(item: chatNow!, attribute: .centerY, relatedBy: .equal, toItem: contentView, attribute: .centerY, multiplier: 1.0, constant: 0))
         contentView.addConstraint(NSLayoutConstraint.init(item: chatNow!, attribute: .centerX, relatedBy: .equal, toItem: contentView, attribute: .centerX, multiplier: 1.0, constant: 0))
        //chatNow.addConstraint(NSLayoutConstraint.init(item: chatNow!, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .width, multiplier: 1.0, constant: 120))
        //chatNow.addConstraint(NSLayoutConstraint.init(item: chatNow!, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1.0, constant: 40))
        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:[chatNow(100)]-(8)-|", options: [], metrics: nil, views: celllayoutDict))
        chatNow.layoutIfNeeded()
        chatNow.layer.cornerRadius = 8.0
        cell.selectionStyle = .none
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 270
    }
    func rectForText(text: String, font: UIFont, maxSize: CGSize) -> CGFloat
    {
        //This is a method to calculate the height
        let label = UILabel(frame:CGRect(x: 0, y: 0, width: maxSize.width, height: maxSize.height))
        label.numberOfLines = 6
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = font
        label.text = text
        
        label.sizeToFit()
        
        return label.frame.height
    }
    func chatnowButtonAction(){
        let chatListVC = self.storyboard?.instantiateViewController(withIdentifier: "ChatViewController") as! ChatViewController
        self.navigationController?.pushViewController(chatListVC, animated: true)
        
    }
    func showAlertMessage(_ title:String,message: String){
           let alertController = UIAlertController.init(title: title, message: message, preferredStyle: .alert)
           let okbtn = UIAlertAction.init(title: "OK", style: .default, handler:nil)
           alertController.addAction(okbtn)
           self.present(alertController, animated: true, completion: nil)
       }
}
