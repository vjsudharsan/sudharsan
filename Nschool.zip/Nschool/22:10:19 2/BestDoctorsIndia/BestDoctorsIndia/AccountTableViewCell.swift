//
//  AccountTableViewCell.swift
//  BestDoctorsIndia
//
//  Created by nschool on 15/10/19.
//  Copyright © 2019 Ndot. All rights reserved.
//

import UIKit

 class AccountTableViewCell: UITableViewCell {

    @IBOutlet var accountInputFields: UITextField!
    override  func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.accountInputFields.delegate = self
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
   func setTag(tag: Int){
        accountInputFields.tag = 100+tag
    }

}
extension AccountTableViewCell: UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
}
