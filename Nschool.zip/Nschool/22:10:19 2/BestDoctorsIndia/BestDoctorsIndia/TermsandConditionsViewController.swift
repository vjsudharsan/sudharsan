//
//  TermsandConditionsViewController.swift
//  BestDoctorsIndia
//
//  Created by nschool on 02/10/19.
//  Copyright © 2019 Ndot. All rights reserved.
//

import UIKit

class TermsandConditionsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

   override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = false
    }
}
