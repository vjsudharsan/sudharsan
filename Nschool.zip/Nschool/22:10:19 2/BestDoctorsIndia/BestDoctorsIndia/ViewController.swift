//
//  ViewController.swift
//  BestDoctorsIndia
//
//  Created by Developer on 9/25/19.
//  Copyright © 2019 Ndot. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var title_lbl: UILabel!
    @IBOutlet weak var description_lbl: UILabel!
    @IBOutlet weak var signupBtn: UIButton!
    @IBOutlet weak var signinBtn: UIButton!
    @IBOutlet weak var copyrights_lbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.title_lbl.text = "BestDoctorindia \n CONNECTING THE DOCTOR"
        self.title_lbl.numberOfLines = 0
        self.description_lbl.text = "Consult Top Doctors from the \n Best Doctors in India"
        self.description_lbl.numberOfLines = 0
        self.copyrights_lbl.text = "copy c bestdoctorindia. \n All rights reserved"
        self.copyrights_lbl.numberOfLines = 0
        self.copyrights_lbl.lineBreakMode = .byWordWrapping
        self.signinBtn.layer.cornerRadius = 25.0
        self.signupBtn.layer.cornerRadius = 25.0
        self.signinBtn.setTitleColor(UIColor.init(red: 45.0/255.0, green: 146.0/255.0, blue: 168.0/255.0, alpha: 1.0), for: .normal)
        self.signupBtn.setTitleColor(UIColor.init(red: 45.0/255.0, green: 146.0/255.0, blue: 168.0/255.0, alpha: 1.0), for: .normal)
       
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = false
    }

}

