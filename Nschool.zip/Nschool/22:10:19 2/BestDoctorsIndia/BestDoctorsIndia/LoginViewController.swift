//
//  LoginViewController.swift
//  BestDoctorsIndia
//
//  Created by Developer on 9/25/19.
//  Copyright © 2019 Ndot. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController,UITextFieldDelegate {
    
    @IBOutlet weak var navigationView: UIView!
    @IBOutlet weak var bottomConstrain: NSLayoutConstraint!
    @IBOutlet weak var Mobilenumber_txtfld: UITextField!
    @IBOutlet weak var password_txtfld: UITextField!
    @IBOutlet weak var signinBtn: UIButton!
    @IBOutlet weak var forgetpswdBtn: UIButton!
    @IBOutlet weak var copyrights_lbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.Mobilenumber_txtfld.keyboardType = .numberPad
        let numberToolbar = UIToolbar(frame:CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
        numberToolbar.barStyle = .default
        numberToolbar.items = [
        UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelNumberPad)),
        UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil),
        UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(doneWithNumberPad))]
        numberToolbar.sizeToFit()
        Mobilenumber_txtfld.inputAccessoryView = numberToolbar
        self.textfieldPaddingview(self.Mobilenumber_txtfld)
        self.textfieldPaddingview(self.password_txtfld)
        self.setcustomPlaceholderString(self.Mobilenumber_txtfld!, placeholderString: "Mobile Number", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.setcustomPlaceholderString(self.password_txtfld!, placeholderString: "Password", placeholderFont: UIFont.systemFont(ofSize: 14), placeholderColor: UIColor.lightGray)
        self.Mobilenumber_txtfld.addShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        self.password_txtfld.addShadowToTextField(color: UIColor.lightGray, cornerRadius: 20)
        self.password_txtfld.isSecureTextEntry = true
        self.signinBtn.layer.cornerRadius = 25.0
        self.signinBtn.addTarget(self, action: #selector(signinBtnAction(_:)), for: .touchUpInside)
        //self.signinBtn.applyGradient(colours: [UIColor.init(red: 45/255.0, green: 146.0/255.0, blue: 191.0/255.0, alpha: 1.0),UIColor.init(red: 86.0/255.0, green: 228.0/255.0, blue: 168.0/255.0, alpha: 1.0)])
        self.copyrights_lbl.text = "copy c bestdoctorindia. All rights reserved"
        self.copyrights_lbl.numberOfLines = 0
        self.copyrights_lbl.textColor = UIColor.lightGray
        self.copyrights_lbl.textAlignment = .center
        self.copyrights_lbl.font = UIFont.systemFont(ofSize: 14)
        self.applyGradient(with: [UIColor.init(red: 86.0/255.0, green: 228.0/255.0, blue: 168.0/255.0, alpha: 1.0),UIColor.init(red: 45.0/255.0, green: 146.0/255.0, blue: 191.0/255.0, alpha: 1.0)], myview: self.navigationView!)
        self.ButtonapplyGradient(with: [UIColor.init(red: 45.0/255.0, green: 146.0/255.0, blue: 191.0/255.0, alpha: 1.0),UIColor.init(red: 86.0/255.0, green: 228.0/255.0, blue: 168.0/255.0, alpha: 1.0)], mybutton: self.signinBtn!)
     
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = false
    }
// set padding view for textfields
    @IBAction func backBtn_action(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @objc func signinBtnAction(_ sender:UIButton){
        if Validation.isEmpty(self.Mobilenumber_txtfld) ||
            Validation.isEmpty(self.password_txtfld) {
         self.showAlertMessage("Message", message: "Enter your Mobile Number and Password")
        }
        else if Validation.emailValidation(self.Mobilenumber_txtfld.text!){
            self.showAlertMessage("Message", message: "Enter valid Email Address")
        }
        else
        {
            let postDict = ["mobile":self.Mobilenumber_txtfld.text!,"password":self.password_txtfld.text!,"device_token":"\(Extensions.getdeviceToken())"] as NSDictionary
                   print("\(postDict)")
                   APIDownload.downloadDataFromServer(baseURL: "http://bestdoctorindia.com/Api/Doctor_login", bodyData: postDict, method: "POST", key: "Doctor_login", completion: {(resultDict) in
                       print("Doctor_login:",resultDict)
                   })
        }

    }
    func textfieldPaddingview(_ txtfld:UITextField){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: txtfld.frame.size.height))
        txtfld.leftView = paddingView
        txtfld.leftViewMode = .always
    }
    // func set custom placeholder in textfields
    func setcustomPlaceholderString(_ txtfld:UITextField!, placeholderString:String!, placeholderFont : UIFont, placeholderColor: UIColor){
        txtfld.attributedPlaceholder = NSMutableAttributedString.init(string: placeholderString, attributes: [NSAttributedString.Key.font : placeholderFont,NSAttributedString.Key.foregroundColor :placeholderColor])
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == self.Mobilenumber_txtfld {
            self.password_txtfld.becomeFirstResponder()
        }
        else if textField == self.password_txtfld{
            self.password_txtfld.resignFirstResponder()
        }
        return true
    }
    func showAlertMessage(_ title:String,message: String){
        let alertController = UIAlertController.init(title: title, message: message, preferredStyle: .alert)
        let okbtn = UIAlertAction.init(title: "OK", style: .default, handler:nil)
        alertController.addAction(okbtn)
        self.present(alertController, animated: true, completion: nil)
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
    if textField == self.Mobilenumber_txtfld{
        let maxLength = 10
        let currentString: NSString = self.Mobilenumber_txtfld.text! as NSString
        let newString: NSString =
        currentString.replacingCharacters(in: range, with: string) as NSString
        return newString.length <= maxLength
    }
    return true
    }
    
    @IBAction func forgrtBtn_Action(_ sender: UIButton) {
        let mobileVC = self.storyboard?.instantiateViewController(withIdentifier: "MobileNumberViewController") as! MobileNumberViewController
        self.navigationController?.pushViewController(mobileVC, animated: true)
        
    }
    
    @objc func cancelNumberPad() {
        //Cancel with number pad
        self.Mobilenumber_txtfld.resignFirstResponder()
    }
    @objc func doneWithNumberPad() {
        //Done with number pad
        self.Mobilenumber_txtfld.resignFirstResponder()
        self.password_txtfld.becomeFirstResponder()
        
    }
    func applyGradient(with colours: [UIColor],myview:UIView) {
           let gradient = CAGradientLayer()
           gradient.frame = myview.bounds
           gradient.colors = colours.map { $0.cgColor }
           gradient.startPoint = CGPoint(x: 0.0, y: 0.5)
           gradient.endPoint = CGPoint(x: 1.0, y: 0.5)
           myview.layer.insertSublayer(gradient, at: 0)
    }
    func ButtonapplyGradient(with colours: [UIColor],mybutton:UIButton) {
        let gradient = CAGradientLayer()
        gradient.frame = mybutton.bounds
        gradient.colors = colours.map { $0.cgColor }
        gradient.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradient.endPoint = CGPoint(x: 1.0, y: 0.5)
        mybutton.layoutIfNeeded()
        mybutton.layer.cornerRadius = 25.0
        mybutton.clipsToBounds = true
        mybutton.layer.insertSublayer(gradient, at: 0)
    }
}
extension UITextField {
    func addShadowToTextField(color: UIColor = UIColor.gray, cornerRadius: CGFloat) {
        self.backgroundColor = UIColor.white
        self.layer.masksToBounds = false
        self.layer.shadowColor = color.cgColor
        self.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.layer.shadowOpacity = 1.0
        self.backgroundColor = .white
        self.layer.cornerRadius = cornerRadius
    }
}
