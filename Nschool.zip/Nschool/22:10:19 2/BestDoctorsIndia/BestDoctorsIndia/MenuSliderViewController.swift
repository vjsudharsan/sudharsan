//
//  MenuSliderViewController.swift
//  SliderMenu
//
//  Created by Developer on 9/26/19.
//  Copyright © 2019 Ndot. All rights reserved.
//

import UIKit

protocol SlideMenuDelegate {
    func slideMenuItemSelectedAtIndex(_ index : Int32)
}
class MenuSliderViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var menucloseBtn: UIButton!
    @IBOutlet weak var menuTable: UITableView!
    var arraymenuData = [Dictionary<String,String>]()
     var delegate : SlideMenuDelegate?
     var btnMenu : UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.menucloseBtn.addTarget(self, action: #selector(oncloseButtonAction(_:)), for: .touchUpInside)
        self.menuTable.tableFooterView = UIView()
        self.menuTable.showsVerticalScrollIndicator = false
        self.menuTable.alwaysBounceVertical = false
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        self.loadmenuArray()
    }
    func loadmenuArray(){
        self.arraymenuData.append(["title":"Profile","icon":"profile"])
        self.arraymenuData.append(["title":"Invoice","icon":"invoice"])
        self.arraymenuData.append(["title":"Settings","icon":"settings"])
        self.arraymenuData.append(["title":"About us","icon":"aboutus"])
        self.arraymenuData.append(["title":"Share","icon":"share"])
        self.arraymenuData.append(["title":"Notifications","icon":"notifications"])
        self.arraymenuData.append(["title":"Help","icon":"help"])
        self.arraymenuData.append(["title":"Terms and Conditions","icon":"terms"])
        self.arraymenuData.append(["title":"Signout","icon":"signout"])
        self.menuTable.reloadData()
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arraymenuData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "menucell")!
        cell.selectionStyle = UITableViewCell.SelectionStyle.none
        cell.layoutMargins = UIEdgeInsets.zero
        cell.preservesSuperviewLayoutMargins = false
        cell.backgroundColor = UIColor.clear
        self.menuTable.separatorStyle = .none

        
        let lblTitle : UILabel = cell.contentView.viewWithTag(101) as! UILabel
        let imgIcon : UIImageView = cell.contentView.viewWithTag(100) as! UIImageView
        imgIcon.image = UIImage(named: arraymenuData[indexPath.row]["icon"]!)
        imgIcon.layer.cornerRadius = 25.0
        imgIcon.clipsToBounds = true
        lblTitle.text = arraymenuData[indexPath.row]["title"]!
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let btn = UIButton(type: UIButton.ButtonType.custom)
        btn.tag = indexPath.row
        self.oncloseButtonAction(btn)
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    @objc func oncloseButtonAction(_ sender:UIButton){
    btnMenu.tag = 0
           
           if (self.delegate != nil) {
               var index = Int32(sender.tag)
               if(sender == self.menucloseBtn){
                   index = -1
               }
               delegate?.slideMenuItemSelectedAtIndex(index)
           }
           
           UIView.animate(withDuration: 0.3, animations: { () -> Void in
               self.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width,height: UIScreen.main.bounds.size.height)
               self.view.layoutIfNeeded()
               self.view.backgroundColor = UIColor.clear
               }, completion: { (finished) -> Void in
                   self.view.removeFromSuperview()
                   self.removeFromParent()
           })
    }
    
}

