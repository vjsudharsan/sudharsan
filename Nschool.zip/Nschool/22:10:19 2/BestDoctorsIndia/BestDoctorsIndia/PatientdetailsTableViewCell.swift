//
//  PatientdetailsTableViewCell.swift
//  BestDoctorsIndia
//
//  Created by nschool on 18/10/19.
//  Copyright © 2019 Ndot. All rights reserved.
//

import UIKit

class PatientdetailsTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
