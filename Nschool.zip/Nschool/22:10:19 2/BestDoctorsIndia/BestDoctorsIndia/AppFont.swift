//
//  AppFont.swift
//  TASK
//
//  Created by Developer on 10/17/19.
//  Copyright © 2019 Ndot. All rights reserved.
//

import Foundation
import UIKit
extension UIFont
{
    class func setAppFont(_ size:CGFloat)->(UIFont)
    {
        return UIFont(name: "Roboto-Regular", size: size)!
    }
    class func setAppFontBold(_ size:CGFloat)->(UIFont)
    {
        return UIFont(name: "Roboto-Medium", size: size)!
    }
}
