//
//  APIDownload.swift
//  TASK
//
//  Created by Developer on 10/17/19.
//  Copyright © 2019 Ndot. All rights reserved.
//

import UIKit

class APIDownload: NSObject {
    class func sendGetMethod(_ url:String,key:String,completion:@escaping (_ resultDic:NSDictionary)->Void) {
        let baseURL = url
        let encodedUrl : String! = baseURL.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
        
        // Creating a request
        var request = URLRequest.init(url:URL(string:encodedUrl)!, cachePolicy:NSURLRequest.CachePolicy.reloadIgnoringCacheData, timeoutInterval: 120)
        request.httpMethod = "GET"
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = TimeInterval(30)
        configuration.timeoutIntervalForResource = TimeInterval(30)
        
        let session = URLSession(configuration: configuration)
        //API Call using URLSession
        let getMethodTask = session.dataTask(with: request, completionHandler: { (data,response,error) -> Void in
            DispatchQueue.main.async(execute: { () -> Void in
                if error != nil {
                    print(error?.localizedDescription)
                } else {
                      if data != nil {
                        do {
                        var resultDictionary:NSDictionary! = NSDictionary()
                        let result = String(data: data!, encoding: String.Encoding.utf8)
                            if result != nil {
                                let dataDic = result!.data(using: .utf8)
                                resultDictionary = try JSONSerialization.jsonObject(with: dataDic!, options: .mutableContainers) as! NSDictionary
                                 if resultDictionary != nil && resultDictionary.count > 0 {
                                    completion(resultDictionary)
                                }
                                else
                                 {
                                     print("Empty dictionary")
                                }
                            }
                        }
                        catch let err as NSError
                        {
                            print(err.localizedDescription)
                        }
                    }
                }
            })
        })
        getMethodTask.resume()
    }
    class func downloadDataFromServer(baseURL:String,bodyData:NSDictionary,method:String,key:String,completion:@escaping (_ resultDic:NSDictionary)->Void) {
        let baseURL = baseURL
        let encodedURL = baseURL.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        // Creating URL Object
        let url = URL(string:encodedURL!)
        // Creating a Mutable Request
        var request = URLRequest.init(url: url!)
        do
        {
            var theJSONData:Data!
            theJSONData = try JSONSerialization.data(withJSONObject: bodyData, options: JSONSerialization.WritingOptions(rawValue: 0))
            let theJSONText =  NSString(data: theJSONData, encoding: String.Encoding.utf8.rawValue)! as String
            let postData = theJSONText.data(using: String.Encoding.utf8)
            //Setting HTTP values
            request.httpMethod = method
            request.setValue("application/json", forHTTPHeaderField:"Accept")
            request.setValue("application/json", forHTTPHeaderField:"Content-Type")
            request.setValue(String("\(String(describing: postData?.count))"), forHTTPHeaderField:"Content-Length")
            request.httpBody = postData
            request.timeoutInterval = (key == "edit_passenger_profile") ? 250 : 120
            
            let configuration = URLSessionConfiguration.default
            configuration.timeoutIntervalForRequest = TimeInterval(30)
            configuration.timeoutIntervalForResource = TimeInterval(30)
            
            let session = URLSession(configuration: configuration)
            
            let downloadTask = session.dataTask(with: request, completionHandler: { (data, response, error) -> Void in
                
                DispatchQueue.main.async(execute: { () -> Void in
                    if error == nil {
                        if data != nil {
                            do {
                                let result = String(data: data!, encoding: .utf8)
                                if result != nil {
                                    
                                    let dataDic = result!.data(using: .utf8)
                                    let resultDictionary:NSDictionary! = try JSONSerialization.jsonObject(with: dataDic!, options: .mutableContainers) as! NSDictionary
                                    if resultDictionary != nil && resultDictionary.count > 0 {
                                        completion(resultDictionary)
                                    }
                                } else {
                                    //Error
                                     print("Empty dictionary")
                                }
                            }
                            catch let err as NSError{
                                 print(err.localizedDescription)
                            }
                        }
                    }
                })
            })
            downloadTask.resume()
        }
        catch let err as NSError{
            print(err.localizedDescription)
        }
    }
}
