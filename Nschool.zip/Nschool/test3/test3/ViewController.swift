//
//  ViewController.swift
//  test3
//
//  Created by nschool on 03/10/20.
//

import UIKit

class ViewController: UIViewController {
    var val : String?
    var val2 : String?
    var city:[Int:String]? = [1:"Coimbatore", 2:"chennai"]
    
    
    override func viewDidLoad() {
        
        val = "hello world"
        val2 = "Welcome"
        if let val = val ,let val2 = val2 {
            print(val)
            print(val2)
        }
        
        
            if let city = city{
    print(city)
        }
        
        
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    
}
    
    
}
